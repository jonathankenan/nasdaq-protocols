from enum import Enum
from typing import Callable, Awaitable, Type

from nasdaq_protocols.common import logable
from nasdaq_protocols.common.message import *
from nasdaq_protocols import soup, ouch


__all__ = [
    'Message',
    'ClientSession',
    'connect_async',
    'OuchIncomingMessageType',
    'OuchOutgoingMessageType',
    'OuchTimeInForce',
    'OuchSide',
    'OuchOrderType',
    'OuchOrderCapacity',
    'OuchAttributes',
    'OuchEnterOrder',
    'OuchReplaceOrder',
    'OuchCancelOrder',
    'OuchCancelOrderById',
    'OuchOrderAccepted',
    'OuchOrderReplaced',
    'OuchOrderCanceled',
    'OuchOrderExecuted',
    'OuchOrderRejected',
]


@logable
class Message(ouch.Message, app_name='de_gwy'):
    def __init_subclass__(cls, **kwargs):
        cls.log.debug('subclassing %s, params = %s', cls.__name__, str(kwargs))
        if 'indicator' not in kwargs:
            raise ValueError('expected "indicator" when subclassing de_gwy.Message')

        kwargs['app_name'] = 'de_gwy'
        super().__init_subclass__(**kwargs)


class ClientSession(ouch.ClientSession):
    @classmethod
    def decode(cls, bytes_: bytes) -> [int, Message]:
        return Message.from_bytes(bytes_)


async def connect_async(remote: tuple[str, int], user: str, passwd: str, session_id,
                        sequence: int = 0,
                        session_factory: Callable[[soup.SoupClientSession], ClientSession] = None,
                        on_msg_coro: Callable[[Type[Message]], Awaitable[None]] = None,
                        on_close_coro: Callable[[], Awaitable[None]] = None,
                        client_heartbeat_interval: int = 10,
                        server_heartbeat_interval: int = 10) -> ClientSession:
    if session_factory is None:
        def session_factory(x):
            return ClientSession(x, on_msg_coro=on_msg_coro, on_close_coro=on_close_coro)

    return await ouch.connect_async(
        remote, user, passwd, session_id, sequence,
        session_factory, on_msg_coro, on_close_coro,
        client_heartbeat_interval, server_heartbeat_interval
    )


# Enums
class OuchIncomingMessageType(Enum):
    OuchEnterOrder = 79
    OuchReplaceOrder = 85
    OuchCancelOrder = 88
    OuchCancelOrderById = 89


class OuchOutgoingMessageType(Enum):
    OuchOrderAccepted = 65
    OuchOrderCanceled = 67
    OuchOrderExecuted = 69
    OuchOrderRejected = 74
    OuchOrderReplaced = 85


class OuchTimeInForce(Enum):
    Undefined = 0
    Day = 1
    GTC = 2
    Fak = 3
    Fok = 4
    GTS = 5
    Days = 6


class OuchSide(Enum):
    Buy = 'B'
    Sell = 'S'
    ShortSell = 'T'


class OuchOrderType(Enum):
    Limit = 1
    Market = 2
    MarketToLimit = 3
    BestOrder = 4
    Imbalance = 5


class OuchOrderCapacity(Enum):
    Agency = 1
    Proprietary = 2
    Individual = 3
    Principal = 4
    RiskLessPrincipal = 5


class OuchAttributes(Enum):
    Undefined = 0
    MarketBid = 1
    PriceStabilization = 2
    Margin = 3


# Records
# Messages
class OuchEnterOrder(Message, indicator=79, direction='incoming'):
    class BodyRecord(Record):
        Fields = [
            Field('orderToken', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('timeInForce', Byte),
            Field('openClose', Byte),
            Field('clientAccount', FixedIsoString(length=16)),
            Field('customerInfo', FixedIsoString(length=15)),
            Field('exchangeInfo', FixedIsoString(length=32)),
            Field('displayQuantity', LongBE),
            Field('orderType', Byte),
            Field('timeInForceData', ShortBE),
            Field('orderCapacity', Byte),
            Field('selfMatchPreventionKey', IntBE),
            Field('attributes', ShortBE),
        ]

    orderToken: int
    orderBookId: int
    side: str
    quantity: int
    price: int
    timeInForce: int
    openClose: int
    clientAccount: str
    customerInfo: str
    exchangeInfo: str
    displayQuantity: int
    orderType: int
    timeInForceData: int
    orderCapacity: int
    selfMatchPreventionKey: int
    attributes: int


class OuchReplaceOrder(Message, indicator=85, direction='incoming'):
    class BodyRecord(Record):
        Fields = [
            Field('existingOrderToken', LongBE),
            Field('replacementOrderToken', LongBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('openClose', Byte),
            Field('clientAccount', FixedIsoString(length=16)),
            Field('customerInfo', FixedIsoString(length=15)),
            Field('exchangeInfo', FixedIsoString(length=32)),
            Field('displayQuantity', LongBE),
            Field('timeInForce', Byte),
            Field('timeInForceData', ShortBE),
            Field('selfMatchPreventionKey', IntBE),
        ]

    existingOrderToken: int
    replacementOrderToken: int
    quantity: int
    price: int
    openClose: int
    clientAccount: str
    customerInfo: str
    exchangeInfo: str
    displayQuantity: int
    timeInForce: int
    timeInForceData: int
    selfMatchPreventionKey: int


class OuchCancelOrder(Message, indicator=88, direction='incoming'):
    class BodyRecord(Record):
        Fields = [
            Field('orderToken', LongBE),
        ]

    orderToken: int


class OuchCancelOrderById(Message, indicator=89, direction='incoming'):
    class BodyRecord(Record):
        Fields = [
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderId', LongBE),
        ]

    orderBookId: int
    side: str
    orderId: int


class OuchOrderAccepted(Message, indicator=65, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('timestamp', LongBE),
            Field('orderToken', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderId', LongBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('timeInForce', Byte),
            Field('openClose', Byte),
            Field('clientAccount', FixedIsoString(length=16)),
            Field('orderState', Byte),
            Field('customerInfo', FixedIsoString(length=15)),
            Field('exchangeInfo', FixedIsoString(length=32)),
            Field('displayQuantity', LongBE),
            Field('orderType', Byte),
            Field('timeInForceData', ShortBE),
            Field('orderCapacity', Byte),
            Field('selfMatchPreventionKey', IntBE),
            Field('attributes', ShortBE),
        ]

    timestamp: int
    orderToken: int
    orderBookId: int
    side: str
    orderId: int
    quantity: int
    price: int
    timeInForce: int
    openClose: int
    clientAccount: str
    orderState: int
    customerInfo: str
    exchangeInfo: str
    displayQuantity: int
    orderType: int
    timeInForceData: int
    orderCapacity: int
    selfMatchPreventionKey: int
    attributes: int


class OuchOrderReplaced(Message, indicator=85, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('timestamp', LongBE),
            Field('replacementOrderToken', LongBE),
            Field('previousOrderToken', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderId', LongBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('timeInForce', Byte),
            Field('openClose', Byte),
            Field('clientAccount', FixedIsoString(length=16)),
            Field('orderState', Byte),
            Field('customerInfo', FixedIsoString(length=15)),
            Field('exchangeInfo', FixedIsoString(length=32)),
            Field('displayQuantity', LongBE),
            Field('orderType', Byte),
            Field('timeInForceData', ShortBE),
            Field('orderCapacity', Byte),
            Field('selfMatchPreventionKey', IntBE),
            Field('attributes', ShortBE),
        ]

    timestamp: int
    replacementOrderToken: int
    previousOrderToken: int
    orderBookId: int
    side: str
    orderId: int
    quantity: int
    price: int
    timeInForce: int
    openClose: int
    clientAccount: str
    orderState: int
    customerInfo: str
    exchangeInfo: str
    displayQuantity: int
    orderType: int
    timeInForceData: int
    orderCapacity: int
    selfMatchPreventionKey: int
    attributes: int


class OuchOrderCanceled(Message, indicator=67, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('timestamp', LongBE),
            Field('orderToken', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderId', LongBE),
            Field('cancelReason', Byte),
        ]

    timestamp: int
    orderToken: int
    orderBookId: int
    side: str
    orderId: int
    cancelReason: int


class OuchOrderExecuted(Message, indicator=69, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('timestamp', LongBE),
            Field('orderToken', LongBE),
            Field('orderBookId', IntBE),
            Field('tradeQuantity', LongBE),
            Field('tradePrice', LongBE),
            Field('matchId', LongBE),
            Field('comboGroupId', IntBE),
            Field('dealSource', Byte),
        ]

    timestamp: int
    orderToken: int
    orderBookId: int
    tradeQuantity: int
    tradePrice: int
    matchId: int
    comboGroupId: int
    dealSource: int


class OuchOrderRejected(Message, indicator=74, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('timestamp', LongBE),
            Field('orderToken', LongBE),
            Field('orderId', LongBE),
            Field('rejectCode', IntBE),
        ]

    timestamp: int
    orderToken: int
    orderId: int
    rejectCode: int


