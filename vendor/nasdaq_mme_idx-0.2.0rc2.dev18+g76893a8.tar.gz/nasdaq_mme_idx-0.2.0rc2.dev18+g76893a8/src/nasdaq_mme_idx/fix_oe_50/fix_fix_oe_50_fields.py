from nasdaq_protocols import fix


class BeginString(fix.Field, Tag="8", Name="BeginString", Type=fix.FixString):
    Values = {
    }


class BodyLength(fix.Field, Tag="9", Name="BodyLength", Type=fix.FixInt):
    Values = {
    }


class MsgType(fix.Field, Tag="35", Name="MsgType", Type=fix.FixString):
    Values = {
        '0': 'Heartbeat',
        '1': 'TestRequest',
        '2': 'ResendRequest',
        '3': 'Reject',
        '4': 'SequenceReset',
        '5': 'Logout',
        '6': 'IOI',
        '7': 'Advertisement',
        '8': 'ExecutionReport',
        '9': 'OrderCancelReject',
        'A': 'Logon',
        'AA': 'DerivativeSecurityList',
        'AB': 'NewOrderMultileg',
        'AC': 'MultilegOrderCancelReplace',
        'AD': 'TradeCaptureReportRequest',
        'AE': 'TradeCaptureReport',
        'AF': 'OrderMassStatusRequest',
        'AG': 'QuoteRequestReject',
        'AH': 'RFQRequest',
        'AI': 'QuoteStatusReport',
        'AJ': 'QuoteResponse',
        'AK': 'Confirmation',
        'AL': 'PositionMaintenanceRequest',
        'AM': 'PositionMaintenanceReport',
        'AN': 'RequestForPositions',
        'AO': 'RequestForPositionsAck',
        'AP': 'PositionReport',
        'AQ': 'TradeCaptureReportRequestAck',
        'AR': 'TradeCaptureReportAck',
        'AS': 'AllocationReport',
        'AT': 'AllocationReportAck',
        'AU': 'ConfirmationAck',
        'AV': 'SettlementInstructionRequest',
        'AW': 'AssignmentReport',
        'AX': 'CollateralRequest',
        'AY': 'CollateralAssignment',
        'AZ': 'CollateralResponse',
        'B': 'News',
        'BA': 'CollateralReport',
        'BB': 'CollateralInquiry',
        'BC': 'NetworkCounterpartySystemStatusRequest',
        'BD': 'NetworkCounterpartySystemStatusResponse',
        'BE': 'UserRequest',
        'BF': 'UserResponse',
        'BG': 'CollateralInquiryAck',
        'BH': 'ConfirmationRequest',
        'BI': 'TradingSessionListRequest',
        'BJ': 'TradingSessionList',
        'BK': 'SecurityListUpdateReport',
        'BL': 'AdjustedPositionReport',
        'BM': 'AllocationInstructionAlert',
        'BN': 'ExecutionAck',
        'BO': 'ContraryIntentionReport',
        'BP': 'SecurityDefinitionUpdateReport',
        'BQ': 'SettlementObligationReport',
        'BR': 'DerivativeSecurityListUpdateReport',
        'BS': 'TradingSessionListUpdateReport',
        'BT': 'MarketDefinitionRequest',
        'BU': 'MarketDefinition',
        'BV': 'MarketDefinitionUpdateReport',
        'BW': 'ApplicationMessageRequest',
        'BX': 'ApplicationMessageRequestAck',
        'BY': 'ApplicationMessageReport',
        'BZ': 'OrderMassActionReport',
        'C': 'Email',
        'CA': 'OrderMassActionRequest',
        'CB': 'UserNotification',
        'CC': 'StreamAssignmentRequest',
        'CD': 'StreamAssignmentReport',
        'CE': 'StreamAssignmentReportACK',
        'CF': 'PartyDetailsListRequest',
        'CG': 'PartyDetailsListReport',
        'CH': 'MarginRequirementInquiry',
        'CI': 'MarginRequirementInquiryAck',
        'CJ': 'MarginRequirementReport',
        'CK': 'PartyDetailsListUpdateReport',
        'CL': 'PartyRiskLimitsRequest',
        'CM': 'PartyRiskLimitsReport',
        'CN': 'SecurityMassStatusRequest',
        'CO': 'SecurityMassStatus',
        'CQ': 'AccountSummaryReport',
        'CR': 'PartyRiskLimitsUpdateReport',
        'CS': 'PartyRiskLimitsDefinitionRequest',
        'CT': 'PartyRiskLimitsDefinitionRequestAck',
        'CU': 'PartyEntitlementsRequest',
        'CV': 'PartyEntitlementsReport',
        'CW': 'QuoteAck',
        'CX': 'PartyDetailsDefinitionRequest',
        'CY': 'PartyDetailsDefinitionRequestAck',
        'CZ': 'PartyEntitlementsUpdateReport',
        'D': 'NewOrderSingle',
        'DA': 'PartyEntitlementsDefinitionRequest',
        'DB': 'PartyEntitlementsDefinitionRequestAck',
        'DC': 'TradeMatchReport',
        'DD': 'TradeMatchReportAck',
        'DE': 'PartyRiskLimitsReportAck',
        'DF': 'PartyRiskLimitCheckRequest',
        'DG': 'PartyRiskLimitCheckRequestAck',
        'DH': 'PartyActionRequest',
        'DI': 'PartyActionReport',
        'DJ': 'MassOrder',
        'DK': 'MassOrderAck',
        'DL': 'PositionTransferInstruction',
        'DM': 'PositionTransferInstructionAck',
        'DN': 'PositionTransferReport',
        'DO': 'MarketDataStatisticsRequest',
        'DP': 'MarketDataStatisticsReport',
        'DQ': 'CollateralReportAck',
        'DR': 'MarketDataReport',
        'E': 'NewOrderList',
        'F': 'OrderCancelRequest',
        'G': 'OrderCancelReplaceRequest',
        'H': 'OrderStatusRequest',
        'J': 'AllocationInstruction',
        'K': 'ListCancelRequest',
        'L': 'ListExecute',
        'M': 'ListStatusRequest',
        'N': 'ListStatus',
        'P': 'AllocationInstructionAck',
        'Q': 'DontKnowTrade',
        'R': 'QuoteRequest',
        'S': 'Quote',
        'T': 'SettlementInstructions',
        'V': 'MarketDataRequest',
        'W': 'MarketDataSnapshotFullRefresh',
        'X': 'MarketDataIncrementalRefresh',
        'Y': 'MarketDataRequestReject',
        'Z': 'QuoteCancel',
        'a': 'QuoteStatusRequest',
        'b': 'MassQuoteAck',
        'c': 'SecurityDefinitionRequest',
        'd': 'SecurityDefinition',
        'e': 'SecurityStatusRequest',
        'f': 'SecurityStatus',
        'g': 'TradingSessionStatusRequest',
        'h': 'TradingSessionStatus',
        'i': 'MassQuote',
        'j': 'BusinessMessageReject',
        'k': 'BidRequest',
        'l': 'BidResponse',
        'm': 'ListStrikePrice',
        'n': 'XMLnonFIX',
        'o': 'RegistrationInstructions',
        'p': 'RegistrationInstructionsResponse',
        'q': 'OrderMassCancelRequest',
        'r': 'OrderMassCancelReport',
        's': 'NewOrderCross',
        't': 'CrossOrderCancelReplaceRequest',
        'u': 'CrossOrderCancelRequest',
        'v': 'SecurityTypeRequest',
        'w': 'SecurityTypes',
        'x': 'SecurityListRequest',
        'y': 'SecurityList',
        'z': 'DerivativeSecurityListRequest',
    }
    Heartbeat = '0'
    TestRequest = '1'
    ResendRequest = '2'
    Reject = '3'
    SequenceReset = '4'
    Logout = '5'
    IOI = '6'
    Advertisement = '7'
    ExecutionReport = '8'
    OrderCancelReject = '9'
    Logon = 'A'
    DerivativeSecurityList = 'AA'
    NewOrderMultileg = 'AB'
    MultilegOrderCancelReplace = 'AC'
    TradeCaptureReportRequest = 'AD'
    TradeCaptureReport = 'AE'
    OrderMassStatusRequest = 'AF'
    QuoteRequestReject = 'AG'
    RFQRequest = 'AH'
    QuoteStatusReport = 'AI'
    QuoteResponse = 'AJ'
    Confirmation = 'AK'
    PositionMaintenanceRequest = 'AL'
    PositionMaintenanceReport = 'AM'
    RequestForPositions = 'AN'
    RequestForPositionsAck = 'AO'
    PositionReport = 'AP'
    TradeCaptureReportRequestAck = 'AQ'
    TradeCaptureReportAck = 'AR'
    AllocationReport = 'AS'
    AllocationReportAck = 'AT'
    ConfirmationAck = 'AU'
    SettlementInstructionRequest = 'AV'
    AssignmentReport = 'AW'
    CollateralRequest = 'AX'
    CollateralAssignment = 'AY'
    CollateralResponse = 'AZ'
    News = 'B'
    CollateralReport = 'BA'
    CollateralInquiry = 'BB'
    NetworkCounterpartySystemStatusRequest = 'BC'
    NetworkCounterpartySystemStatusResponse = 'BD'
    UserRequest = 'BE'
    UserResponse = 'BF'
    CollateralInquiryAck = 'BG'
    ConfirmationRequest = 'BH'
    TradingSessionListRequest = 'BI'
    TradingSessionList = 'BJ'
    SecurityListUpdateReport = 'BK'
    AdjustedPositionReport = 'BL'
    AllocationInstructionAlert = 'BM'
    ExecutionAck = 'BN'
    ContraryIntentionReport = 'BO'
    SecurityDefinitionUpdateReport = 'BP'
    SettlementObligationReport = 'BQ'
    DerivativeSecurityListUpdateReport = 'BR'
    TradingSessionListUpdateReport = 'BS'
    MarketDefinitionRequest = 'BT'
    MarketDefinition = 'BU'
    MarketDefinitionUpdateReport = 'BV'
    ApplicationMessageRequest = 'BW'
    ApplicationMessageRequestAck = 'BX'
    ApplicationMessageReport = 'BY'
    OrderMassActionReport = 'BZ'
    Email = 'C'
    OrderMassActionRequest = 'CA'
    UserNotification = 'CB'
    StreamAssignmentRequest = 'CC'
    StreamAssignmentReport = 'CD'
    StreamAssignmentReportACK = 'CE'
    PartyDetailsListRequest = 'CF'
    PartyDetailsListReport = 'CG'
    MarginRequirementInquiry = 'CH'
    MarginRequirementInquiryAck = 'CI'
    MarginRequirementReport = 'CJ'
    PartyDetailsListUpdateReport = 'CK'
    PartyRiskLimitsRequest = 'CL'
    PartyRiskLimitsReport = 'CM'
    SecurityMassStatusRequest = 'CN'
    SecurityMassStatus = 'CO'
    AccountSummaryReport = 'CQ'
    PartyRiskLimitsUpdateReport = 'CR'
    PartyRiskLimitsDefinitionRequest = 'CS'
    PartyRiskLimitsDefinitionRequestAck = 'CT'
    PartyEntitlementsRequest = 'CU'
    PartyEntitlementsReport = 'CV'
    QuoteAck = 'CW'
    PartyDetailsDefinitionRequest = 'CX'
    PartyDetailsDefinitionRequestAck = 'CY'
    PartyEntitlementsUpdateReport = 'CZ'
    NewOrderSingle = 'D'
    PartyEntitlementsDefinitionRequest = 'DA'
    PartyEntitlementsDefinitionRequestAck = 'DB'
    TradeMatchReport = 'DC'
    TradeMatchReportAck = 'DD'
    PartyRiskLimitsReportAck = 'DE'
    PartyRiskLimitCheckRequest = 'DF'
    PartyRiskLimitCheckRequestAck = 'DG'
    PartyActionRequest = 'DH'
    PartyActionReport = 'DI'
    MassOrder = 'DJ'
    MassOrderAck = 'DK'
    PositionTransferInstruction = 'DL'
    PositionTransferInstructionAck = 'DM'
    PositionTransferReport = 'DN'
    MarketDataStatisticsRequest = 'DO'
    MarketDataStatisticsReport = 'DP'
    CollateralReportAck = 'DQ'
    MarketDataReport = 'DR'
    NewOrderList = 'E'
    OrderCancelRequest = 'F'
    OrderCancelReplaceRequest = 'G'
    OrderStatusRequest = 'H'
    AllocationInstruction = 'J'
    ListCancelRequest = 'K'
    ListExecute = 'L'
    ListStatusRequest = 'M'
    ListStatus = 'N'
    AllocationInstructionAck = 'P'
    DontKnowTrade = 'Q'
    QuoteRequest = 'R'
    Quote = 'S'
    SettlementInstructions = 'T'
    MarketDataRequest = 'V'
    MarketDataSnapshotFullRefresh = 'W'
    MarketDataIncrementalRefresh = 'X'
    MarketDataRequestReject = 'Y'
    QuoteCancel = 'Z'
    QuoteStatusRequest = 'a'
    MassQuoteAck = 'b'
    SecurityDefinitionRequest = 'c'
    SecurityDefinition = 'd'
    SecurityStatusRequest = 'e'
    SecurityStatus = 'f'
    TradingSessionStatusRequest = 'g'
    TradingSessionStatus = 'h'
    MassQuote = 'i'
    BusinessMessageReject = 'j'
    BidRequest = 'k'
    BidResponse = 'l'
    ListStrikePrice = 'm'
    XMLnonFIX = 'n'
    RegistrationInstructions = 'o'
    RegistrationInstructionsResponse = 'p'
    OrderMassCancelRequest = 'q'
    OrderMassCancelReport = 'r'
    NewOrderCross = 's'
    CrossOrderCancelReplaceRequest = 't'
    CrossOrderCancelRequest = 'u'
    SecurityTypeRequest = 'v'
    SecurityTypes = 'w'
    SecurityListRequest = 'x'
    SecurityList = 'y'
    DerivativeSecurityListRequest = 'z'


class ApplVerID(fix.Field, Tag="1128", Name="ApplVerID", Type=fix.FixString):
    Values = {
        '0': 'FIX27',
        '1': 'FIX30',
        '2': 'FIX40',
        '3': 'FIX41',
        '4': 'FIX42',
        '5': 'FIX43',
        '6': 'FIX44',
        '7': 'FIX50',
        '8': 'FIX50SP1',
        '9': 'FIX50SP2',
    }
    FIX27 = '0'
    FIX30 = '1'
    FIX40 = '2'
    FIX41 = '3'
    FIX42 = '4'
    FIX43 = '5'
    FIX44 = '6'
    FIX50 = '7'
    FIX50SP1 = '8'
    FIX50SP2 = '9'


class ApplExtID(fix.Field, Tag="1156", Name="ApplExtID", Type=fix.FixInt):
    Values = {
    }


class CstmApplVerID(fix.Field, Tag="1129", Name="CstmApplVerID", Type=fix.FixString):
    Values = {
    }


class SenderCompID(fix.Field, Tag="49", Name="SenderCompID", Type=fix.FixString):
    Values = {
    }


class TargetCompID(fix.Field, Tag="56", Name="TargetCompID", Type=fix.FixString):
    Values = {
    }


class OnBehalfOfCompID(fix.Field, Tag="115", Name="OnBehalfOfCompID", Type=fix.FixString):
    Values = {
    }


class DeliverToCompID(fix.Field, Tag="128", Name="DeliverToCompID", Type=fix.FixString):
    Values = {
    }


class SecureDataLen(fix.Field, Tag="90", Name="SecureDataLen", Type=fix.FixInt):
    Values = {
    }


class SecureData(fix.Field, Tag="91", Name="SecureData", Type=fix.FixString):
    Values = {
    }


class MsgSeqNum(fix.Field, Tag="34", Name="MsgSeqNum", Type=fix.FixInt):
    Values = {
    }


class SenderSubID(fix.Field, Tag="50", Name="SenderSubID", Type=fix.FixString):
    Values = {
    }


class SenderLocationID(fix.Field, Tag="142", Name="SenderLocationID", Type=fix.FixString):
    Values = {
    }


class TargetSubID(fix.Field, Tag="57", Name="TargetSubID", Type=fix.FixString):
    Values = {
    }


class TargetLocationID(fix.Field, Tag="143", Name="TargetLocationID", Type=fix.FixString):
    Values = {
    }


class OnBehalfOfSubID(fix.Field, Tag="116", Name="OnBehalfOfSubID", Type=fix.FixString):
    Values = {
    }


class OnBehalfOfLocationID(fix.Field, Tag="144", Name="OnBehalfOfLocationID", Type=fix.FixString):
    Values = {
    }


class DeliverToSubID(fix.Field, Tag="129", Name="DeliverToSubID", Type=fix.FixString):
    Values = {
    }


class DeliverToLocationID(fix.Field, Tag="145", Name="DeliverToLocationID", Type=fix.FixString):
    Values = {
    }


class PossDupFlag(fix.Field, Tag="43", Name="PossDupFlag", Type=fix.FixBool):
    Values = {
        'N': 'OriginalTransmission',
        'Y': 'PossibleDuplicate',
    }
    OriginalTransmission = 'N'
    PossibleDuplicate = 'Y'


class PossResend(fix.Field, Tag="97", Name="PossResend", Type=fix.FixBool):
    Values = {
        'N': 'OriginalTransmission',
        'Y': 'PossibleResend',
    }
    OriginalTransmission = 'N'
    PossibleResend = 'Y'


class SendingTime(fix.Field, Tag="52", Name="SendingTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class OrigSendingTime(fix.Field, Tag="122", Name="OrigSendingTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class XmlDataLen(fix.Field, Tag="212", Name="XmlDataLen", Type=fix.FixInt):
    Values = {
    }


class XmlData(fix.Field, Tag="213", Name="XmlData", Type=fix.FixString):
    Values = {
    }


class MessageEncoding(fix.Field, Tag="347", Name="MessageEncoding", Type=fix.FixString):
    Values = {
    }


class LastMsgSeqNumProcessed(fix.Field, Tag="369", Name="LastMsgSeqNumProcessed", Type=fix.FixInt):
    Values = {
    }


class NoHops(fix.Field, Tag="627", Name="NoHops", Type=fix.FixInt):
    Values = {
    }


class HopCompID(fix.Field, Tag="628", Name="HopCompID", Type=fix.FixString):
    Values = {
    }


class HopSendingTime(fix.Field, Tag="629", Name="HopSendingTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class HopRefID(fix.Field, Tag="630", Name="HopRefID", Type=fix.FixInt):
    Values = {
    }


class EncryptMethod(fix.Field, Tag="98", Name="EncryptMethod", Type=fix.FixInt):
    Values = {
        0: 'None_',
        1: 'PKCS',
        2: 'DES',
        3: 'PKCSDES',
        4: 'PGPDES',
        5: 'PGPDESMD5',
        6: 'PEM',
    }
    None_ = 0
    PKCS = 1
    DES = 2
    PKCSDES = 3
    PGPDES = 4
    PGPDESMD5 = 5
    PEM = 6


class HeartBtInt(fix.Field, Tag="108", Name="HeartBtInt", Type=fix.FixInt):
    Values = {
    }


class RawDataLength(fix.Field, Tag="95", Name="RawDataLength", Type=fix.FixInt):
    Values = {
    }


class RawData(fix.Field, Tag="96", Name="RawData", Type=fix.FixString):
    Values = {
    }


class ResetSeqNumFlag(fix.Field, Tag="141", Name="ResetSeqNumFlag", Type=fix.FixBool):
    Values = {
        'N': 'No',
        'Y': 'Yes',
    }
    No = 'N'
    Yes = 'Y'


class NextExpectedMsgSeqNum(fix.Field, Tag="789", Name="NextExpectedMsgSeqNum", Type=fix.FixInt):
    Values = {
    }


class MaxMessageSize(fix.Field, Tag="383", Name="MaxMessageSize", Type=fix.FixInt):
    Values = {
    }


class NoMsgTypes(fix.Field, Tag="384", Name="NoMsgTypes", Type=fix.FixInt):
    Values = {
    }


class RefMsgType(fix.Field, Tag="372", Name="RefMsgType", Type=fix.FixString):
    Values = {
        '0': 'Heartbeat',
        '1': 'TestRequest',
        '2': 'ResendRequest',
        '3': 'Reject',
        '4': 'SequenceReset',
        '5': 'Logout',
        '6': 'IOI',
        '7': 'Advertisement',
        '8': 'ExecutionReport',
        '9': 'OrderCancelReject',
        'A': 'Logon',
        'AA': 'DerivativeSecurityList',
        'AB': 'NewOrderMultileg',
        'AC': 'MultilegOrderCancelReplace',
        'AD': 'TradeCaptureReportRequest',
        'AE': 'TradeCaptureReport',
        'AF': 'OrderMassStatusRequest',
        'AG': 'QuoteRequestReject',
        'AH': 'RFQRequest',
        'AI': 'QuoteStatusReport',
        'AJ': 'QuoteResponse',
        'AK': 'Confirmation',
        'AL': 'PositionMaintenanceRequest',
        'AM': 'PositionMaintenanceReport',
        'AN': 'RequestForPositions',
        'AO': 'RequestForPositionsAck',
        'AP': 'PositionReport',
        'AQ': 'TradeCaptureReportRequestAck',
        'AR': 'TradeCaptureReportAck',
        'AS': 'AllocationReport',
        'AT': 'AllocationReportAck',
        'AU': 'ConfirmationAck',
        'AV': 'SettlementInstructionRequest',
        'AW': 'AssignmentReport',
        'AX': 'CollateralRequest',
        'AY': 'CollateralAssignment',
        'AZ': 'CollateralResponse',
        'B': 'News',
        'BA': 'CollateralReport',
        'BB': 'CollateralInquiry',
        'BC': 'NetworkCounterpartySystemStatusRequest',
        'BD': 'NetworkCounterpartySystemStatusResponse',
        'BE': 'UserRequest',
        'BF': 'UserResponse',
        'BG': 'CollateralInquiryAck',
        'BH': 'ConfirmationRequest',
        'BI': 'TradingSessionListRequest',
        'BJ': 'TradingSessionList',
        'BK': 'SecurityListUpdateReport',
        'BL': 'AdjustedPositionReport',
        'BM': 'AllocationInstructionAlert',
        'BN': 'ExecutionAck',
        'BO': 'ContraryIntentionReport',
        'BP': 'SecurityDefinitionUpdateReport',
        'BQ': 'SettlementObligationReport',
        'BR': 'DerivativeSecurityListUpdateReport',
        'BS': 'TradingSessionListUpdateReport',
        'BT': 'MarketDefinitionRequest',
        'BU': 'MarketDefinition',
        'BV': 'MarketDefinitionUpdateReport',
        'BW': 'ApplicationMessageRequest',
        'BX': 'ApplicationMessageRequestAck',
        'BY': 'ApplicationMessageReport',
        'BZ': 'OrderMassActionReport',
        'C': 'Email',
        'CA': 'OrderMassActionRequest',
        'CB': 'UserNotification',
        'CC': 'StreamAssignmentRequest',
        'CD': 'StreamAssignmentReport',
        'CE': 'StreamAssignmentReportACK',
        'CF': 'PartyDetailsListRequest',
        'CG': 'PartyDetailsListReport',
        'CH': 'MarginRequirementInquiry',
        'CI': 'MarginRequirementInquiryAck',
        'CJ': 'MarginRequirementReport',
        'CK': 'PartyDetailsListUpdateReport',
        'CL': 'PartyRiskLimitsRequest',
        'CM': 'PartyRiskLimitsReport',
        'CN': 'SecurityMassStatusRequest',
        'CO': 'SecurityMassStatus',
        'CQ': 'AccountSummaryReport',
        'CR': 'PartyRiskLimitsUpdateReport',
        'CS': 'PartyRiskLimitsDefinitionRequest',
        'CT': 'PartyRiskLimitsDefinitionRequestAck',
        'CU': 'PartyEntitlementsRequest',
        'CV': 'PartyEntitlementsReport',
        'CW': 'QuoteAck',
        'CX': 'PartyDetailsDefinitionRequest',
        'CY': 'PartyDetailsDefinitionRequestAck',
        'CZ': 'PartyEntitlementsUpdateReport',
        'D': 'NewOrderSingle',
        'DA': 'PartyEntitlementsDefinitionRequest',
        'DB': 'PartyEntitlementsDefinitionRequestAck',
        'DC': 'TradeMatchReport',
        'DD': 'TradeMatchReportAck',
        'DE': 'PartyRiskLimitsReportAck',
        'DF': 'PartyRiskLimitCheckRequest',
        'DG': 'PartyRiskLimitCheckRequestAck',
        'DH': 'PartyActionRequest',
        'DI': 'PartyActionReport',
        'DJ': 'MassOrder',
        'DK': 'MassOrderAck',
        'DL': 'PositionTransferInstruction',
        'DM': 'PositionTransferInstructionAck',
        'DN': 'PositionTransferReport',
        'DO': 'MarketDataStatisticsRequest',
        'DP': 'MarketDataStatisticsReport',
        'DQ': 'CollateralReportAck',
        'DR': 'MarketDataReport',
        'E': 'NewOrderList',
        'F': 'OrderCancelRequest',
        'G': 'OrderCancelReplaceRequest',
        'H': 'OrderStatusRequest',
        'J': 'AllocationInstruction',
        'K': 'ListCancelRequest',
        'L': 'ListExecute',
        'M': 'ListStatusRequest',
        'N': 'ListStatus',
        'P': 'AllocationInstructionAck',
        'Q': 'DontKnowTrade',
        'R': 'QuoteRequest',
        'S': 'Quote',
        'T': 'SettlementInstructions',
        'V': 'MarketDataRequest',
        'W': 'MarketDataSnapshotFullRefresh',
        'X': 'MarketDataIncrementalRefresh',
        'Y': 'MarketDataRequestReject',
        'Z': 'QuoteCancel',
        'a': 'QuoteStatusRequest',
        'b': 'MassQuoteAck',
        'c': 'SecurityDefinitionRequest',
        'd': 'SecurityDefinition',
        'e': 'SecurityStatusRequest',
        'f': 'SecurityStatus',
        'g': 'TradingSessionStatusRequest',
        'h': 'TradingSessionStatus',
        'i': 'MassQuote',
        'j': 'BusinessMessageReject',
        'k': 'BidRequest',
        'l': 'BidResponse',
        'm': 'ListStrikePrice',
        'n': 'XMLnonFIX',
        'o': 'RegistrationInstructions',
        'p': 'RegistrationInstructionsResponse',
        'q': 'OrderMassCancelRequest',
        'r': 'OrderMassCancelReport',
        's': 'NewOrderCross',
        't': 'CrossOrderCancelReplaceRequest',
        'u': 'CrossOrderCancelRequest',
        'v': 'SecurityTypeRequest',
        'w': 'SecurityTypes',
        'x': 'SecurityListRequest',
        'y': 'SecurityList',
        'z': 'DerivativeSecurityListRequest',
    }
    Heartbeat = '0'
    TestRequest = '1'
    ResendRequest = '2'
    Reject = '3'
    SequenceReset = '4'
    Logout = '5'
    IOI = '6'
    Advertisement = '7'
    ExecutionReport = '8'
    OrderCancelReject = '9'
    Logon = 'A'
    DerivativeSecurityList = 'AA'
    NewOrderMultileg = 'AB'
    MultilegOrderCancelReplace = 'AC'
    TradeCaptureReportRequest = 'AD'
    TradeCaptureReport = 'AE'
    OrderMassStatusRequest = 'AF'
    QuoteRequestReject = 'AG'
    RFQRequest = 'AH'
    QuoteStatusReport = 'AI'
    QuoteResponse = 'AJ'
    Confirmation = 'AK'
    PositionMaintenanceRequest = 'AL'
    PositionMaintenanceReport = 'AM'
    RequestForPositions = 'AN'
    RequestForPositionsAck = 'AO'
    PositionReport = 'AP'
    TradeCaptureReportRequestAck = 'AQ'
    TradeCaptureReportAck = 'AR'
    AllocationReport = 'AS'
    AllocationReportAck = 'AT'
    ConfirmationAck = 'AU'
    SettlementInstructionRequest = 'AV'
    AssignmentReport = 'AW'
    CollateralRequest = 'AX'
    CollateralAssignment = 'AY'
    CollateralResponse = 'AZ'
    News = 'B'
    CollateralReport = 'BA'
    CollateralInquiry = 'BB'
    NetworkCounterpartySystemStatusRequest = 'BC'
    NetworkCounterpartySystemStatusResponse = 'BD'
    UserRequest = 'BE'
    UserResponse = 'BF'
    CollateralInquiryAck = 'BG'
    ConfirmationRequest = 'BH'
    TradingSessionListRequest = 'BI'
    TradingSessionList = 'BJ'
    SecurityListUpdateReport = 'BK'
    AdjustedPositionReport = 'BL'
    AllocationInstructionAlert = 'BM'
    ExecutionAck = 'BN'
    ContraryIntentionReport = 'BO'
    SecurityDefinitionUpdateReport = 'BP'
    SettlementObligationReport = 'BQ'
    DerivativeSecurityListUpdateReport = 'BR'
    TradingSessionListUpdateReport = 'BS'
    MarketDefinitionRequest = 'BT'
    MarketDefinition = 'BU'
    MarketDefinitionUpdateReport = 'BV'
    ApplicationMessageRequest = 'BW'
    ApplicationMessageRequestAck = 'BX'
    ApplicationMessageReport = 'BY'
    OrderMassActionReport = 'BZ'
    Email = 'C'
    OrderMassActionRequest = 'CA'
    UserNotification = 'CB'
    StreamAssignmentRequest = 'CC'
    StreamAssignmentReport = 'CD'
    StreamAssignmentReportACK = 'CE'
    PartyDetailsListRequest = 'CF'
    PartyDetailsListReport = 'CG'
    MarginRequirementInquiry = 'CH'
    MarginRequirementInquiryAck = 'CI'
    MarginRequirementReport = 'CJ'
    PartyDetailsListUpdateReport = 'CK'
    PartyRiskLimitsRequest = 'CL'
    PartyRiskLimitsReport = 'CM'
    SecurityMassStatusRequest = 'CN'
    SecurityMassStatus = 'CO'
    AccountSummaryReport = 'CQ'
    PartyRiskLimitsUpdateReport = 'CR'
    PartyRiskLimitsDefinitionRequest = 'CS'
    PartyRiskLimitsDefinitionRequestAck = 'CT'
    PartyEntitlementsRequest = 'CU'
    PartyEntitlementsReport = 'CV'
    QuoteAck = 'CW'
    PartyDetailsDefinitionRequest = 'CX'
    PartyDetailsDefinitionRequestAck = 'CY'
    PartyEntitlementsUpdateReport = 'CZ'
    NewOrderSingle = 'D'
    PartyEntitlementsDefinitionRequest = 'DA'
    PartyEntitlementsDefinitionRequestAck = 'DB'
    TradeMatchReport = 'DC'
    TradeMatchReportAck = 'DD'
    PartyRiskLimitsReportAck = 'DE'
    PartyRiskLimitCheckRequest = 'DF'
    PartyRiskLimitCheckRequestAck = 'DG'
    PartyActionRequest = 'DH'
    PartyActionReport = 'DI'
    MassOrder = 'DJ'
    MassOrderAck = 'DK'
    PositionTransferInstruction = 'DL'
    PositionTransferInstructionAck = 'DM'
    PositionTransferReport = 'DN'
    MarketDataStatisticsRequest = 'DO'
    MarketDataStatisticsReport = 'DP'
    CollateralReportAck = 'DQ'
    MarketDataReport = 'DR'
    NewOrderList = 'E'
    OrderCancelRequest = 'F'
    OrderCancelReplaceRequest = 'G'
    OrderStatusRequest = 'H'
    AllocationInstruction = 'J'
    ListCancelRequest = 'K'
    ListExecute = 'L'
    ListStatusRequest = 'M'
    ListStatus = 'N'
    AllocationInstructionAck = 'P'
    DontKnowTrade = 'Q'
    QuoteRequest = 'R'
    Quote = 'S'
    SettlementInstructions = 'T'
    MarketDataRequest = 'V'
    MarketDataSnapshotFullRefresh = 'W'
    MarketDataIncrementalRefresh = 'X'
    MarketDataRequestReject = 'Y'
    QuoteCancel = 'Z'
    QuoteStatusRequest = 'a'
    MassQuoteAck = 'b'
    SecurityDefinitionRequest = 'c'
    SecurityDefinition = 'd'
    SecurityStatusRequest = 'e'
    SecurityStatus = 'f'
    TradingSessionStatusRequest = 'g'
    TradingSessionStatus = 'h'
    MassQuote = 'i'
    BusinessMessageReject = 'j'
    BidRequest = 'k'
    BidResponse = 'l'
    ListStrikePrice = 'm'
    XMLnonFIX = 'n'
    RegistrationInstructions = 'o'
    RegistrationInstructionsResponse = 'p'
    OrderMassCancelRequest = 'q'
    OrderMassCancelReport = 'r'
    NewOrderCross = 's'
    CrossOrderCancelReplaceRequest = 't'
    CrossOrderCancelRequest = 'u'
    SecurityTypeRequest = 'v'
    SecurityTypes = 'w'
    SecurityListRequest = 'x'
    SecurityList = 'y'
    DerivativeSecurityListRequest = 'z'


class MsgDirection(fix.Field, Tag="385", Name="MsgDirection", Type=fix.FixChar):
    Values = {
        'R': 'Receive',
        'S': 'Send',
    }
    Receive = 'R'
    Send = 'S'


class RefApplVerID(fix.Field, Tag="1130", Name="RefApplVerID", Type=fix.FixString):
    Values = {
        '0': 'FIX27',
        '1': 'FIX30',
        '2': 'FIX40',
        '3': 'FIX41',
        '4': 'FIX42',
        '5': 'FIX43',
        '6': 'FIX44',
        '7': 'FIX50',
        '8': 'FIX50SP1',
        '9': 'FIX50SP2',
    }
    FIX27 = '0'
    FIX30 = '1'
    FIX40 = '2'
    FIX41 = '3'
    FIX42 = '4'
    FIX43 = '5'
    FIX44 = '6'
    FIX50 = '7'
    FIX50SP1 = '8'
    FIX50SP2 = '9'


class RefApplExtID(fix.Field, Tag="1406", Name="RefApplExtID", Type=fix.FixInt):
    Values = {
    }


class RefCstmApplVerID(fix.Field, Tag="1131", Name="RefCstmApplVerID", Type=fix.FixString):
    Values = {
    }


class DefaultVerIndicator(fix.Field, Tag="1410", Name="DefaultVerIndicator", Type=fix.FixBool):
    Values = {
    }


class TestMessageIndicator(fix.Field, Tag="464", Name="TestMessageIndicator", Type=fix.FixBool):
    Values = {
        'N': 'False_',
        'Y': 'True_',
    }
    False_ = 'N'
    True_ = 'Y'


class Username(fix.Field, Tag="553", Name="Username", Type=fix.FixString):
    Values = {
    }


class Password(fix.Field, Tag="554", Name="Password", Type=fix.FixString):
    Values = {
    }


class NewPassword(fix.Field, Tag="925", Name="NewPassword", Type=fix.FixString):
    Values = {
    }


class EncryptedPasswordMethod(fix.Field, Tag="1400", Name="EncryptedPasswordMethod", Type=fix.FixInt):
    Values = {
    }


class EncryptedPasswordLen(fix.Field, Tag="1401", Name="EncryptedPasswordLen", Type=fix.FixInt):
    Values = {
    }


class EncryptedPassword(fix.Field, Tag="1402", Name="EncryptedPassword", Type=fix.FixString):
    Values = {
    }


class EncryptedNewPasswordLen(fix.Field, Tag="1403", Name="EncryptedNewPasswordLen", Type=fix.FixInt):
    Values = {
    }


class EncryptedNewPassword(fix.Field, Tag="1404", Name="EncryptedNewPassword", Type=fix.FixString):
    Values = {
    }


class SessionStatus(fix.Field, Tag="1409", Name="SessionStatus", Type=fix.FixInt):
    Values = {
        0: 'SessionActive',
        1: 'SessionPasswordChanged',
        10: 'ReceivedNextExpectedMsgSeqNumTooHigh',
        101: 'Heartbeatintervaltoolow',
        102: 'ServersideLogonRequestduetoSessionReset',
        103: 'Usercredentialscouldnotbeauthenticated',
        2: 'SessionPasswordDueToExpire',
        3: 'NewSessionPasswordDoesNotComplyWithPolicy',
        4: 'SessionLogoutComplete',
        5: 'InvalidUsernameOrPassword',
        6: 'AccountLocked',
        7: 'LogonsAreNotAllowedAtThisTime',
        8: 'PasswordExpired',
        9: 'ReceivedMsgSeqNumTooLow',
    }
    SessionActive = 0
    SessionPasswordChanged = 1
    ReceivedNextExpectedMsgSeqNumTooHigh = 10
    Heartbeatintervaltoolow = 101
    ServersideLogonRequestduetoSessionReset = 102
    Usercredentialscouldnotbeauthenticated = 103
    SessionPasswordDueToExpire = 2
    NewSessionPasswordDoesNotComplyWithPolicy = 3
    SessionLogoutComplete = 4
    InvalidUsernameOrPassword = 5
    AccountLocked = 6
    LogonsAreNotAllowedAtThisTime = 7
    PasswordExpired = 8
    ReceivedMsgSeqNumTooLow = 9


class DefaultApplVerID(fix.Field, Tag="1137", Name="DefaultApplVerID", Type=fix.FixString):
    Values = {
        '0': 'FIX27',
        '1': 'FIX30',
        '2': 'FIX40',
        '3': 'FIX41',
        '4': 'FIX42',
        '5': 'FIX43',
        '6': 'FIX44',
        '7': 'FIX50',
        '8': 'FIX50SP1',
        '9': 'FIX50SP2',
    }
    FIX27 = '0'
    FIX30 = '1'
    FIX40 = '2'
    FIX41 = '3'
    FIX42 = '4'
    FIX43 = '5'
    FIX44 = '6'
    FIX50 = '7'
    FIX50SP1 = '8'
    FIX50SP2 = '9'


class DefaultApplExtID(fix.Field, Tag="1407", Name="DefaultApplExtID", Type=fix.FixInt):
    Values = {
    }


class DefaultCstmApplVerID(fix.Field, Tag="1408", Name="DefaultCstmApplVerID", Type=fix.FixString):
    Values = {
    }


class Text(fix.Field, Tag="58", Name="Text", Type=fix.FixString):
    Values = {
    }


class EncodedTextLen(fix.Field, Tag="354", Name="EncodedTextLen", Type=fix.FixInt):
    Values = {
    }


class EncodedText(fix.Field, Tag="355", Name="EncodedText", Type=fix.FixString):
    Values = {
    }


class SignatureLength(fix.Field, Tag="93", Name="SignatureLength", Type=fix.FixInt):
    Values = {
    }


class Signature(fix.Field, Tag="89", Name="Signature", Type=fix.FixString):
    Values = {
    }


class CheckSum(fix.Field, Tag="10", Name="CheckSum", Type=fix.FixString):
    Values = {
    }


class NewsID(fix.Field, Tag="1472", Name="NewsID", Type=fix.FixString):
    Values = {
    }


class NoNewsRefIDs(fix.Field, Tag="1475", Name="NoNewsRefIDs", Type=fix.FixInt):
    Values = {
    }


class NewsRefID(fix.Field, Tag="1476", Name="NewsRefID", Type=fix.FixString):
    Values = {
    }


class NewsCategory(fix.Field, Tag="1473", Name="NewsCategory", Type=fix.FixInt):
    Values = {
        0: 'CompanyNews',
        1: 'MarketplaceNews',
        101: 'BarrierNewsEndOfBusiness',
        2: 'FinancialMarketNews',
        3: 'TechnicalNews',
        99: 'OtherNews',
    }
    CompanyNews = 0
    MarketplaceNews = 1
    BarrierNewsEndOfBusiness = 101
    FinancialMarketNews = 2
    TechnicalNews = 3
    OtherNews = 99


class OrigTime(fix.Field, Tag="42", Name="OrigTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class Urgency(fix.Field, Tag="61", Name="Urgency", Type=fix.FixChar):
    Values = {
        '0': 'Normal',
        '1': 'Flash',
        '2': 'Background',
    }
    Normal = '0'
    Flash = '1'
    Background = '2'


class Headline(fix.Field, Tag="148", Name="Headline", Type=fix.FixString):
    Values = {
    }


class NoRoutingIDs(fix.Field, Tag="215", Name="NoRoutingIDs", Type=fix.FixInt):
    Values = {
    }


class MarketID(fix.Field, Tag="1301", Name="MarketID", Type=fix.FixExchange):
    Values = {
    }


class MarketSegmentID(fix.Field, Tag="1300", Name="MarketSegmentID", Type=fix.FixString):
    Values = {
    }


class NoRelatedSym(fix.Field, Tag="146", Name="NoRelatedSym", Type=fix.FixInt):
    Values = {
    }


class Symbol(fix.Field, Tag="55", Name="Symbol", Type=fix.FixString):
    Values = {
    }


class SymbolSfx(fix.Field, Tag="65", Name="SymbolSfx", Type=fix.FixString):
    Values = {
        'CD': 'EUCPWithLumpSumInterest',
        'WI': 'WhenIssued',
    }
    EUCPWithLumpSumInterest = 'CD'
    WhenIssued = 'WI'


class SecurityID(fix.Field, Tag="48", Name="SecurityID", Type=fix.FixString):
    Values = {
    }


class SecurityIDSource(fix.Field, Tag="22", Name="SecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class NoSecurityAltID(fix.Field, Tag="454", Name="NoSecurityAltID", Type=fix.FixInt):
    Values = {
    }


class SecurityAltID(fix.Field, Tag="455", Name="SecurityAltID", Type=fix.FixString):
    Values = {
    }


class SecurityAltIDSource(fix.Field, Tag="456", Name="SecurityAltIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class Product(fix.Field, Tag="460", Name="Product", Type=fix.FixInt):
    Values = {
        1: 'AGENCY',
        10: 'MORTGAGE',
        11: 'MUNICIPAL',
        12: 'OTHER',
        13: 'FINANCING',
        2: 'COMMODITY',
        3: 'CORPORATE',
        4: 'CURRENCY',
        5: 'EQUITY',
        6: 'GOVERNMENT',
        7: 'INDEX',
        8: 'LOAN',
        9: 'MONEYMARKET',
    }
    AGENCY = 1
    MORTGAGE = 10
    MUNICIPAL = 11
    OTHER = 12
    FINANCING = 13
    COMMODITY = 2
    CORPORATE = 3
    CURRENCY = 4
    EQUITY = 5
    GOVERNMENT = 6
    INDEX = 7
    LOAN = 8
    MONEYMARKET = 9


class CFICode(fix.Field, Tag="461", Name="CFICode", Type=fix.FixString):
    Values = {
    }


class SecurityType(fix.Field, Tag="167", Name="SecurityType", Type=fix.FixString):
    Values = {
        '?': 'Wildcard',
        'ABS': 'AssetBackedSecurities',
        'AMENDED': 'Amended',
        'AN': 'OtherAnticipationNotes',
        'BA': 'BankersAcceptance',
        'BDN': 'BankDepositoryNote',
        'BN': 'BankNotes',
        'BOX': 'BillOfExchanges',
        'BRADY': 'BradyBond',
        'BRIDGE': 'BridgeLoan',
        'BUYSELL': 'BuySellback',
        'CAMM': 'CanadianMoneyMarkets',
        'CAN': 'CanadianTreasuryNotes',
        'CAP': 'Cap',
        'CASH': 'Cash',
        'CB': 'ConvertibleBond',
        'CD': 'CertificateOfDeposit',
        'CDS': 'CreditDefaultSwap',
        'CL': 'CallLoans',
        'CLLR': 'Collar',
        'CMB': 'CanadianMortgageBonds',
        'CMBS': 'Corp',
        'CMDTYSWAP': 'CommoditySwap',
        'CMO': 'CollateralizedMortgageObligation',
        'COFO': 'CertificateOfObligation',
        'COFP': 'CertificateOfParticipation',
        'COLLBSKT': 'CollateralBasket',
        'CORP': 'CorporateBond',
        'CP': 'CommercialPaper',
        'CPP': 'CorporatePrivatePlacement',
        'CS': 'CommonStock',
        'CTB': 'CanadianTreasuryBills',
        'DEFLTED': 'Defaulted',
        'DINP': 'DebtorInPossession',
        'DN': 'DepositNotes',
        'DUAL': 'DualCurrency',
        'DVPLDG': 'DeliveryVersusPledge',
        'EUCD': 'EuroCertificateOfDeposit',
        'EUCORP': 'EuroCorporateBond',
        'EUCP': 'EuroCommercialPaper',
        'EUFRN': 'EuroCorporateFloatingRateNotes',
        'EUSOV': 'EuroSovereigns',
        'EUSUPRA': 'EuroSupranationalCoupons',
        'EXOTIC': 'Exotic',
        'FAC': 'FederalAgencyCoupon',
        'FADN': 'FederalAgencyDiscountNote',
        'FLR': 'Floor',
        'FOR': 'ForeignExchangeContract',
        'FORWARD': 'Forward',
        'FRA': 'FRA',
        'FRN': 'USCorporateFloatingRateNotes',
        'FUT': 'Futures',
        'FWD': 'DerivativeForward',
        'FXFWD': 'FXForward',
        'FXNDF': 'NonDeliverableForward',
        'FXSPOT': 'FXSpot',
        'FXSWAP': 'FXSwap',
        'GO': 'GeneralObligationBonds',
        'IET': 'IOETTEMortgage',
        'INDEX': 'Index',
        'IRS': 'InterestRateSwap',
        'LOANLEASE': 'LoanLease',
        'LOFC': 'LetterOfCredit',
        'LQN': 'LiquidityNote',
        'MATURED': 'Matured',
        'MBS': 'MortgageBackedSecurities',
        'MF': 'MutualFund',
        'MIO': 'MortgageInterestOnly',
        'MLEG': 'MultilegInstrument',
        'MPO': 'MortgagePrincipalOnly',
        'MPP': 'MortgagePrivatePlacement',
        'MPT': 'MiscellaneousPassThrough',
        'MT': 'MandatoryTender',
        'MTN': 'MediumTermNotes',
        'NONE': 'NoSecurityType',
        'ONITE': 'Overnight',
        'OOC': 'OptionsOnCombo',
        'OOF': 'Options',
        'OOP': 'OptionsOnPhysical',
        'OPT': 'Option',
        'OTHER': 'Other',
        'PEF': 'PrivateExportFunding',
        'PFAND': 'Pfandbriefe',
        'PN': 'PromissoryNote',
        'PROV': 'CanadianProvincialBonds',
        'PS': 'PreferredStock',
        'PZFJ': 'PlazosFijos',
        'RAN': 'RevenueAnticipationNote',
        'REPLACD': 'Replaced',
        'REPO': 'Repurchase',
        'RETIRED': 'Retired',
        'REV': 'RevenueBonds',
        'RVLV': 'RevolverLoan',
        'RVLVTRM': 'Revolver',
        'SECLOAN': 'SecuritiesLoan',
        'SECPLEDGE': 'SecuritiesPledge',
        'SLQN': 'SecuredLiquidityNote',
        'SPCLA': 'SpecialAssessment',
        'SPCLO': 'SpecialObligation',
        'SPCLT': 'SpecialTax',
        'SPOTFWD': 'SpotForward',
        'STN': 'ShortTermLoanNote',
        'STRUCT': 'StructuredNotes',
        'SUPRA': 'USDSupranationalCoupons',
        'SWAPTION': 'SwapOption',
        'SWING': 'SwingLineFacility',
        'TAN': 'TaxAnticipationNote',
        'TAXA': 'TaxAllocation',
        'TB': 'TreasuryBill',
        'TBA': 'ToBeAnnounced',
        'TBILL': 'USTreasuryBill',
        'TBOND': 'USTreasuryBond',
        'TCAL': 'PrincipalStripOfACallableBondOrNote',
        'TD': 'TimeDeposit',
        'TECP': 'TaxExemptCommercialPaper',
        'TERM': 'TermLoan',
        'TINT': 'InterestStripFromAnyBondOrNote',
        'TIPS': 'TreasuryInflationProtectedSecurities',
        'TLQN': 'TermLiquidityNote',
        'TMCP': 'TaxableMunicipalCP',
        'TNOTE': 'USTreasuryNote',
        'TPRN': 'PrincipalStripFromANonCallableBondOrNote',
        'TRAN': 'TaxRevenueAnticipationNote',
        'TRS': 'TotalReturnSwap',
        'UST': 'USTreasuryNoteDeprecatedValueUseTNOTE',
        'USTB': 'USTreasuryBillDeprecatedValueUseTBILL',
        'VRDN': 'VariableRateDemandNote',
        'WAR': 'Warrant',
        'WITHDRN': 'Withdrawn',
        'XCN': 'ExtendedCommNote',
        'XLINKD': 'IndexedLinked',
        'XMISSION': 'Transmission',
        'YANK': 'YankeeCorporateBond',
        'YCD': 'YankeeCertificateOfDeposit',
    }
    Wildcard = '?'
    AssetBackedSecurities = 'ABS'
    Amended = 'AMENDED'
    OtherAnticipationNotes = 'AN'
    BankersAcceptance = 'BA'
    BankDepositoryNote = 'BDN'
    BankNotes = 'BN'
    BillOfExchanges = 'BOX'
    BradyBond = 'BRADY'
    BridgeLoan = 'BRIDGE'
    BuySellback = 'BUYSELL'
    CanadianMoneyMarkets = 'CAMM'
    CanadianTreasuryNotes = 'CAN'
    Cap = 'CAP'
    Cash = 'CASH'
    ConvertibleBond = 'CB'
    CertificateOfDeposit = 'CD'
    CreditDefaultSwap = 'CDS'
    CallLoans = 'CL'
    Collar = 'CLLR'
    CanadianMortgageBonds = 'CMB'
    Corp = 'CMBS'
    CommoditySwap = 'CMDTYSWAP'
    CollateralizedMortgageObligation = 'CMO'
    CertificateOfObligation = 'COFO'
    CertificateOfParticipation = 'COFP'
    CollateralBasket = 'COLLBSKT'
    CorporateBond = 'CORP'
    CommercialPaper = 'CP'
    CorporatePrivatePlacement = 'CPP'
    CommonStock = 'CS'
    CanadianTreasuryBills = 'CTB'
    Defaulted = 'DEFLTED'
    DebtorInPossession = 'DINP'
    DepositNotes = 'DN'
    DualCurrency = 'DUAL'
    DeliveryVersusPledge = 'DVPLDG'
    EuroCertificateOfDeposit = 'EUCD'
    EuroCorporateBond = 'EUCORP'
    EuroCommercialPaper = 'EUCP'
    EuroCorporateFloatingRateNotes = 'EUFRN'
    EuroSovereigns = 'EUSOV'
    EuroSupranationalCoupons = 'EUSUPRA'
    Exotic = 'EXOTIC'
    FederalAgencyCoupon = 'FAC'
    FederalAgencyDiscountNote = 'FADN'
    Floor = 'FLR'
    ForeignExchangeContract = 'FOR'
    Forward = 'FORWARD'
    FRA = 'FRA'
    USCorporateFloatingRateNotes = 'FRN'
    Futures = 'FUT'
    DerivativeForward = 'FWD'
    FXForward = 'FXFWD'
    NonDeliverableForward = 'FXNDF'
    FXSpot = 'FXSPOT'
    FXSwap = 'FXSWAP'
    GeneralObligationBonds = 'GO'
    IOETTEMortgage = 'IET'
    Index = 'INDEX'
    InterestRateSwap = 'IRS'
    LoanLease = 'LOANLEASE'
    LetterOfCredit = 'LOFC'
    LiquidityNote = 'LQN'
    Matured = 'MATURED'
    MortgageBackedSecurities = 'MBS'
    MutualFund = 'MF'
    MortgageInterestOnly = 'MIO'
    MultilegInstrument = 'MLEG'
    MortgagePrincipalOnly = 'MPO'
    MortgagePrivatePlacement = 'MPP'
    MiscellaneousPassThrough = 'MPT'
    MandatoryTender = 'MT'
    MediumTermNotes = 'MTN'
    NoSecurityType = 'NONE'
    Overnight = 'ONITE'
    OptionsOnCombo = 'OOC'
    Options = 'OOF'
    OptionsOnPhysical = 'OOP'
    Option = 'OPT'
    Other = 'OTHER'
    PrivateExportFunding = 'PEF'
    Pfandbriefe = 'PFAND'
    PromissoryNote = 'PN'
    CanadianProvincialBonds = 'PROV'
    PreferredStock = 'PS'
    PlazosFijos = 'PZFJ'
    RevenueAnticipationNote = 'RAN'
    Replaced = 'REPLACD'
    Repurchase = 'REPO'
    Retired = 'RETIRED'
    RevenueBonds = 'REV'
    RevolverLoan = 'RVLV'
    Revolver = 'RVLVTRM'
    SecuritiesLoan = 'SECLOAN'
    SecuritiesPledge = 'SECPLEDGE'
    SecuredLiquidityNote = 'SLQN'
    SpecialAssessment = 'SPCLA'
    SpecialObligation = 'SPCLO'
    SpecialTax = 'SPCLT'
    SpotForward = 'SPOTFWD'
    ShortTermLoanNote = 'STN'
    StructuredNotes = 'STRUCT'
    USDSupranationalCoupons = 'SUPRA'
    SwapOption = 'SWAPTION'
    SwingLineFacility = 'SWING'
    TaxAnticipationNote = 'TAN'
    TaxAllocation = 'TAXA'
    TreasuryBill = 'TB'
    ToBeAnnounced = 'TBA'
    USTreasuryBill = 'TBILL'
    USTreasuryBond = 'TBOND'
    PrincipalStripOfACallableBondOrNote = 'TCAL'
    TimeDeposit = 'TD'
    TaxExemptCommercialPaper = 'TECP'
    TermLoan = 'TERM'
    InterestStripFromAnyBondOrNote = 'TINT'
    TreasuryInflationProtectedSecurities = 'TIPS'
    TermLiquidityNote = 'TLQN'
    TaxableMunicipalCP = 'TMCP'
    USTreasuryNote = 'TNOTE'
    PrincipalStripFromANonCallableBondOrNote = 'TPRN'
    TaxRevenueAnticipationNote = 'TRAN'
    TotalReturnSwap = 'TRS'
    USTreasuryNoteDeprecatedValueUseTNOTE = 'UST'
    USTreasuryBillDeprecatedValueUseTBILL = 'USTB'
    VariableRateDemandNote = 'VRDN'
    Warrant = 'WAR'
    Withdrawn = 'WITHDRN'
    ExtendedCommNote = 'XCN'
    IndexedLinked = 'XLINKD'
    Transmission = 'XMISSION'
    YankeeCorporateBond = 'YANK'
    YankeeCertificateOfDeposit = 'YCD'


class SecuritySubType(fix.Field, Tag="762", Name="SecuritySubType", Type=fix.FixString):
    Values = {
    }


class MaturityDate(fix.Field, Tag="541", Name="MaturityDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class MaturityTime(fix.Field, Tag="1079", Name="MaturityTime", Type=fix.FixTzTimeonly):
    Values = {
    }


class SecurityStatus(fix.Field, Tag="965", Name="SecurityStatus", Type=fix.FixString):
    Values = {
        '1': 'Active',
        '10': 'Published',
        '11': 'PendingDeletion',
        '2': 'Inactive',
        '3': 'ActiveClosingOrdersOnly',
        '4': 'Expired',
        '5': 'Delisted',
        '6': 'KnockedOut',
        '7': 'KnockOutRevoked',
        '8': 'PendingExpiry',
        '9': 'Suspended',
    }
    Active = '1'
    Published = '10'
    PendingDeletion = '11'
    Inactive = '2'
    ActiveClosingOrdersOnly = '3'
    Expired = '4'
    Delisted = '5'
    KnockedOut = '6'
    KnockOutRevoked = '7'
    PendingExpiry = '8'
    Suspended = '9'


class CouponPaymentDate(fix.Field, Tag="224", Name="CouponPaymentDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class NoSecondaryAssetClasses(fix.Field, Tag="1976", Name="NoSecondaryAssetClasses", Type=fix.FixInt):
    Values = {
    }


class NoAssetAttributes(fix.Field, Tag="2304", Name="NoAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class CouponDayCount(fix.Field, Tag="1950", Name="CouponDayCount", Type=fix.FixInt):
    Values = {
        0: 'OneOne',
        1: 'ThrityThreeSixtyUS',
        10: 'ActActISMAUltimo',
        11: 'ActActISDA',
        12: 'BusTwoFiftyTwo',
        13: 'ThirtyEPlusThreeSixty',
        14: 'ActThreeSixtyFiveL',
        15: 'NLThreeSixtyFive',
        16: 'NLThreeSixty',
        17: 'Act364',
        2: 'ThirtyThreeSixtySIA',
        3: 'ThirtyThreeSixtyM',
        4: 'ThirtyEThreeSixty',
        5: 'ThirtyEThreeSixtyISDA',
        6: 'ActThreeSixty',
        7: 'ActThreeSixtyFiveFixed',
        8: 'ActActAFB',
        9: 'ActActICMA',
    }
    OneOne = 0
    ThrityThreeSixtyUS = 1
    ActActISMAUltimo = 10
    ActActISDA = 11
    BusTwoFiftyTwo = 12
    ThirtyEPlusThreeSixty = 13
    ActThreeSixtyFiveL = 14
    NLThreeSixtyFive = 15
    NLThreeSixty = 16
    Act364 = 17
    ThirtyThreeSixtySIA = 2
    ThirtyThreeSixtyM = 3
    ThirtyEThreeSixty = 4
    ThirtyEThreeSixtyISDA = 5
    ActThreeSixty = 6
    ActThreeSixtyFiveFixed = 7
    ActActAFB = 8
    ActActICMA = 9


class IssueDate(fix.Field, Tag="225", Name="IssueDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class Factor(fix.Field, Tag="228", Name="Factor", Type=fix.FixFloat):
    Values = {
    }


class StrikePrice(fix.Field, Tag="202", Name="StrikePrice", Type=fix.FixPrice):
    Values = {
    }


class StrikePricePrecision(fix.Field, Tag="2577", Name="StrikePricePrecision", Type=fix.FixInt):
    Values = {
    }


class StrikeMultiplier(fix.Field, Tag="967", Name="StrikeMultiplier", Type=fix.FixFloat):
    Values = {
    }


class ContractMultiplier(fix.Field, Tag="231", Name="ContractMultiplier", Type=fix.FixFloat):
    Values = {
    }


class MinPriceIncrement(fix.Field, Tag="969", Name="MinPriceIncrement", Type=fix.FixFloat):
    Values = {
    }


class SettlMethod(fix.Field, Tag="1193", Name="SettlMethod", Type=fix.FixString):
    Values = {
        '1': 'DvPDeliveryvsPayment',
        '2': 'DFoPDeliveryFreeofPayment',
        '3': 'PFoDPaymentFreeofDelivery',
        '4': 'DvDDeliveryvsDelivery',
        'C': 'CashSettlementRequired',
        'E': 'Election',
        'P': 'PhysicalSettlementRequired',
    }
    DvPDeliveryvsPayment = '1'
    DFoPDeliveryFreeofPayment = '2'
    PFoDPaymentFreeofDelivery = '3'
    DvDDeliveryvsDelivery = '4'
    CashSettlementRequired = 'C'
    Election = 'E'
    PhysicalSettlementRequired = 'P'


class ExerciseStyle(fix.Field, Tag="1194", Name="ExerciseStyle", Type=fix.FixInt):
    Values = {
        0: 'European',
        1: 'American',
        2: 'Bermuda',
        99: 'Other',
    }
    European = 0
    American = 1
    Bermuda = 2
    Other = 99


class PutOrCall(fix.Field, Tag="201", Name="PutOrCall", Type=fix.FixInt):
    Values = {
        0: 'Put',
        1: 'Call',
    }
    Put = 0
    Call = 1


class CouponRate(fix.Field, Tag="223", Name="CouponRate", Type=fix.FixFloat):
    Values = {
    }


class Issuer(fix.Field, Tag="106", Name="Issuer", Type=fix.FixString):
    Values = {
    }


class SecurityDesc(fix.Field, Tag="107", Name="SecurityDesc", Type=fix.FixString):
    Values = {
    }


class NoEvents(fix.Field, Tag="864", Name="NoEvents", Type=fix.FixInt):
    Values = {
    }


class EventType(fix.Field, Tag="865", Name="EventType", Type=fix.FixInt):
    Values = {
        1: 'Put',
        10: 'SwapRollDate',
        109: 'FirstTradeDate',
        11: 'SwapNextStartDate',
        12: 'SwapNextRollDate',
        13: 'FirstDeliveryDate',
        133: 'EffectiveExpirationDate',
        14: 'LastDeliveryDate',
        15: 'InitialInventoryDueDate',
        16: 'FinalInventoryDueDate',
        17: 'FirstIntentDate',
        18: 'LastIntentDate',
        19: 'PositionRemovalDate',
        2: 'Call',
        20: 'MinimumNotice',
        21: 'DeliveryStartTime',
        22: 'DeliveryEndTime',
        23: 'FirstNoticeDate',
        24: 'LastNoticeDate',
        25: 'FirstExerciseDate',
        26: 'RedemptionDate',
        27: 'TrdCntntnEfctvDt',
        3: 'Tender',
        4: 'SinkingFundCall',
        5: 'Activation',
        6: 'Inactiviation',
        7: 'LastTradeDate',
        8: 'SwapStartDate',
        9: 'SwapEndDate',
        99: 'Other',
    }
    Put = 1
    SwapRollDate = 10
    FirstTradeDate = 109
    SwapNextStartDate = 11
    SwapNextRollDate = 12
    FirstDeliveryDate = 13
    EffectiveExpirationDate = 133
    LastDeliveryDate = 14
    InitialInventoryDueDate = 15
    FinalInventoryDueDate = 16
    FirstIntentDate = 17
    LastIntentDate = 18
    PositionRemovalDate = 19
    Call = 2
    MinimumNotice = 20
    DeliveryStartTime = 21
    DeliveryEndTime = 22
    FirstNoticeDate = 23
    LastNoticeDate = 24
    FirstExerciseDate = 25
    RedemptionDate = 26
    TrdCntntnEfctvDt = 27
    Tender = 3
    SinkingFundCall = 4
    Activation = 5
    Inactiviation = 6
    LastTradeDate = 7
    SwapStartDate = 8
    SwapEndDate = 9
    Other = 99


class EventDate(fix.Field, Tag="866", Name="EventDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class EventTime(fix.Field, Tag="1145", Name="EventTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class DatedDate(fix.Field, Tag="873", Name="DatedDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class NoInstrumentParties(fix.Field, Tag="1018", Name="NoInstrumentParties", Type=fix.FixInt):
    Values = {
    }


class InstrumentPartyID(fix.Field, Tag="1019", Name="InstrumentPartyID", Type=fix.FixString):
    Values = {
    }


class InstrumentPartyIDSource(fix.Field, Tag="1050", Name="InstrumentPartyIDSource", Type=fix.FixChar):
    Values = {
        '1': 'KoreanInvestorID',
        '2': 'TaiwaneseForeignInvestorID',
        '3': 'TaiwaneseTradingAcct',
        '4': 'MalaysianCentralDepository',
        '5': 'ChineseInvestorID',
        '6': 'UKNationalInsuranceOrPensionNumber',
        '7': 'USSocialSecurityNumber',
        '8': 'USEmployerOrTaxIDNumber',
        '9': 'AustralianBusinessNumber',
        'A': 'AustralianTaxFileNumber',
        'B': 'BIC',
        'C': 'GeneralIdentifier',
        'D': 'Proprietary',
        'E': 'ISOCountryCode',
        'F': 'SettlementEntityLocation',
        'G': 'MIC',
        'H': 'CSDParticipant',
        'I': 'ISITCAcronym',
        'J': 'TaxID',
        'K': 'AustralianCompanyNumber',
        'L': 'AustralianRegisteredBodyNumber',
        'M': 'CFTCReportingFirmIdentifier',
        'N': 'LegalEntityIdentifier',
        'O': 'InterimIdentifier',
        'P': 'ShortCodeIdentifier',
    }
    KoreanInvestorID = '1'
    TaiwaneseForeignInvestorID = '2'
    TaiwaneseTradingAcct = '3'
    MalaysianCentralDepository = '4'
    ChineseInvestorID = '5'
    UKNationalInsuranceOrPensionNumber = '6'
    USSocialSecurityNumber = '7'
    USEmployerOrTaxIDNumber = '8'
    AustralianBusinessNumber = '9'
    AustralianTaxFileNumber = 'A'
    BIC = 'B'
    GeneralIdentifier = 'C'
    Proprietary = 'D'
    ISOCountryCode = 'E'
    SettlementEntityLocation = 'F'
    MIC = 'G'
    CSDParticipant = 'H'
    ISITCAcronym = 'I'
    TaxID = 'J'
    AustralianCompanyNumber = 'K'
    AustralianRegisteredBodyNumber = 'L'
    CFTCReportingFirmIdentifier = 'M'
    LegalEntityIdentifier = 'N'
    InterimIdentifier = 'O'
    ShortCodeIdentifier = 'P'


class InstrumentPartyRole(fix.Field, Tag="1051", Name="InstrumentPartyRole", Type=fix.FixInt):
    Values = {
        1: 'ExecutingFirm',
        10: 'SettlementLocation',
        100: 'MarginAccount',
        101: 'CollateralAssetAccount',
        102: 'DataRepository',
        103: 'CalculationAgent',
        104: 'ExerciseNoticeSender',
        105: 'ExerciseNoticeReceiver',
        106: 'RateReferenceBank',
        107: 'Correspondent',
        109: 'BeneficiaryBank',
        11: 'OrderOriginationTrader',
        110: 'Borrower',
        111: 'PrimaryObligator',
        112: 'Guarantor',
        113: 'ExcludedReferenceEntity',
        114: 'DeterminingParty',
        115: 'HedgingParty',
        116: 'ReportingEntity',
        117: 'SalesPerson',
        118: 'Operator',
        119: 'CSD',
        12: 'ExecutingTrader',
        120: 'ICSD',
        122: 'InvestmentDecisionMaker',
        125: 'Issuer',
        13: 'OrderOriginationFirm',
        14: 'GiveupClearingFirmfirmtowhichtradeisgivenup',
        15: 'CorrespondantClearingFirm',
        16: 'ExecutingSystem',
        17: 'ContraFirm',
        18: 'ContraClearingFirm',
        19: 'SponsoringFirm',
        2: 'BrokerOfCredit',
        20: 'UnderlyingContraFirm',
        21: 'ClearingOrganization',
        22: 'Exchange',
        24: 'CustomerAccount',
        25: 'CorrespondentClearingOrganization',
        26: 'CorrespondentBroker',
        27: 'Buyer',
        28: 'Custodian',
        29: 'Intermediary',
        3: 'ClientID',
        30: 'Agent',
        31: 'SubCustodian',
        32: 'Beneficiary',
        33: 'InterestedParty',
        34: 'RegulatoryBody',
        35: 'LiquidityProvider',
        36: 'EnteringTrader',
        37: 'ContraTrader',
        38: 'PositionAccount',
        39: 'ContraInvestorID',
        4: 'ClearingFirm',
        40: 'TransferToFirm',
        41: 'ContraPositionAccount',
        42: 'ContraExchange',
        43: 'InternalCarryAccount',
        44: 'OrderEntryOperatorID',
        45: 'SecondaryAccountNumber',
        46: 'ForeignFirm',
        47: 'ThirdPartyAllocationFirm',
        48: 'ClaimingAccount',
        49: 'AssetManager',
        5: 'InvestorID',
        50: 'PledgorAccount',
        51: 'PledgeeAccount',
        52: 'LargeTraderReportableAccount',
        53: 'TraderMnemonic',
        54: 'SenderLocation',
        55: 'SessionID',
        56: 'AcceptableCounterparty',
        57: 'UnacceptableCounterparty',
        58: 'EnteringUnit',
        59: 'ExecutingUnit',
        6: 'IntroducingFirm',
        60: 'IntroducingBroker',
        61: 'QuoteOriginator',
        62: 'ReportOriginator',
        63: 'SystematicInternaliser',
        64: 'MultilateralTradingFacility',
        65: 'RegulatedMarket',
        66: 'MarketMaker',
        67: 'InvestmentFirm',
        68: 'HostCompetentAuthority',
        69: 'HomeCompetentAuthority',
        7: 'EnteringFirm',
        70: 'CompetentAuthorityLiquidity',
        71: 'CompetentAuthorityTransactionVenue',
        72: 'ReportingIntermediary',
        73: 'ExecutionVenue',
        74: 'MarketDataEntryOriginator',
        75: 'LocationID',
        76: 'DeskID',
        77: 'MarketDataMarket',
        78: 'AllocationEntity',
        79: 'PrimeBroker',
        8: 'Locate',
        80: 'StepOutFirm',
        81: 'BrokerClearingID',
        82: 'CentralRegistrationDepository',
        83: 'ClearingAccount',
        84: 'AcceptableSettlingCounterparty',
        85: 'UnacceptableSettlingCounterparty',
        86: 'CLSMemberBank',
        87: 'InConcertGroup',
        88: 'InConcertControllingEntity',
        89: 'LargePositionsReportingAccount',
        9: 'FundManagerClientID',
        90: 'SettlementFirm',
        91: 'SettlementAccount',
        92: 'ReportingMarketCenter',
        93: 'RelatedReportingMarketCenter',
        94: 'AwayMarket',
        95: 'GiveupTradingFirm',
        96: 'TakeupTradingFirm',
        97: 'GiveupClearingFirm',
        98: 'TakeupClearingFirm',
        99: 'OriginatingMarket',
    }
    ExecutingFirm = 1
    SettlementLocation = 10
    MarginAccount = 100
    CollateralAssetAccount = 101
    DataRepository = 102
    CalculationAgent = 103
    ExerciseNoticeSender = 104
    ExerciseNoticeReceiver = 105
    RateReferenceBank = 106
    Correspondent = 107
    BeneficiaryBank = 109
    OrderOriginationTrader = 11
    Borrower = 110
    PrimaryObligator = 111
    Guarantor = 112
    ExcludedReferenceEntity = 113
    DeterminingParty = 114
    HedgingParty = 115
    ReportingEntity = 116
    SalesPerson = 117
    Operator = 118
    CSD = 119
    ExecutingTrader = 12
    ICSD = 120
    InvestmentDecisionMaker = 122
    Issuer = 125
    OrderOriginationFirm = 13
    GiveupClearingFirmfirmtowhichtradeisgivenup = 14
    CorrespondantClearingFirm = 15
    ExecutingSystem = 16
    ContraFirm = 17
    ContraClearingFirm = 18
    SponsoringFirm = 19
    BrokerOfCredit = 2
    UnderlyingContraFirm = 20
    ClearingOrganization = 21
    Exchange = 22
    CustomerAccount = 24
    CorrespondentClearingOrganization = 25
    CorrespondentBroker = 26
    Buyer = 27
    Custodian = 28
    Intermediary = 29
    ClientID = 3
    Agent = 30
    SubCustodian = 31
    Beneficiary = 32
    InterestedParty = 33
    RegulatoryBody = 34
    LiquidityProvider = 35
    EnteringTrader = 36
    ContraTrader = 37
    PositionAccount = 38
    ContraInvestorID = 39
    ClearingFirm = 4
    TransferToFirm = 40
    ContraPositionAccount = 41
    ContraExchange = 42
    InternalCarryAccount = 43
    OrderEntryOperatorID = 44
    SecondaryAccountNumber = 45
    ForeignFirm = 46
    ThirdPartyAllocationFirm = 47
    ClaimingAccount = 48
    AssetManager = 49
    InvestorID = 5
    PledgorAccount = 50
    PledgeeAccount = 51
    LargeTraderReportableAccount = 52
    TraderMnemonic = 53
    SenderLocation = 54
    SessionID = 55
    AcceptableCounterparty = 56
    UnacceptableCounterparty = 57
    EnteringUnit = 58
    ExecutingUnit = 59
    IntroducingFirm = 6
    IntroducingBroker = 60
    QuoteOriginator = 61
    ReportOriginator = 62
    SystematicInternaliser = 63
    MultilateralTradingFacility = 64
    RegulatedMarket = 65
    MarketMaker = 66
    InvestmentFirm = 67
    HostCompetentAuthority = 68
    HomeCompetentAuthority = 69
    EnteringFirm = 7
    CompetentAuthorityLiquidity = 70
    CompetentAuthorityTransactionVenue = 71
    ReportingIntermediary = 72
    ExecutionVenue = 73
    MarketDataEntryOriginator = 74
    LocationID = 75
    DeskID = 76
    MarketDataMarket = 77
    AllocationEntity = 78
    PrimeBroker = 79
    Locate = 8
    StepOutFirm = 80
    BrokerClearingID = 81
    CentralRegistrationDepository = 82
    ClearingAccount = 83
    AcceptableSettlingCounterparty = 84
    UnacceptableSettlingCounterparty = 85
    CLSMemberBank = 86
    InConcertGroup = 87
    InConcertControllingEntity = 88
    LargePositionsReportingAccount = 89
    FundManagerClientID = 9
    SettlementFirm = 90
    SettlementAccount = 91
    ReportingMarketCenter = 92
    RelatedReportingMarketCenter = 93
    AwayMarket = 94
    GiveupTradingFirm = 95
    TakeupTradingFirm = 96
    GiveupClearingFirm = 97
    TakeupClearingFirm = 98
    OriginatingMarket = 99


class NoInstrumentPartySubIDs(fix.Field, Tag="1052", Name="NoInstrumentPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoComplexEvents(fix.Field, Tag="1483", Name="NoComplexEvents", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventDates(fix.Field, Tag="1491", Name="NoComplexEventDates", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventTimes(fix.Field, Tag="1494", Name="NoComplexEventTimes", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventRateSources(fix.Field, Tag="41013", Name="NoComplexEventRateSources", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventDateBusinessCenters(fix.Field, Tag="41018", Name="NoComplexEventDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventPeriods(fix.Field, Tag="41010", Name="NoComplexEventPeriods", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventSchedules(fix.Field, Tag="41031", Name="NoComplexEventSchedules", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventPeriodDateTimes(fix.Field, Tag="41007", Name="NoComplexEventPeriodDateTimes", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventAveragingObservations(fix.Field, Tag="40994", Name="NoComplexEventAveragingObservations", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventCreditEventSources(fix.Field, Tag="41029", Name="NoComplexEventCreditEventSources", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventCreditEvents(fix.Field, Tag="40997", Name="NoComplexEventCreditEvents", Type=fix.FixInt):
    Values = {
    }


class NoComplexEventCreditEventQualifiers(fix.Field, Tag="41005", Name="NoComplexEventCreditEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class InstrumentPricePrecision(fix.Field, Tag="2576", Name="InstrumentPricePrecision", Type=fix.FixInt):
    Values = {
    }


class NoBusinessCenters(fix.Field, Tag="40278", Name="NoBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPricingDateBusinessCenters(fix.Field, Tag="41230", Name="NoPricingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoMarketDisruptionEvents(fix.Field, Tag="41092", Name="NoMarketDisruptionEvents", Type=fix.FixInt):
    Values = {
    }


class NoMarketDisruptionFallbacks(fix.Field, Tag="41094", Name="NoMarketDisruptionFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoMarketDisruptionFallbackReferencePrices(fix.Field, Tag="41096", Name="NoMarketDisruptionFallbackReferencePrices", Type=fix.FixInt):
    Values = {
    }


class NoOptionExerciseBusinessCenters(fix.Field, Tag="41116", Name="NoOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoOptionExerciseDates(fix.Field, Tag="41137", Name="NoOptionExerciseDates", Type=fix.FixInt):
    Values = {
    }


class NoOptionExerciseExpirationDateBusinessCenters(fix.Field, Tag="41140", Name="NoOptionExerciseExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoOptionExerciseExpirationDates(fix.Field, Tag="41152", Name="NoOptionExerciseExpirationDates", Type=fix.FixInt):
    Values = {
    }


class NoStreams(fix.Field, Tag="40049", Name="NoStreams", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommodityAltIDs(fix.Field, Tag="41277", Name="NoStreamCommodityAltIDs", Type=fix.FixInt):
    Values = {
    }


class NoStreamAssetAttributes(fix.Field, Tag="41237", Name="NoStreamAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommodityDataSources(fix.Field, Tag="41280", Name="NoStreamCommodityDataSources", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommoditySettlBusinessCenters(fix.Field, Tag="41249", Name="NoStreamCommoditySettlBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommoditySettlPeriods(fix.Field, Tag="41289", Name="NoStreamCommoditySettlPeriods", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommoditySettlDays(fix.Field, Tag="41283", Name="NoStreamCommoditySettlDays", Type=fix.FixInt):
    Values = {
    }


class NoStreamCommoditySettlTimes(fix.Field, Tag="41286", Name="NoStreamCommoditySettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoStreamEffectiveBusinessCenters(fix.Field, Tag="40960", Name="NoStreamEffectiveBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoStreamTerminationDateBusinessCenters(fix.Field, Tag="40961", Name="NoStreamTerminationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoStreamCalculationPeriodBusinessCenters(fix.Field, Tag="40958", Name="NoStreamCalculationPeriodBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoStreamCalculationPeriodDates(fix.Field, Tag="41241", Name="NoStreamCalculationPeriodDates", Type=fix.FixInt):
    Values = {
    }


class NoStreamFirstPeriodStartDateBusinessCenters(fix.Field, Tag="40959", Name="NoStreamFirstPeriodStartDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class PaymentStreamDayCount(fix.Field, Tag="40742", Name="PaymentStreamDayCount", Type=fix.FixInt):
    Values = {
        0: 'OneOne',
        1: 'ThrityThreeSixtyUS',
        10: 'ActActISMAUltimo',
        11: 'ActActISDA',
        12: 'BusTwoFiftyTwo',
        13: 'ThirtyEPlusThreeSixty',
        14: 'ActThreeSixtyFiveL',
        15: 'NLThreeSixtyFive',
        16: 'NLThreeSixty',
        17: 'Act364',
        2: 'ThirtyThreeSixtySIA',
        3: 'ThirtyThreeSixtyM',
        4: 'ThirtyEThreeSixty',
        5: 'ThirtyEThreeSixtyISDA',
        6: 'ActThreeSixty',
        7: 'ActThreeSixtyFiveFixed',
        8: 'ActActAFB',
        9: 'ActActICMA',
    }
    OneOne = 0
    ThrityThreeSixtyUS = 1
    ActActISMAUltimo = 10
    ActActISDA = 11
    BusTwoFiftyTwo = 12
    ThirtyEPlusThreeSixty = 13
    ActThreeSixtyFiveL = 14
    NLThreeSixtyFive = 15
    NLThreeSixty = 16
    Act364 = 17
    ThirtyThreeSixtySIA = 2
    ThirtyThreeSixtyM = 3
    ThirtyEThreeSixty = 4
    ThirtyEThreeSixtyISDA = 5
    ActThreeSixty = 6
    ActThreeSixtyFiveFixed = 7
    ActActAFB = 8
    ActActICMA = 9


class NoPaymentStreamPaymentDateBusinessCenters(fix.Field, Tag="40947", Name="NoPaymentStreamPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamPaymentDates(fix.Field, Tag="41220", Name="NoPaymentStreamPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamResetDateBusinessCenters(fix.Field, Tag="40948", Name="NoPaymentStreamResetDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamInitialFixingDateBusinessCenters(fix.Field, Tag="40949", Name="NoPaymentStreamInitialFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamFixingDateBusinessCenters(fix.Field, Tag="40950", Name="NoPaymentStreamFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamPricingBusinessCenters(fix.Field, Tag="41192", Name="NoPaymentStreamPricingBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamPricingDays(fix.Field, Tag="41227", Name="NoPaymentStreamPricingDays", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamPricingDates(fix.Field, Tag="41224", Name="NoPaymentStreamPricingDates", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStreamNonDeliverableFixingDatesBusinessCenters(fix.Field, Tag="40946", Name="NoPaymentStreamNonDeliverableFixingDatesBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoNonDeliverableFixingDates(fix.Field, Tag="40825", Name="NoNonDeliverableFixingDates", Type=fix.FixInt):
    Values = {
    }


class NoSettlRateFallbacks(fix.Field, Tag="40085", Name="NoSettlRateFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoPaymentSchedules(fix.Field, Tag="40828", Name="NoPaymentSchedules", Type=fix.FixInt):
    Values = {
    }


class NoPaymentScheduleRateSources(fix.Field, Tag="40868", Name="NoPaymentScheduleRateSources", Type=fix.FixInt):
    Values = {
    }


class NoPaymentScheduleFixingDateBusinessCenters(fix.Field, Tag="40977", Name="NoPaymentScheduleFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentScheduleFixingDays(fix.Field, Tag="41161", Name="NoPaymentScheduleFixingDays", Type=fix.FixInt):
    Values = {
    }


class NoPaymentScheduleInterimExchangeDateBusinessCenters(fix.Field, Tag="40945", Name="NoPaymentScheduleInterimExchangeDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentStubs(fix.Field, Tag="40872", Name="NoPaymentStubs", Type=fix.FixInt):
    Values = {
    }


class NoDeliveryStreamCommoditySources(fix.Field, Tag="41085", Name="NoDeliveryStreamCommoditySources", Type=fix.FixInt):
    Values = {
    }


class NoDeliveryStreamCycles(fix.Field, Tag="41081", Name="NoDeliveryStreamCycles", Type=fix.FixInt):
    Values = {
    }


class NoDeliverySchedules(fix.Field, Tag="41037", Name="NoDeliverySchedules", Type=fix.FixInt):
    Values = {
    }


class NoDeliveryScheduleSettlDays(fix.Field, Tag="41051", Name="NoDeliveryScheduleSettlDays", Type=fix.FixInt):
    Values = {
    }


class NoDeliveryScheduleSettlTimes(fix.Field, Tag="41054", Name="NoDeliveryScheduleSettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoProvisions(fix.Field, Tag="40090", Name="NoProvisions", Type=fix.FixInt):
    Values = {
    }


class NoProvisionDateBusinessCenters(fix.Field, Tag="40957", Name="NoProvisionDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionCashSettlValueDateBusinessCenters(fix.Field, Tag="40953", Name="NoProvisionCashSettlValueDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionOptionExerciseBusinessCenters(fix.Field, Tag="40954", Name="NoProvisionOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionOptionExerciseFixedDates(fix.Field, Tag="40142", Name="NoProvisionOptionExerciseFixedDates", Type=fix.FixInt):
    Values = {
    }


class NoProvisionOptionExpirationDateBusinessCenters(fix.Field, Tag="40955", Name="NoProvisionOptionExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionOptionRelevantUnderlyingDateBusinessCenters(fix.Field, Tag="40956", Name="NoProvisionOptionRelevantUnderlyingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionCashSettlPaymentDateBusinessCenters(fix.Field, Tag="40952", Name="NoProvisionCashSettlPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoProvisionCashSettlPaymentDates(fix.Field, Tag="40171", Name="NoProvisionCashSettlPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoProvisionPartyIDs(fix.Field, Tag="40174", Name="NoProvisionPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoProvisionPartySubIDs(fix.Field, Tag="40178", Name="NoProvisionPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoAdditionalTerms(fix.Field, Tag="40019", Name="NoAdditionalTerms", Type=fix.FixInt):
    Values = {
    }


class NoAdditionalTermBondRefs(fix.Field, Tag="40000", Name="NoAdditionalTermBondRefs", Type=fix.FixInt):
    Values = {
    }


class NoProtectionTerms(fix.Field, Tag="40181", Name="NoProtectionTerms", Type=fix.FixInt):
    Values = {
    }


class NoProtectionTermEventNewsSources(fix.Field, Tag="40951", Name="NoProtectionTermEventNewsSources", Type=fix.FixInt):
    Values = {
    }


class NoProtectionTermEvents(fix.Field, Tag="40191", Name="NoProtectionTermEvents", Type=fix.FixInt):
    Values = {
    }


class NoProtectionTermEventQualifiers(fix.Field, Tag="40199", Name="NoProtectionTermEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class NoProtectionTermObligations(fix.Field, Tag="40201", Name="NoProtectionTermObligations", Type=fix.FixInt):
    Values = {
    }


class NoCashSettlTerms(fix.Field, Tag="40022", Name="NoCashSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoCashSettlDealers(fix.Field, Tag="40277", Name="NoCashSettlDealers", Type=fix.FixInt):
    Values = {
    }


class NoPhysicalSettlTerms(fix.Field, Tag="40204", Name="NoPhysicalSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoPhysicalSettlDeliverableObligations(fix.Field, Tag="40209", Name="NoPhysicalSettlDeliverableObligations", Type=fix.FixInt):
    Values = {
    }


class NoInstrAttrib(fix.Field, Tag="870", Name="NoInstrAttrib", Type=fix.FixInt):
    Values = {
    }


class InstrAttribType(fix.Field, Tag="871", Name="InstrAttribType", Type=fix.FixInt):
    Values = {
        1: 'Flat',
        10: 'OriginalIssueDiscount',
        106: 'BasePriceReferencePrice',
        11: 'Callable',
        117: 'PartitionID',
        12: 'EscrowedToMaturity',
        120: 'BaseAsset',
        121: 'InstrumentQuantityPrecision',
        122: 'OutstandingNoOfShares',
        123: 'TradeableNoOfShares',
        124: 'MinOrderQty',
        125: 'MaxOrderQty',
        126: 'EntitlementsMultiplier',
        127: 'Haircut',
        128: 'PrimaryIndicator',
        13: 'EscrowedToRedemptionDate',
        133: 'TradingQtyUnitType',
        14: 'PreRefunded',
        15: 'InDefault',
        16: 'Unrated',
        17: 'Taxable',
        18: 'Indexed',
        19: 'SubjectToAlternativeMinimumTax',
        2: 'ZeroCoupon',
        20: 'OriginalIssueDiscountPrice',
        21: 'CallableBelowMaturityValue',
        22: 'CallableWithoutNotice',
        23: 'PriceTickRulesForSecurity',
        24: 'TradeTypeEligibilityDetailsForSecurity',
        25: 'InstrumentDenominator',
        26: 'InstrumentNumerator',
        27: 'InstrumentPricePrecision',
        28: 'InstrumentStrikePrice',
        29: 'TradeableIndicator',
        3: 'InterestBearing',
        30: 'InstrumentEligibleAnonOrders',
        31: 'MinGuaranteedFillVolume',
        32: 'MinGuaranteedFillStatus',
        33: 'TradeAtSettlementEligibility',
        34: 'TestInstrument',
        35: 'DummyInstrument',
        36: 'NegativeSettlementPriceEligibility',
        37: 'NegativeStrikePriceEligibility',
        38: 'USStdContractInd',
        4: 'NoPeriodicPayments',
        5: 'VariableRate',
        6: 'LessFeeForPut',
        7: 'SteppedCoupon',
        8: 'CouponPeriod',
        9: 'When',
        99: 'Text',
    }
    Flat = 1
    OriginalIssueDiscount = 10
    BasePriceReferencePrice = 106
    Callable = 11
    PartitionID = 117
    EscrowedToMaturity = 12
    BaseAsset = 120
    InstrumentQuantityPrecision = 121
    OutstandingNoOfShares = 122
    TradeableNoOfShares = 123
    MinOrderQty = 124
    MaxOrderQty = 125
    EntitlementsMultiplier = 126
    Haircut = 127
    PrimaryIndicator = 128
    EscrowedToRedemptionDate = 13
    TradingQtyUnitType = 133
    PreRefunded = 14
    InDefault = 15
    Unrated = 16
    Taxable = 17
    Indexed = 18
    SubjectToAlternativeMinimumTax = 19
    ZeroCoupon = 2
    OriginalIssueDiscountPrice = 20
    CallableBelowMaturityValue = 21
    CallableWithoutNotice = 22
    PriceTickRulesForSecurity = 23
    TradeTypeEligibilityDetailsForSecurity = 24
    InstrumentDenominator = 25
    InstrumentNumerator = 26
    InstrumentPricePrecision = 27
    InstrumentStrikePrice = 28
    TradeableIndicator = 29
    InterestBearing = 3
    InstrumentEligibleAnonOrders = 30
    MinGuaranteedFillVolume = 31
    MinGuaranteedFillStatus = 32
    TradeAtSettlementEligibility = 33
    TestInstrument = 34
    DummyInstrument = 35
    NegativeSettlementPriceEligibility = 36
    NegativeStrikePriceEligibility = 37
    USStdContractInd = 38
    NoPeriodicPayments = 4
    VariableRate = 5
    LessFeeForPut = 6
    SteppedCoupon = 7
    CouponPeriod = 8
    When = 9
    Text = 99


class InstrAttribValue(fix.Field, Tag="872", Name="InstrAttribValue", Type=fix.FixString):
    Values = {
        'C': 'Callable',
        'L': 'Quantitiesexpressedinlots',
        'N': 'No',
        'U': 'Quantitiesexpressedinunits',
        'Y': 'Yes',
    }
    Callable = 'C'
    Quantitiesexpressedinlots = 'L'
    No = 'N'
    Quantitiesexpressedinunits = 'U'
    Yes = 'Y'


class NoContractualDefinitions(fix.Field, Tag="40040", Name="NoContractualDefinitions", Type=fix.FixInt):
    Values = {
    }


class NoFinancingTermSupplements(fix.Field, Tag="40046", Name="NoFinancingTermSupplements", Type=fix.FixInt):
    Values = {
    }


class NoContractualMatrices(fix.Field, Tag="40042", Name="NoContractualMatrices", Type=fix.FixInt):
    Values = {
    }


class StartDate(fix.Field, Tag="916", Name="StartDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class EndDate(fix.Field, Tag="917", Name="EndDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class NoRelatedInstruments(fix.Field, Tag="1647", Name="NoRelatedInstruments", Type=fix.FixInt):
    Values = {
    }


class NoLegs(fix.Field, Tag="555", Name="NoLegs", Type=fix.FixInt):
    Values = {
    }


class LegSymbol(fix.Field, Tag="600", Name="LegSymbol", Type=fix.FixString):
    Values = {
    }


class LegSecurityID(fix.Field, Tag="602", Name="LegSecurityID", Type=fix.FixString):
    Values = {
    }


class LegSecurityIDSource(fix.Field, Tag="603", Name="LegSecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class NoLegSecurityAltID(fix.Field, Tag="604", Name="NoLegSecurityAltID", Type=fix.FixInt):
    Values = {
    }


class LegSecurityAltID(fix.Field, Tag="605", Name="LegSecurityAltID", Type=fix.FixString):
    Values = {
    }


class LegSecurityAltIDSource(fix.Field, Tag="606", Name="LegSecurityAltIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class NoLegSecondaryAssetClasses(fix.Field, Tag="2076", Name="NoLegSecondaryAssetClasses", Type=fix.FixInt):
    Values = {
    }


class NoLegAssetAttributes(fix.Field, Tag="2308", Name="NoLegAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class LegSecurityDesc(fix.Field, Tag="620", Name="LegSecurityDesc", Type=fix.FixString):
    Values = {
    }


class LegRatioQty(fix.Field, Tag="623", Name="LegRatioQty", Type=fix.FixFloat):
    Values = {
    }


class LegSide(fix.Field, Tag="624", Name="LegSide", Type=fix.FixChar):
    Values = {
        '1': 'Buy',
        '2': 'Sell',
        '3': 'BuyMinus',
        '4': 'SellPlus',
        '5': 'SellShort',
        '6': 'SellShortExempt',
        '7': 'Undisclosed',
        '8': 'Cross',
        '9': 'CrossShort',
        'A': 'CrossShortExempt',
        'B': 'AsDefined',
        'C': 'Opposite',
        'D': 'Subscribe',
        'E': 'Redeem',
        'F': 'Lend',
        'G': 'Borrow',
    }
    Buy = '1'
    Sell = '2'
    BuyMinus = '3'
    SellPlus = '4'
    SellShort = '5'
    SellShortExempt = '6'
    Undisclosed = '7'
    Cross = '8'
    CrossShort = '9'
    CrossShortExempt = 'A'
    AsDefined = 'B'
    Opposite = 'C'
    Subscribe = 'D'
    Redeem = 'E'
    Lend = 'F'
    Borrow = 'G'


class NoLegEvents(fix.Field, Tag="2059", Name="NoLegEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegInstrumentParties(fix.Field, Tag="2254", Name="NoLegInstrumentParties", Type=fix.FixInt):
    Values = {
    }


class NoLegInstrumentPartySubIDs(fix.Field, Tag="2258", Name="NoLegInstrumentPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEvents(fix.Field, Tag="2218", Name="NoLegComplexEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventDates(fix.Field, Tag="2250", Name="NoLegComplexEventDates", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventTimes(fix.Field, Tag="2253", Name="NoLegComplexEventTimes", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventRateSources(fix.Field, Tag="41382", Name="NoLegComplexEventRateSources", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventDateBusinessCenters(fix.Field, Tag="41387", Name="NoLegComplexEventDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventPeriods(fix.Field, Tag="41379", Name="NoLegComplexEventPeriods", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventSchedules(fix.Field, Tag="41400", Name="NoLegComplexEventSchedules", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventPeriodDateTimes(fix.Field, Tag="41376", Name="NoLegComplexEventPeriodDateTimes", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventAveragingObservations(fix.Field, Tag="41363", Name="NoLegComplexEventAveragingObservations", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventCreditEventSources(fix.Field, Tag="41398", Name="NoLegComplexEventCreditEventSources", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventCreditEvents(fix.Field, Tag="41366", Name="NoLegComplexEventCreditEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegComplexEventCreditEventQualifiers(fix.Field, Tag="41374", Name="NoLegComplexEventCreditEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class NoLegBusinessCenters(fix.Field, Tag="40923", Name="NoLegBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPricingDateBusinessCenters(fix.Field, Tag="41607", Name="NoLegPricingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegMarketDisruptionEvents(fix.Field, Tag="41467", Name="NoLegMarketDisruptionEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegMarketDisruptionFallbacks(fix.Field, Tag="41469", Name="NoLegMarketDisruptionFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoLegMarketDisruptionFallbackReferencePrices(fix.Field, Tag="41471", Name="NoLegMarketDisruptionFallbackReferencePrices", Type=fix.FixInt):
    Values = {
    }


class NoLegOptionExerciseBusinessCenters(fix.Field, Tag="41491", Name="NoLegOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegOptionExerciseDates(fix.Field, Tag="41512", Name="NoLegOptionExerciseDates", Type=fix.FixInt):
    Values = {
    }


class NoLegOptionExerciseExpirationDateBusinessCenters(fix.Field, Tag="41515", Name="NoLegOptionExerciseExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegOptionExerciseExpirationDates(fix.Field, Tag="41527", Name="NoLegOptionExerciseExpirationDates", Type=fix.FixInt):
    Values = {
    }


class NoLegStreams(fix.Field, Tag="40241", Name="NoLegStreams", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommodityAltIDs(fix.Field, Tag="41674", Name="NoLegStreamCommodityAltIDs", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamAssetAttributes(fix.Field, Tag="41452", Name="NoLegStreamAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommodityDataSources(fix.Field, Tag="41677", Name="NoLegStreamCommodityDataSources", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommoditySettlBusinessCenters(fix.Field, Tag="41646", Name="NoLegStreamCommoditySettlBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommoditySettlPeriods(fix.Field, Tag="41686", Name="NoLegStreamCommoditySettlPeriods", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommoditySettlDays(fix.Field, Tag="41680", Name="NoLegStreamCommoditySettlDays", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCommoditySettlTimes(fix.Field, Tag="41683", Name="NoLegStreamCommoditySettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamEffectiveDateBusinessCenters(fix.Field, Tag="40942", Name="NoLegStreamEffectiveDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamTerminationDateBusinessCenters(fix.Field, Tag="40943", Name="NoLegStreamTerminationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCalculationPeriodBusinessCenters(fix.Field, Tag="40940", Name="NoLegStreamCalculationPeriodBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamCalculationPeriodDates(fix.Field, Tag="41638", Name="NoLegStreamCalculationPeriodDates", Type=fix.FixInt):
    Values = {
    }


class NoLegStreamFirstPeriodStartDateBusinessCenters(fix.Field, Tag="40941", Name="NoLegStreamFirstPeriodStartDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamPaymentDateBusinessCenters(fix.Field, Tag="40930", Name="NoLegPaymentStreamPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamPaymentDates(fix.Field, Tag="41589", Name="NoLegPaymentStreamPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamResetDateBusinessCenters(fix.Field, Tag="40931", Name="NoLegPaymentStreamResetDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamInitialFixingDateBusinessCenters(fix.Field, Tag="40932", Name="NoLegPaymentStreamInitialFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamFixingDateBusinessCenters(fix.Field, Tag="40933", Name="NoLegPaymentStreamFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamPricingBusinessCenters(fix.Field, Tag="41561", Name="NoLegPaymentStreamPricingBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamPricingDays(fix.Field, Tag="41596", Name="NoLegPaymentStreamPricingDays", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamPricingDates(fix.Field, Tag="41593", Name="NoLegPaymentStreamPricingDates", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStreamNonDeliverableFixingDateBusinessCenters(fix.Field, Tag="40929", Name="NoLegPaymentStreamNonDeliverableFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegNonDeliverableFixingDates(fix.Field, Tag="40367", Name="NoLegNonDeliverableFixingDates", Type=fix.FixInt):
    Values = {
    }


class NoLegSettlRateFallbacks(fix.Field, Tag="40902", Name="NoLegSettlRateFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentSchedules(fix.Field, Tag="40374", Name="NoLegPaymentSchedules", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentScheduleRateSources(fix.Field, Tag="40414", Name="NoLegPaymentScheduleRateSources", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentScheduleFixingDateBusinessCenters(fix.Field, Tag="40927", Name="NoLegPaymentScheduleFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentScheduleFixingDays(fix.Field, Tag="41530", Name="NoLegPaymentScheduleFixingDays", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentScheduleInterimExchangeDateBusinessCenters(fix.Field, Tag="40928", Name="NoLegPaymentScheduleInterimExchangeDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegPaymentStubs(fix.Field, Tag="40418", Name="NoLegPaymentStubs", Type=fix.FixInt):
    Values = {
    }


class NoLegDeliveryStreamCommoditySources(fix.Field, Tag="41460", Name="NoLegDeliveryStreamCommoditySources", Type=fix.FixInt):
    Values = {
    }


class NoLegDeliveryStreamCycles(fix.Field, Tag="41456", Name="NoLegDeliveryStreamCycles", Type=fix.FixInt):
    Values = {
    }


class NoLegDeliverySchedules(fix.Field, Tag="41408", Name="NoLegDeliverySchedules", Type=fix.FixInt):
    Values = {
    }


class NoLegDeliveryScheduleSettlDays(fix.Field, Tag="41422", Name="NoLegDeliveryScheduleSettlDays", Type=fix.FixInt):
    Values = {
    }


class NoLegDeliveryScheduleSettlTimes(fix.Field, Tag="41425", Name="NoLegDeliveryScheduleSettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisions(fix.Field, Tag="40448", Name="NoLegProvisions", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionDateBusinessCenters(fix.Field, Tag="40939", Name="NoLegProvisionDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionCashSettlValueDateBusinessCenters(fix.Field, Tag="40935", Name="NoLegProvisionCashSettlValueDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionOptionExerciseBusinessCenters(fix.Field, Tag="40936", Name="NoLegProvisionOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionOptionExerciseFixedDates(fix.Field, Tag="40495", Name="NoLegProvisionOptionExerciseFixedDates", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionOptionExpirationDateBusinessCenters(fix.Field, Tag="40937", Name="NoLegProvisionOptionExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionOptionRelevantUnderlyingDateBusinessCenters(fix.Field, Tag="40938", Name="NoLegProvisionOptionRelevantUnderlyingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionCashSettlPaymentDateBusinessCenters(fix.Field, Tag="40934", Name="NoLegProvisionCashSettlPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionCashSettlPaymentDates(fix.Field, Tag="40473", Name="NoLegProvisionCashSettlPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionPartyIDs(fix.Field, Tag="40533", Name="NoLegProvisionPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoLegProvisionPartySubIDs(fix.Field, Tag="40537", Name="NoLegProvisionPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoLegAdditionalTerms(fix.Field, Tag="41335", Name="NoLegAdditionalTerms", Type=fix.FixInt):
    Values = {
    }


class NoLegAdditionalTermBondRefs(fix.Field, Tag="41316", Name="NoLegAdditionalTermBondRefs", Type=fix.FixInt):
    Values = {
    }


class NoLegProtectionTerms(fix.Field, Tag="41616", Name="NoLegProtectionTerms", Type=fix.FixInt):
    Values = {
    }


class NoLegProtectionTermEventNewsSources(fix.Field, Tag="41614", Name="NoLegProtectionTermEventNewsSources", Type=fix.FixInt):
    Values = {
    }


class NoLegProtectionTermEvents(fix.Field, Tag="41625", Name="NoLegProtectionTermEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegProtectionTermEventQualifiers(fix.Field, Tag="41633", Name="NoLegProtectionTermEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class NoLegProtectionTermObligations(fix.Field, Tag="41635", Name="NoLegProtectionTermObligations", Type=fix.FixInt):
    Values = {
    }


class NoLegCashSettlTerms(fix.Field, Tag="41344", Name="NoLegCashSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoLegCashSettlDealers(fix.Field, Tag="41342", Name="NoLegCashSettlDealers", Type=fix.FixInt):
    Values = {
    }


class NoLegPhysicalSettlTerms(fix.Field, Tag="41599", Name="NoLegPhysicalSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoLegPhysicalSettlDeliverableObligations(fix.Field, Tag="41604", Name="NoLegPhysicalSettlDeliverableObligations", Type=fix.FixInt):
    Values = {
    }


class NoLegContractualDefinitions(fix.Field, Tag="42198", Name="NoLegContractualDefinitions", Type=fix.FixInt):
    Values = {
    }


class NoLegFinancingTermSupplements(fix.Field, Tag="42200", Name="NoLegFinancingTermSupplements", Type=fix.FixInt):
    Values = {
    }


class NoLegContractualMatrices(fix.Field, Tag="42203", Name="NoLegContractualMatrices", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyings(fix.Field, Tag="711", Name="NoUnderlyings", Type=fix.FixInt):
    Values = {
    }


class UnderlyingSymbol(fix.Field, Tag="311", Name="UnderlyingSymbol", Type=fix.FixString):
    Values = {
    }


class UnderlyingSymbolSfx(fix.Field, Tag="312", Name="UnderlyingSymbolSfx", Type=fix.FixString):
    Values = {
        'CD': 'EUCPWithLumpSumInterest',
        'WI': 'WhenIssued',
    }
    EUCPWithLumpSumInterest = 'CD'
    WhenIssued = 'WI'


class UnderlyingSecurityID(fix.Field, Tag="309", Name="UnderlyingSecurityID", Type=fix.FixString):
    Values = {
    }


class UnderlyingSecurityIDSource(fix.Field, Tag="305", Name="UnderlyingSecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class NoUnderlyingSecurityAltID(fix.Field, Tag="457", Name="NoUnderlyingSecurityAltID", Type=fix.FixInt):
    Values = {
    }


class UnderlyingSecurityAltID(fix.Field, Tag="458", Name="UnderlyingSecurityAltID", Type=fix.FixString):
    Values = {
    }


class UnderlyingSecurityAltIDSource(fix.Field, Tag="459", Name="UnderlyingSecurityAltIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class UnderlyingSecurityDesc(fix.Field, Tag="307", Name="UnderlyingSecurityDesc", Type=fix.FixString):
    Values = {
    }


class UnderlyingCurrency(fix.Field, Tag="318", Name="UnderlyingCurrency", Type=fix.FixCurrency):
    Values = {
    }


class NoUnderlyingStips(fix.Field, Tag="887", Name="NoUnderlyingStips", Type=fix.FixInt):
    Values = {
    }


class NoUndlyInstrumentParties(fix.Field, Tag="1058", Name="NoUndlyInstrumentParties", Type=fix.FixInt):
    Values = {
    }


class NoUndlyInstrumentPartySubIDs(fix.Field, Tag="1062", Name="NoUndlyInstrumentPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingEvents(fix.Field, Tag="1981", Name="NoUnderlyingEvents", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingSecondaryAssetClasses(fix.Field, Tag="2080", Name="NoUnderlyingSecondaryAssetClasses", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingAssetAttributes(fix.Field, Tag="2312", Name="NoUnderlyingAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEvents(fix.Field, Tag="2045", Name="NoUnderlyingComplexEvents", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventDates(fix.Field, Tag="2053", Name="NoUnderlyingComplexEventDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventTimes(fix.Field, Tag="2056", Name="NoUnderlyingComplexEventTimes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventRateSources(fix.Field, Tag="41732", Name="NoUnderlyingComplexEventRateSources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventDateBusinessCenters(fix.Field, Tag="41737", Name="NoUnderlyingComplexEventDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventPeriods(fix.Field, Tag="41729", Name="NoUnderlyingComplexEventPeriods", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventSchedules(fix.Field, Tag="41750", Name="NoUnderlyingComplexEventSchedules", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventPeriodDateTimes(fix.Field, Tag="41726", Name="NoUnderlyingComplexEventPeriodDateTimes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventAveragingObservations(fix.Field, Tag="41713", Name="NoUnderlyingComplexEventAveragingObservations", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventCreditEventSources(fix.Field, Tag="41748", Name="NoUnderlyingComplexEventCreditEventSources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventCreditEvents(fix.Field, Tag="41716", Name="NoUnderlyingComplexEventCreditEvents", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingComplexEventCreditEventQualifiers(fix.Field, Tag="41724", Name="NoUnderlyingComplexEventCreditEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingBusinessCenters(fix.Field, Tag="40962", Name="NoUnderlyingBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPricingDateBusinessCenters(fix.Field, Tag="41947", Name="NoUnderlyingPricingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingMarketDisruptionEvents(fix.Field, Tag="41864", Name="NoUnderlyingMarketDisruptionEvents", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingMarketDisruptionFallbacks(fix.Field, Tag="41866", Name="NoUnderlyingMarketDisruptionFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingMarketDisruptionFallbackReferencePrices(fix.Field, Tag="41868", Name="NoUnderlyingMarketDisruptionFallbackReferencePrices", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingOptionExerciseBusinessCenters(fix.Field, Tag="41820", Name="NoUnderlyingOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingOptionExerciseDates(fix.Field, Tag="41841", Name="NoUnderlyingOptionExerciseDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingOptionExerciseExpirationDateBusinessCenters(fix.Field, Tag="41844", Name="NoUnderlyingOptionExerciseExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingOptionExerciseExpirationDates(fix.Field, Tag="41856", Name="NoUnderlyingOptionExerciseExpirationDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreams(fix.Field, Tag="40540", Name="NoUnderlyingStreams", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommodityAltIDs(fix.Field, Tag="41990", Name="NoUnderlyingStreamCommodityAltIDs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamAssetAttributes(fix.Field, Tag="41800", Name="NoUnderlyingStreamAssetAttributes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommodityDataSources(fix.Field, Tag="41993", Name="NoUnderlyingStreamCommodityDataSources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommoditySettlBusinessCenters(fix.Field, Tag="41962", Name="NoUnderlyingStreamCommoditySettlBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommoditySettlPeriods(fix.Field, Tag="42002", Name="NoUnderlyingStreamCommoditySettlPeriods", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommoditySettlDays(fix.Field, Tag="41996", Name="NoUnderlyingStreamCommoditySettlDays", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCommoditySettlTimes(fix.Field, Tag="41999", Name="NoUnderlyingStreamCommoditySettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamEffectiveDateBusinessCenters(fix.Field, Tag="40975", Name="NoUnderlyingStreamEffectiveDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamTerminationDateBusinessCenters(fix.Field, Tag="40976", Name="NoUnderlyingStreamTerminationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCalculationPeriodBusinessCenters(fix.Field, Tag="40973", Name="NoUnderlyingStreamCalculationPeriodBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamCalculationPeriodDates(fix.Field, Tag="41954", Name="NoUnderlyingStreamCalculationPeriodDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingStreamFirstPeriodStartDateBusinessCenters(fix.Field, Tag="40974", Name="NoUnderlyingStreamFirstPeriodStartDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamPaymentDateBusinessCenters(fix.Field, Tag="40969", Name="NoUnderlyingPaymentStreamPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamPaymentDates(fix.Field, Tag="41937", Name="NoUnderlyingPaymentStreamPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamResetDateBusinessCenters(fix.Field, Tag="40970", Name="NoUnderlyingPaymentStreamResetDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamInitialFixingDateBusinessCenters(fix.Field, Tag="40971", Name="NoUnderlyingPaymentStreamInitialFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamFixingDateBusinessCenters(fix.Field, Tag="40972", Name="NoUnderlyingPaymentStreamFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamPricingBusinessCenters(fix.Field, Tag="41909", Name="NoUnderlyingPaymentStreamPricingBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamPricingDays(fix.Field, Tag="41944", Name="NoUnderlyingPaymentStreamPricingDays", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamPricingDates(fix.Field, Tag="41941", Name="NoUnderlyingPaymentStreamPricingDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStreamNonDeliverableFixingDatesBusinessCenters(fix.Field, Tag="40968", Name="NoUnderlyingPaymentStreamNonDeliverableFixingDatesBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingNonDeliverableFixingDates(fix.Field, Tag="40656", Name="NoUnderlyingNonDeliverableFixingDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingSettlRateFallbacks(fix.Field, Tag="40659", Name="NoUnderlyingSettlRateFallbacks", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentSchedules(fix.Field, Tag="40664", Name="NoUnderlyingPaymentSchedules", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentScheduleRateSources(fix.Field, Tag="40704", Name="NoUnderlyingPaymentScheduleRateSources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentScheduleFixingDateBusinessCenters(fix.Field, Tag="40966", Name="NoUnderlyingPaymentScheduleFixingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentScheduleFixingDays(fix.Field, Tag="41878", Name="NoUnderlyingPaymentScheduleFixingDays", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentScheduleInterimExchangeDateBusinessCenters(fix.Field, Tag="40967", Name="NoUnderlyingPaymentScheduleInterimExchangeDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPaymentStubs(fix.Field, Tag="40708", Name="NoUnderlyingPaymentStubs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingDeliveryStreamCommoditySources(fix.Field, Tag="41808", Name="NoUnderlyingDeliveryStreamCommoditySources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingDeliveryStreamCycles(fix.Field, Tag="41804", Name="NoUnderlyingDeliveryStreamCycles", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingDeliverySchedules(fix.Field, Tag="41756", Name="NoUnderlyingDeliverySchedules", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingDeliveryScheduleSettlDays(fix.Field, Tag="41770", Name="NoUnderlyingDeliveryScheduleSettlDays", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingDeliveryScheduleSettlTimes(fix.Field, Tag="41773", Name="NoUnderlyingDeliveryScheduleSettlTimes", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisions(fix.Field, Tag="42149", Name="NoUnderlyingProvisions", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionDateBusinessCenters(fix.Field, Tag="42190", Name="NoUnderlyingProvisionDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionCashSettlValueDateBusinessCenters(fix.Field, Tag="42182", Name="NoUnderlyingProvisionCashSettlValueDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionOptionExerciseBusinessCenters(fix.Field, Tag="42184", Name="NoUnderlyingProvisionOptionExerciseBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionOptionExerciseFixedDates(fix.Field, Tag="42112", Name="NoUnderlyingProvisionOptionExerciseFixedDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionOptionExpirationDateBusinessCenters(fix.Field, Tag="42186", Name="NoUnderlyingProvisionOptionExpirationDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionOptionRelevantUnderlyingDateBusinessCenters(fix.Field, Tag="42188", Name="NoUnderlyingProvisionOptionRelevantUnderlyingDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionCashSettlPaymentDateBusinessCenters(fix.Field, Tag="42180", Name="NoUnderlyingProvisionCashSettlPaymentDateBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionCashSettlPaymentDates(fix.Field, Tag="42099", Name="NoUnderlyingProvisionCashSettlPaymentDates", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionPartyIDs(fix.Field, Tag="42173", Name="NoUnderlyingProvisionPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProvisionPartySubIDs(fix.Field, Tag="42177", Name="NoUnderlyingProvisionPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingAdditionalTerms(fix.Field, Tag="42036", Name="NoUnderlyingAdditionalTerms", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingAdditionalTermBondRefs(fix.Field, Tag="41340", Name="NoUnderlyingAdditionalTermBondRefs", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProtectionTerms(fix.Field, Tag="42068", Name="NoUnderlyingProtectionTerms", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProtectionTermEventNewsSources(fix.Field, Tag="42090", Name="NoUnderlyingProtectionTermEventNewsSources", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProtectionTermEvents(fix.Field, Tag="42077", Name="NoUnderlyingProtectionTermEvents", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProtectionTermEventQualifiers(fix.Field, Tag="42085", Name="NoUnderlyingProtectionTermEventQualifiers", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingProtectionTermObligations(fix.Field, Tag="42087", Name="NoUnderlyingProtectionTermObligations", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingCashSettlTerms(fix.Field, Tag="42041", Name="NoUnderlyingCashSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingCashSettlDealers(fix.Field, Tag="42039", Name="NoUnderlyingCashSettlDealers", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPhysicalSettlTerms(fix.Field, Tag="42060", Name="NoUnderlyingPhysicalSettlTerms", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingPhysicalSettlDeliverableObligations(fix.Field, Tag="42065", Name="NoUnderlyingPhysicalSettlDeliverableObligations", Type=fix.FixInt):
    Values = {
    }


class NoLinesOfText(fix.Field, Tag="33", Name="NoLinesOfText", Type=fix.FixInt):
    Values = {
    }


class URLLink(fix.Field, Tag="149", Name="URLLink", Type=fix.FixString):
    Values = {
    }


class UserRequestID(fix.Field, Tag="923", Name="UserRequestID", Type=fix.FixString):
    Values = {
    }


class UserRequestType(fix.Field, Tag="924", Name="UserRequestType", Type=fix.FixInt):
    Values = {
        1: 'LogOnUser',
        2: 'LogOffUser',
        3: 'ChangePasswordForUser',
        4: 'RequestIndividualUserStatus',
        5: 'RequestThrottleLimit',
    }
    LogOnUser = 1
    LogOffUser = 2
    ChangePasswordForUser = 3
    RequestIndividualUserStatus = 4
    RequestThrottleLimit = 5


class ClOrdID(fix.Field, Tag="11", Name="ClOrdID", Type=fix.FixString):
    Values = {
    }


class SecondaryClOrdID(fix.Field, Tag="526", Name="SecondaryClOrdID", Type=fix.FixString):
    Values = {
    }


class NoPartyIDs(fix.Field, Tag="453", Name="NoPartyIDs", Type=fix.FixInt):
    Values = {
    }


class PartyID(fix.Field, Tag="448", Name="PartyID", Type=fix.FixString):
    Values = {
    }


class PartyIDSource(fix.Field, Tag="447", Name="PartyIDSource", Type=fix.FixChar):
    Values = {
        '1': 'KoreanInvestorID',
        '2': 'TaiwaneseForeignInvestorID',
        '3': 'TaiwaneseTradingAcct',
        '4': 'MalaysianCentralDepository',
        '5': 'ChineseInvestorID',
        '6': 'UKNationalInsuranceOrPensionNumber',
        '7': 'USSocialSecurityNumber',
        '8': 'USEmployerOrTaxIDNumber',
        '9': 'AustralianBusinessNumber',
        'A': 'AustralianTaxFileNumber',
        'B': 'BIC',
        'C': 'GeneralIdentifier',
        'D': 'Proprietary',
        'E': 'ISOCountryCode',
        'F': 'SettlementEntityLocation',
        'G': 'MIC',
        'H': 'CSDParticipant',
        'I': 'ISITCAcronym',
        'J': 'TaxID',
        'K': 'AustralianCompanyNumber',
        'L': 'AustralianRegisteredBodyNumber',
        'M': 'CFTCReportingFirmIdentifier',
        'N': 'LegalEntityIdentifier',
        'O': 'InterimIdentifier',
        'P': 'ShortCodeIdentifier',
    }
    KoreanInvestorID = '1'
    TaiwaneseForeignInvestorID = '2'
    TaiwaneseTradingAcct = '3'
    MalaysianCentralDepository = '4'
    ChineseInvestorID = '5'
    UKNationalInsuranceOrPensionNumber = '6'
    USSocialSecurityNumber = '7'
    USEmployerOrTaxIDNumber = '8'
    AustralianBusinessNumber = '9'
    AustralianTaxFileNumber = 'A'
    BIC = 'B'
    GeneralIdentifier = 'C'
    Proprietary = 'D'
    ISOCountryCode = 'E'
    SettlementEntityLocation = 'F'
    MIC = 'G'
    CSDParticipant = 'H'
    ISITCAcronym = 'I'
    TaxID = 'J'
    AustralianCompanyNumber = 'K'
    AustralianRegisteredBodyNumber = 'L'
    CFTCReportingFirmIdentifier = 'M'
    LegalEntityIdentifier = 'N'
    InterimIdentifier = 'O'
    ShortCodeIdentifier = 'P'


class PartyRole(fix.Field, Tag="452", Name="PartyRole", Type=fix.FixInt):
    Values = {
        1: 'ExecutingFirm',
        10: 'SettlementLocation',
        100: 'MarginAccount',
        101: 'CollateralAssetAccount',
        102: 'DataRepository',
        103: 'CalculationAgent',
        104: 'ExerciseNoticeSender',
        105: 'ExerciseNoticeReceiver',
        106: 'RateReferenceBank',
        107: 'Correspondent',
        109: 'BeneficiaryBank',
        11: 'OrderOriginationTrader',
        110: 'Borrower',
        111: 'PrimaryObligator',
        112: 'Guarantor',
        113: 'ExcludedReferenceEntity',
        114: 'DeterminingParty',
        115: 'HedgingParty',
        116: 'ReportingEntity',
        117: 'SalesPerson',
        118: 'Operator',
        119: 'CSD',
        12: 'ExecutingTrader',
        120: 'ICSD',
        122: 'InvestmentDecisionMaker',
        125: 'Issuer',
        13: 'OrderOriginationFirm',
        14: 'GiveupClearingFirmfirmtowhichtradeisgivenup',
        15: 'CorrespondantClearingFirm',
        16: 'ExecutingSystem',
        17: 'ContraFirm',
        18: 'ContraClearingFirm',
        19: 'SponsoringFirm',
        2: 'BrokerOfCredit',
        20: 'UnderlyingContraFirm',
        21: 'ClearingOrganization',
        22: 'Exchange',
        24: 'CustomerAccount',
        25: 'CorrespondentClearingOrganization',
        26: 'CorrespondentBroker',
        27: 'Buyer',
        28: 'Custodian',
        29: 'Intermediary',
        3: 'ClientID',
        30: 'Agent',
        31: 'SubCustodian',
        32: 'Beneficiary',
        33: 'InterestedParty',
        34: 'RegulatoryBody',
        35: 'LiquidityProvider',
        36: 'EnteringTrader',
        37: 'ContraTrader',
        38: 'PositionAccount',
        39: 'ContraInvestorID',
        4: 'ClearingFirm',
        40: 'TransferToFirm',
        41: 'ContraPositionAccount',
        42: 'ContraExchange',
        43: 'InternalCarryAccount',
        44: 'OrderEntryOperatorID',
        45: 'SecondaryAccountNumber',
        46: 'ForeignFirm',
        47: 'ThirdPartyAllocationFirm',
        48: 'ClaimingAccount',
        49: 'AssetManager',
        5: 'InvestorID',
        50: 'PledgorAccount',
        51: 'PledgeeAccount',
        52: 'LargeTraderReportableAccount',
        53: 'TraderMnemonic',
        54: 'SenderLocation',
        55: 'SessionID',
        56: 'AcceptableCounterparty',
        57: 'UnacceptableCounterparty',
        58: 'EnteringUnit',
        59: 'ExecutingUnit',
        6: 'IntroducingFirm',
        60: 'IntroducingBroker',
        61: 'QuoteOriginator',
        62: 'ReportOriginator',
        63: 'SystematicInternaliser',
        64: 'MultilateralTradingFacility',
        65: 'RegulatedMarket',
        66: 'MarketMaker',
        67: 'InvestmentFirm',
        68: 'HostCompetentAuthority',
        69: 'HomeCompetentAuthority',
        7: 'EnteringFirm',
        70: 'CompetentAuthorityLiquidity',
        71: 'CompetentAuthorityTransactionVenue',
        72: 'ReportingIntermediary',
        73: 'ExecutionVenue',
        74: 'MarketDataEntryOriginator',
        75: 'LocationID',
        76: 'DeskID',
        77: 'MarketDataMarket',
        78: 'AllocationEntity',
        79: 'PrimeBroker',
        8: 'Locate',
        80: 'StepOutFirm',
        81: 'BrokerClearingID',
        82: 'CentralRegistrationDepository',
        83: 'ClearingAccount',
        84: 'AcceptableSettlingCounterparty',
        85: 'UnacceptableSettlingCounterparty',
        86: 'CLSMemberBank',
        87: 'InConcertGroup',
        88: 'InConcertControllingEntity',
        89: 'LargePositionsReportingAccount',
        9: 'FundManagerClientID',
        90: 'SettlementFirm',
        91: 'SettlementAccount',
        92: 'ReportingMarketCenter',
        93: 'RelatedReportingMarketCenter',
        94: 'AwayMarket',
        95: 'GiveupTradingFirm',
        96: 'TakeupTradingFirm',
        97: 'GiveupClearingFirm',
        98: 'TakeupClearingFirm',
        99: 'OriginatingMarket',
    }
    ExecutingFirm = 1
    SettlementLocation = 10
    MarginAccount = 100
    CollateralAssetAccount = 101
    DataRepository = 102
    CalculationAgent = 103
    ExerciseNoticeSender = 104
    ExerciseNoticeReceiver = 105
    RateReferenceBank = 106
    Correspondent = 107
    BeneficiaryBank = 109
    OrderOriginationTrader = 11
    Borrower = 110
    PrimaryObligator = 111
    Guarantor = 112
    ExcludedReferenceEntity = 113
    DeterminingParty = 114
    HedgingParty = 115
    ReportingEntity = 116
    SalesPerson = 117
    Operator = 118
    CSD = 119
    ExecutingTrader = 12
    ICSD = 120
    InvestmentDecisionMaker = 122
    Issuer = 125
    OrderOriginationFirm = 13
    GiveupClearingFirmfirmtowhichtradeisgivenup = 14
    CorrespondantClearingFirm = 15
    ExecutingSystem = 16
    ContraFirm = 17
    ContraClearingFirm = 18
    SponsoringFirm = 19
    BrokerOfCredit = 2
    UnderlyingContraFirm = 20
    ClearingOrganization = 21
    Exchange = 22
    CustomerAccount = 24
    CorrespondentClearingOrganization = 25
    CorrespondentBroker = 26
    Buyer = 27
    Custodian = 28
    Intermediary = 29
    ClientID = 3
    Agent = 30
    SubCustodian = 31
    Beneficiary = 32
    InterestedParty = 33
    RegulatoryBody = 34
    LiquidityProvider = 35
    EnteringTrader = 36
    ContraTrader = 37
    PositionAccount = 38
    ContraInvestorID = 39
    ClearingFirm = 4
    TransferToFirm = 40
    ContraPositionAccount = 41
    ContraExchange = 42
    InternalCarryAccount = 43
    OrderEntryOperatorID = 44
    SecondaryAccountNumber = 45
    ForeignFirm = 46
    ThirdPartyAllocationFirm = 47
    ClaimingAccount = 48
    AssetManager = 49
    InvestorID = 5
    PledgorAccount = 50
    PledgeeAccount = 51
    LargeTraderReportableAccount = 52
    TraderMnemonic = 53
    SenderLocation = 54
    SessionID = 55
    AcceptableCounterparty = 56
    UnacceptableCounterparty = 57
    EnteringUnit = 58
    ExecutingUnit = 59
    IntroducingFirm = 6
    IntroducingBroker = 60
    QuoteOriginator = 61
    ReportOriginator = 62
    SystematicInternaliser = 63
    MultilateralTradingFacility = 64
    RegulatedMarket = 65
    MarketMaker = 66
    InvestmentFirm = 67
    HostCompetentAuthority = 68
    HomeCompetentAuthority = 69
    EnteringFirm = 7
    CompetentAuthorityLiquidity = 70
    CompetentAuthorityTransactionVenue = 71
    ReportingIntermediary = 72
    ExecutionVenue = 73
    MarketDataEntryOriginator = 74
    LocationID = 75
    DeskID = 76
    MarketDataMarket = 77
    AllocationEntity = 78
    PrimeBroker = 79
    Locate = 8
    StepOutFirm = 80
    BrokerClearingID = 81
    CentralRegistrationDepository = 82
    ClearingAccount = 83
    AcceptableSettlingCounterparty = 84
    UnacceptableSettlingCounterparty = 85
    CLSMemberBank = 86
    InConcertGroup = 87
    InConcertControllingEntity = 88
    LargePositionsReportingAccount = 89
    FundManagerClientID = 9
    SettlementFirm = 90
    SettlementAccount = 91
    ReportingMarketCenter = 92
    RelatedReportingMarketCenter = 93
    AwayMarket = 94
    GiveupTradingFirm = 95
    TakeupTradingFirm = 96
    GiveupClearingFirm = 97
    TakeupClearingFirm = 98
    OriginatingMarket = 99


class PartyRoleQualifier(fix.Field, Tag="2376", Name="PartyRoleQualifier", Type=fix.FixInt):
    Values = {
    }


class NoPartySubIDs(fix.Field, Tag="802", Name="NoPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class PartySubID(fix.Field, Tag="523", Name="PartySubID", Type=fix.FixString):
    Values = {
    }


class PartySubIDType(fix.Field, Tag="803", Name="PartySubIDType", Type=fix.FixInt):
    Values = {
        1: 'Firm',
        10: 'SecuritiesAccountNumber',
        11: 'RegistrationNumber',
        12: 'RegisteredAddressForConfirmation',
        13: 'RegulatoryStatus',
        14: 'RegistrationName',
        15: 'CashAccountNumber',
        16: 'BIC',
        17: 'CSDParticipantMemberCode',
        18: 'RegisteredAddress',
        19: 'FundAccountName',
        2: 'Person',
        20: 'TelexNumber',
        21: 'FaxNumber',
        22: 'SecuritiesAccountName',
        23: 'CashAccountName',
        24: 'Department',
        25: 'LocationDesk',
        26: 'PositionAccountType',
        27: 'SecurityLocateID',
        28: 'MarketMaker',
        29: 'EligibleCounterparty',
        3: 'System',
        30: 'ProfessionalClient',
        31: 'Location',
        32: 'ExecutionVenue',
        33: 'CurrencyDeliveryIdentifier',
        34: 'AddressCity',
        35: 'AddressStateOrProvince',
        36: 'AddressPostalCode',
        37: 'AddressStreet',
        38: 'AddressISOCountryCode',
        39: 'ISOCountryCode',
        4: 'Application',
        40: 'MarketSegment',
        4028: 'MarketMIC',
        4029: 'TradingSession',
        4030: 'OrderSource',
        41: 'CustomerAccountType',
        42: 'OmnibusAccount',
        43: 'FundsSegregationType',
        44: 'GuaranteeFund',
        45: 'SwapDealer',
        46: 'MajorParticipant',
        47: 'FinancialEntity',
        48: 'USPerson',
        49: 'ReportingEntityIndicator',
        5: 'FullLegalNameOfFirm',
        50: 'ElectedClearingRequirementException',
        51: 'BusinessCenter',
        52: 'ReferenceText',
        53: 'ShortMarkingExemptAccount',
        54: 'ParentFirmIdentifier',
        55: 'ParentFirmName',
        56: 'DealIdentifier',
        57: 'SystemTradeID',
        58: 'SystemTradeSubID',
        59: 'FCMCode',
        6: 'PostalAddress',
        60: 'DlvryTrmlCode',
        61: 'VolntyRptEntity',
        62: 'RptObligJursdctn',
        63: 'VolntyRptJursdctn',
        64: 'CompanyActivities',
        65: 'EEAreaDomiciled',
        66: 'ContractLinked',
        67: 'ContractAbove',
        68: 'VolntyRptPty',
        69: 'EndUser',
        7: 'PhoneNumber',
        70: 'LocationOrJurisdiction',
        71: 'DerivativesDealer',
        72: 'Domicile',
        73: 'ExemptFromRecognition',
        74: 'Payer',
        75: 'Receiver',
        8: 'EmailAddress',
        9: 'ContactName',
    }
    Firm = 1
    SecuritiesAccountNumber = 10
    RegistrationNumber = 11
    RegisteredAddressForConfirmation = 12
    RegulatoryStatus = 13
    RegistrationName = 14
    CashAccountNumber = 15
    BIC = 16
    CSDParticipantMemberCode = 17
    RegisteredAddress = 18
    FundAccountName = 19
    Person = 2
    TelexNumber = 20
    FaxNumber = 21
    SecuritiesAccountName = 22
    CashAccountName = 23
    Department = 24
    LocationDesk = 25
    PositionAccountType = 26
    SecurityLocateID = 27
    MarketMaker = 28
    EligibleCounterparty = 29
    System = 3
    ProfessionalClient = 30
    Location = 31
    ExecutionVenue = 32
    CurrencyDeliveryIdentifier = 33
    AddressCity = 34
    AddressStateOrProvince = 35
    AddressPostalCode = 36
    AddressStreet = 37
    AddressISOCountryCode = 38
    ISOCountryCode = 39
    Application = 4
    MarketSegment = 40
    MarketMIC = 4028
    TradingSession = 4029
    OrderSource = 4030
    CustomerAccountType = 41
    OmnibusAccount = 42
    FundsSegregationType = 43
    GuaranteeFund = 44
    SwapDealer = 45
    MajorParticipant = 46
    FinancialEntity = 47
    USPerson = 48
    ReportingEntityIndicator = 49
    FullLegalNameOfFirm = 5
    ElectedClearingRequirementException = 50
    BusinessCenter = 51
    ReferenceText = 52
    ShortMarkingExemptAccount = 53
    ParentFirmIdentifier = 54
    ParentFirmName = 55
    DealIdentifier = 56
    SystemTradeID = 57
    SystemTradeSubID = 58
    FCMCode = 59
    PostalAddress = 6
    DlvryTrmlCode = 60
    VolntyRptEntity = 61
    RptObligJursdctn = 62
    VolntyRptJursdctn = 63
    CompanyActivities = 64
    EEAreaDomiciled = 65
    ContractLinked = 66
    ContractAbove = 67
    VolntyRptPty = 68
    EndUser = 69
    PhoneNumber = 7
    LocationOrJurisdiction = 70
    DerivativesDealer = 71
    Domicile = 72
    ExemptFromRecognition = 73
    Payer = 74
    Receiver = 75
    EmailAddress = 8
    ContactName = 9


class NoTargetPartyIDs(fix.Field, Tag="1461", Name="NoTargetPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoTargetPartySubIDs(fix.Field, Tag="2433", Name="NoTargetPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class TradeDate(fix.Field, Tag="75", Name="TradeDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class Account(fix.Field, Tag="1", Name="Account", Type=fix.FixString):
    Values = {
    }


class NoAllocs(fix.Field, Tag="78", Name="NoAllocs", Type=fix.FixInt):
    Values = {
    }


class NoNestedPartySubIDs(fix.Field, Tag="804", Name="NoNestedPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class SettlDate(fix.Field, Tag="64", Name="SettlDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class ExecInst(fix.Field, Tag="18", Name="ExecInst", Type=fix.FixString):
    Values = {
        '0': 'StayOnOfferSide',
        '1': 'NotHeld',
        '2': 'Work',
        '3': 'GoAlong',
        '4': 'OverTheDay',
        '5': 'Held',
        '6': 'ParticipateDoNotInitiate',
        '7': 'StrictScale',
        '8': 'TryToScale',
        '9': 'StayOnBidSide',
        'A': 'NoCross',
        'B': 'OKToCross',
        'C': 'CallFirst',
        'D': 'PercentOfVolume',
        'E': 'DoNotIncrease',
        'F': 'DoNotReduce',
        'G': 'AllOrNone',
        'H': 'ReinstateOnSystemFailure',
        'I': 'InstitutionsOnly',
        'J': 'ReinstateOnTradingHalt',
        'K': 'CancelOnTradingHalt',
        'L': 'Lastpeglastsale',
        'M': 'Midpricepegmidpriceofinsidequote',
        'N': 'NonNegotiable',
        'O': 'Openingpeg',
        'P': 'Marketpeg',
        'Q': 'CancelOnSystemFailure',
        'R': 'Primarypeg',
        'S': 'Suspend',
        'T': 'Fixedpegtolocalbestbidorofferattimeoforder',
        'U': 'CustomerDisplayInstruction',
        'V': 'Netting',
        'W': 'PegtoVWAP',
        'X': 'TradeAlong',
        'Y': 'TryToStop',
        'Z': 'CancelIfNotBest',
        'a': 'Trailingstoppeg',
        'b': 'StrictLimit',
        'c': 'IgnorePriceValidityChecks',
        'd': 'Pegtolimitprice',
        'e': 'WorkToTargetStrategy',
        'f': 'IntermarketSweep',
        'g': 'ExternalRoutingAllowed',
        'h': 'ExternalRoutingNotAllowed',
        'i': 'ImbalanceOnly',
        'j': 'SingleExecutionRequestedForBlockTrade',
        'k': 'BestExecution',
        'l': 'SuspendOnSystemFailure',
        'm': 'SuspendOnTradingHalt',
        'n': 'ReinstateOnConnectionLoss',
        'o': 'CancelOnConnectionLoss',
        'p': 'SuspendOnConnectionLoss',
        'q': 'Release',
        'r': 'ExecuteAsDeltaNeutral',
        's': 'ExecuteAsDurationNeutral',
        't': 'ExecuteAsFXNeutral',
        'u': 'MinGuaranteedFillEligible',
        'v': 'BypassNonDisplayLiquidity',
        'w': 'Lock',
        'x': 'IgnoreNotionalValueChecks',
    }
    StayOnOfferSide = '0'
    NotHeld = '1'
    Work = '2'
    GoAlong = '3'
    OverTheDay = '4'
    Held = '5'
    ParticipateDoNotInitiate = '6'
    StrictScale = '7'
    TryToScale = '8'
    StayOnBidSide = '9'
    NoCross = 'A'
    OKToCross = 'B'
    CallFirst = 'C'
    PercentOfVolume = 'D'
    DoNotIncrease = 'E'
    DoNotReduce = 'F'
    AllOrNone = 'G'
    ReinstateOnSystemFailure = 'H'
    InstitutionsOnly = 'I'
    ReinstateOnTradingHalt = 'J'
    CancelOnTradingHalt = 'K'
    Lastpeglastsale = 'L'
    Midpricepegmidpriceofinsidequote = 'M'
    NonNegotiable = 'N'
    Openingpeg = 'O'
    Marketpeg = 'P'
    CancelOnSystemFailure = 'Q'
    Primarypeg = 'R'
    Suspend = 'S'
    Fixedpegtolocalbestbidorofferattimeoforder = 'T'
    CustomerDisplayInstruction = 'U'
    Netting = 'V'
    PegtoVWAP = 'W'
    TradeAlong = 'X'
    TryToStop = 'Y'
    CancelIfNotBest = 'Z'
    Trailingstoppeg = 'a'
    StrictLimit = 'b'
    IgnorePriceValidityChecks = 'c'
    Pegtolimitprice = 'd'
    WorkToTargetStrategy = 'e'
    IntermarketSweep = 'f'
    ExternalRoutingAllowed = 'g'
    ExternalRoutingNotAllowed = 'h'
    ImbalanceOnly = 'i'
    SingleExecutionRequestedForBlockTrade = 'j'
    BestExecution = 'k'
    SuspendOnSystemFailure = 'l'
    SuspendOnTradingHalt = 'm'
    ReinstateOnConnectionLoss = 'n'
    CancelOnConnectionLoss = 'o'
    SuspendOnConnectionLoss = 'p'
    Release = 'q'
    ExecuteAsDeltaNeutral = 'r'
    ExecuteAsDurationNeutral = 's'
    ExecuteAsFXNeutral = 't'
    MinGuaranteedFillEligible = 'u'
    BypassNonDisplayLiquidity = 'v'
    Lock = 'w'
    IgnoreNotionalValueChecks = 'x'


class MinQty(fix.Field, Tag="110", Name="MinQty", Type=fix.FixQuantity):
    Values = {
    }


class MatchIncrement(fix.Field, Tag="1089", Name="MatchIncrement", Type=fix.FixQuantity):
    Values = {
    }


class NoMatchInst(fix.Field, Tag="1624", Name="NoMatchInst", Type=fix.FixInt):
    Values = {
    }


class DisplayQty(fix.Field, Tag="1138", Name="DisplayQty", Type=fix.FixQuantity):
    Values = {
    }


class InitialDisplayQty(fix.Field, Tag="1608", Name="InitialDisplayQty", Type=fix.FixQuantity):
    Values = {
    }


class DisplayMethod(fix.Field, Tag="1084", Name="DisplayMethod", Type=fix.FixChar):
    Values = {
        '1': 'Initial',
        '2': 'New',
        '3': 'Random',
        '4': 'Undisclosed',
    }
    Initial = '1'
    New = '2'
    Random = '3'
    Undisclosed = '4'


class RefreshQty(fix.Field, Tag="1088", Name="RefreshQty", Type=fix.FixQuantity):
    Values = {
    }


class NoDisclosureInstructions(fix.Field, Tag="1812", Name="NoDisclosureInstructions", Type=fix.FixInt):
    Values = {
    }


class ExDestination(fix.Field, Tag="100", Name="ExDestination", Type=fix.FixExchange):
    Values = {
    }


class NoTradingSessions(fix.Field, Tag="386", Name="NoTradingSessions", Type=fix.FixInt):
    Values = {
    }


class TradingSessionID(fix.Field, Tag="336", Name="TradingSessionID", Type=fix.FixString):
    Values = {
        '1': 'Day',
        '102': 'AllTradingSessions',
        '103': 'TriggeronSessionsubtype',
        '104': 'GoodtillendofSessionsubtype',
        '2': 'HalfDay',
        '3': 'Morning',
        '4': 'Afternoon',
        '5': 'Evening',
        '6': 'AfterHours',
        '7': 'Holiday',
    }
    Day = '1'
    AllTradingSessions = '102'
    TriggeronSessionsubtype = '103'
    GoodtillendofSessionsubtype = '104'
    HalfDay = '2'
    Morning = '3'
    Afternoon = '4'
    Evening = '5'
    AfterHours = '6'
    Holiday = '7'


class TradingSessionSubID(fix.Field, Tag="625", Name="TradingSessionSubID", Type=fix.FixString):
    Values = {
        '1': 'PreTrading',
        '10': 'OutOfMainSessionTrading',
        '11': 'PrivateAuction',
        '12': 'PublicAuction',
        '13': 'GroupAuction',
        '2': 'OpeningOrOpeningAuction',
        '3': 'Continuous',
        '4': 'ClosingOrClosingAuction',
        '5': 'PostTrading',
        '6': 'ScheduledIntradayAuction',
        '7': 'Quiescent',
        '8': 'AnyAuction',
        '9': 'UnscheduledIntradayAuction',
    }
    PreTrading = '1'
    OutOfMainSessionTrading = '10'
    PrivateAuction = '11'
    PublicAuction = '12'
    GroupAuction = '13'
    OpeningOrOpeningAuction = '2'
    Continuous = '3'
    ClosingOrClosingAuction = '4'
    PostTrading = '5'
    ScheduledIntradayAuction = '6'
    Quiescent = '7'
    AnyAuction = '8'
    UnscheduledIntradayAuction = '9'


class Side(fix.Field, Tag="54", Name="Side", Type=fix.FixChar):
    Values = {
        '1': 'Buy',
        '2': 'Sell',
        '3': 'BuyMinus',
        '4': 'SellPlus',
        '5': 'SellShort',
        '6': 'SellShortExempt',
        '7': 'Undisclosed',
        '8': 'Cross',
        '9': 'CrossShort',
        'A': 'CrossShortExempt',
        'B': 'AsDefined',
        'C': 'Opposite',
        'D': 'Subscribe',
        'E': 'Redeem',
        'F': 'Lend',
        'G': 'Borrow',
    }
    Buy = '1'
    Sell = '2'
    BuyMinus = '3'
    SellPlus = '4'
    SellShort = '5'
    SellShortExempt = '6'
    Undisclosed = '7'
    Cross = '8'
    CrossShort = '9'
    CrossShortExempt = 'A'
    AsDefined = 'B'
    Opposite = 'C'
    Subscribe = 'D'
    Redeem = 'E'
    Lend = 'F'
    Borrow = 'G'


class LocateReqd(fix.Field, Tag="114", Name="LocateReqd", Type=fix.FixBool):
    Values = {
        'N': 'No',
        'Y': 'Yes',
    }
    No = 'N'
    Yes = 'Y'


class TransactTime(fix.Field, Tag="60", Name="TransactTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class NoStipulations(fix.Field, Tag="232", Name="NoStipulations", Type=fix.FixInt):
    Values = {
    }


class OrderQty(fix.Field, Tag="38", Name="OrderQty", Type=fix.FixQuantity):
    Values = {
    }


class OrdType(fix.Field, Tag="40", Name="OrdType", Type=fix.FixChar):
    Values = {
        '1': 'Market',
        '2': 'Limit',
        '3': 'Stop',
        '4': 'StopLimit',
        '5': 'MarketOnCloseNolongerused',
        '6': 'WithOrWithout',
        '7': 'LimitOrBetter',
        '8': 'LimitWithOrWithout',
        '9': 'OnBasis',
        'A': 'OnCloseNolongerused',
        'B': 'LimitOnCloseNolongerused',
        'C': 'ForexMarketNolongerused',
        'D': 'PreviouslyQuoted',
        'E': 'PreviouslyIndicated',
        'F': 'ForexLimitNolongerused',
        'G': 'ForexSwap',
        'H': 'ForexPreviouslyQuotedNolongerused',
        'I': 'Funari',
        'J': 'MarketIfTouched',
        'K': 'MarketWithLeftOverAsLimit',
        'L': 'PreviousFundValuationPoint',
        'M': 'NextFundValuationPoint',
        'P': 'Pegged',
        'Q': 'CounterOrderSelection',
        'R': 'StopOnBidOrOffer',
        'S': 'StopLimitOnBidOrOffer',
    }
    Market = '1'
    Limit = '2'
    Stop = '3'
    StopLimit = '4'
    MarketOnCloseNolongerused = '5'
    WithOrWithout = '6'
    LimitOrBetter = '7'
    LimitWithOrWithout = '8'
    OnBasis = '9'
    OnCloseNolongerused = 'A'
    LimitOnCloseNolongerused = 'B'
    ForexMarketNolongerused = 'C'
    PreviouslyQuoted = 'D'
    PreviouslyIndicated = 'E'
    ForexLimitNolongerused = 'F'
    ForexSwap = 'G'
    ForexPreviouslyQuotedNolongerused = 'H'
    Funari = 'I'
    MarketIfTouched = 'J'
    MarketWithLeftOverAsLimit = 'K'
    PreviousFundValuationPoint = 'L'
    NextFundValuationPoint = 'M'
    Pegged = 'P'
    CounterOrderSelection = 'Q'
    StopOnBidOrOffer = 'R'
    StopLimitOnBidOrOffer = 'S'


class Price(fix.Field, Tag="44", Name="Price", Type=fix.FixPrice):
    Values = {
    }


class TriggerType(fix.Field, Tag="1100", Name="TriggerType", Type=fix.FixChar):
    Values = {
        '1': 'PartialExecution',
        '2': 'SpecifiedTradingSession',
        '3': 'NextAuction',
        '4': 'PriceMovement',
        '5': 'OnOrderEntryOrModification',
    }
    PartialExecution = '1'
    SpecifiedTradingSession = '2'
    NextAuction = '3'
    PriceMovement = '4'
    OnOrderEntryOrModification = '5'


class TriggerAction(fix.Field, Tag="1101", Name="TriggerAction", Type=fix.FixChar):
    Values = {
        '1': 'Activate',
        '2': 'Modify',
        '3': 'Cancel',
    }
    Activate = '1'
    Modify = '2'
    Cancel = '3'


class TriggerPrice(fix.Field, Tag="1102", Name="TriggerPrice", Type=fix.FixPrice):
    Values = {
    }


class TriggerSymbol(fix.Field, Tag="1103", Name="TriggerSymbol", Type=fix.FixString):
    Values = {
    }


class TriggerSecurityID(fix.Field, Tag="1104", Name="TriggerSecurityID", Type=fix.FixString):
    Values = {
    }


class TriggerSecurityIDSource(fix.Field, Tag="1105", Name="TriggerSecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class TriggerPriceType(fix.Field, Tag="1107", Name="TriggerPriceType", Type=fix.FixChar):
    Values = {
        '1': 'BestOffer',
        '2': 'LastTrade',
        '3': 'BestBid',
        '4': 'BestBidOrLastTrade',
        '5': 'BestOfferOrLastTrade',
        '6': 'BestMid',
    }
    BestOffer = '1'
    LastTrade = '2'
    BestBid = '3'
    BestBidOrLastTrade = '4'
    BestOfferOrLastTrade = '5'
    BestMid = '6'


class TriggerPriceDirection(fix.Field, Tag="1109", Name="TriggerPriceDirection", Type=fix.FixChar):
    Values = {
        'D': 'Down',
        'U': 'Up',
    }
    Down = 'D'
    Up = 'U'


class TriggerTradingSessionID(fix.Field, Tag="1113", Name="TriggerTradingSessionID", Type=fix.FixString):
    Values = {
    }


class Currency(fix.Field, Tag="15", Name="Currency", Type=fix.FixCurrency):
    Values = {
    }


class QuoteID(fix.Field, Tag="117", Name="QuoteID", Type=fix.FixString):
    Values = {
    }


class TimeInForce(fix.Field, Tag="59", Name="TimeInForce", Type=fix.FixChar):
    Values = {
        '0': 'Day',
        '1': 'GoodTillCancel',
        '2': 'AtTheOpening',
        '3': 'ImmediateOrCancel',
        '4': 'FillOrKill',
        '5': 'GoodTillCrossing',
        '6': 'GoodTillDate',
        '7': 'AtTheClose',
        '8': 'GoodThroughCrossing',
        '9': 'AtCrossing',
        'A': 'GoodForTime',
        'B': 'GoodForAuction',
        'S': 'GoodTillEndOfSession',
    }
    Day = '0'
    GoodTillCancel = '1'
    AtTheOpening = '2'
    ImmediateOrCancel = '3'
    FillOrKill = '4'
    GoodTillCrossing = '5'
    GoodTillDate = '6'
    AtTheClose = '7'
    GoodThroughCrossing = '8'
    AtCrossing = '9'
    GoodForTime = 'A'
    GoodForAuction = 'B'
    GoodTillEndOfSession = 'S'


class ExpireDate(fix.Field, Tag="432", Name="ExpireDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class ExposureDuration(fix.Field, Tag="1629", Name="ExposureDuration", Type=fix.FixInt):
    Values = {
    }


class NoCommissions(fix.Field, Tag="2639", Name="NoCommissions", Type=fix.FixInt):
    Values = {
    }


class OrderCapacity(fix.Field, Tag="528", Name="OrderCapacity", Type=fix.FixChar):
    Values = {
        'A': 'Agency',
        'G': 'Proprietary',
        'I': 'Individual',
        'M': 'MixedCapacity',
        'P': 'Principal',
        'R': 'RisklessPrincipal',
        'W': 'AgentForOtherMember',
    }
    Agency = 'A'
    Proprietary = 'G'
    Individual = 'I'
    MixedCapacity = 'M'
    Principal = 'P'
    RisklessPrincipal = 'R'
    AgentForOtherMember = 'W'


class OrderRestrictions(fix.Field, Tag="529", Name="OrderRestrictions", Type=fix.FixString):
    Values = {
        '1': 'ProgramTrade',
        '2': 'IndexArbitrage',
        '3': 'NonIndexArbitrage',
        '4': 'CompetingMarketMaker',
        '5': 'ActingAsMarketMakerOrSpecialistInSecurity',
        '6': 'ActingAsMarketMakerOrSpecialistInUnderlying',
        '7': 'ForeignEntity',
        '8': 'ExternalMarketParticipant',
        '9': 'ExternalInterConnectedMarketLinkage',
        'A': 'RisklessArbitrage',
        'B': 'IssuerHolding',
        'C': 'IssuePriceStabilization',
        'D': 'NonAlgorithmic',
        'E': 'Algorithmic',
        'F': 'Cross',
        'G': 'InsiderAccount',
        'H': 'SignificantShareholder',
        'I': 'NormalCourseIssuerBid',
    }
    ProgramTrade = '1'
    IndexArbitrage = '2'
    NonIndexArbitrage = '3'
    CompetingMarketMaker = '4'
    ActingAsMarketMakerOrSpecialistInSecurity = '5'
    ActingAsMarketMakerOrSpecialistInUnderlying = '6'
    ForeignEntity = '7'
    ExternalMarketParticipant = '8'
    ExternalInterConnectedMarketLinkage = '9'
    RisklessArbitrage = 'A'
    IssuerHolding = 'B'
    IssuePriceStabilization = 'C'
    NonAlgorithmic = 'D'
    Algorithmic = 'E'
    Cross = 'F'
    InsiderAccount = 'G'
    SignificantShareholder = 'H'
    NormalCourseIssuerBid = 'I'


class PreTradeAnonymity(fix.Field, Tag="1091", Name="PreTradeAnonymity", Type=fix.FixBool):
    Values = {
    }


class CustOrderCapacity(fix.Field, Tag="582", Name="CustOrderCapacity", Type=fix.FixInt):
    Values = {
        1: 'MemberTradingForTheirOwnAccount',
        2: 'ClearingFirmTradingForItsProprietaryAccount',
        3: 'MemberTradingForAnotherMember',
        4: 'AllOther',
        5: 'RetailCustomer',
    }
    MemberTradingForTheirOwnAccount = 1
    ClearingFirmTradingForItsProprietaryAccount = 2
    MemberTradingForAnotherMember = 3
    AllOther = 4
    RetailCustomer = 5


class SettlCurrency(fix.Field, Tag="120", Name="SettlCurrency", Type=fix.FixCurrency):
    Values = {
    }


class PositionEffect(fix.Field, Tag="77", Name="PositionEffect", Type=fix.FixChar):
    Values = {
        'C': 'Close',
        'D': 'Default',
        'F': 'FIFO',
        'N': 'CloseButNotifyOnOpen',
        'O': 'Open',
        'R': 'Rolled',
    }
    Close = 'C'
    Default = 'D'
    FIFO = 'F'
    CloseButNotifyOnOpen = 'N'
    Open = 'O'
    Rolled = 'R'


class PegOffsetValue(fix.Field, Tag="211", Name="PegOffsetValue", Type=fix.FixFloat):
    Values = {
    }


class PegPriceType(fix.Field, Tag="1094", Name="PegPriceType", Type=fix.FixInt):
    Values = {
        1: 'LastPeg',
        10: 'ShortSaleMinPricePeg',
        2: 'MidPricePeg',
        3: 'OpeningPeg',
        4: 'MarketPeg',
        5: 'PrimaryPeg',
        7: 'PegToVWAP',
        8: 'TrailingStopPeg',
        9: 'PegToLimitPrice',
    }
    LastPeg = 1
    ShortSaleMinPricePeg = 10
    MidPricePeg = 2
    OpeningPeg = 3
    MarketPeg = 4
    PrimaryPeg = 5
    PegToVWAP = 7
    TrailingStopPeg = 8
    PegToLimitPrice = 9


class PegMoveType(fix.Field, Tag="835", Name="PegMoveType", Type=fix.FixInt):
    Values = {
        0: 'Floating',
        1: 'Fixed',
    }
    Floating = 0
    Fixed = 1


class PegOffsetType(fix.Field, Tag="836", Name="PegOffsetType", Type=fix.FixInt):
    Values = {
        0: 'Price',
        1: 'BasisPoints',
        2: 'Ticks',
        3: 'PriceTier',
    }
    Price = 0
    BasisPoints = 1
    Ticks = 2
    PriceTier = 3


class PegSecurityIDSource(fix.Field, Tag="1096", Name="PegSecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class PegSecurityID(fix.Field, Tag="1097", Name="PegSecurityID", Type=fix.FixString):
    Values = {
    }


class PegSymbol(fix.Field, Tag="1098", Name="PegSymbol", Type=fix.FixString):
    Values = {
    }


class NoStrategyParameters(fix.Field, Tag="957", Name="NoStrategyParameters", Type=fix.FixInt):
    Values = {
    }


class CustOrderHandlingInst(fix.Field, Tag="1031", Name="CustOrderHandlingInst", Type=fix.FixMultipleValueString):
    Values = {
        'A': 'PhoneSimple',
        'ADD': 'AddOnOrder',
        'AON': 'AllOrNone',
        'B': 'PhoneComplex',
        'C': 'FCMProvidedScreen',
        'CND': 'ConditionalOrder',
        'CNH': 'CashNotHeld',
        'CSH': 'DeliveryInstructionsCash',
        'D': 'OtherProvidedScreen',
        'DIR': 'DirectedOrder',
        'DLO': 'DiscretionaryLimitOrder',
        'E': 'ClientProvidedPlatformControlledByFCM',
        'E.W': 'ExchangeForPhysicalTransaction',
        'F': 'ClientProvidedPlatformDirectToExchange',
        'F0': 'StayOnOfferside',
        'F3': 'GoAlong',
        'F6': 'ParticipateDoNotInitiate',
        'F7': 'StrictScale',
        'F8': 'TryToScale',
        'F9': 'StayOnBidside',
        'FA': 'NoCross',
        'FB': 'OKToCross',
        'FC': 'CallFirst',
        'FD': 'PercentOfVolume',
        'FH': 'ReinstateOnSystemFailure',
        'FI': 'InstitutionOnly',
        'FJ': 'ReinstateOnTradingHalt',
        'FK': 'CancelOnTradingHalf',
        'FL': 'LastPeg',
        'FM': 'MidPricePeg',
        'FN': 'NonNegotiable',
        'FO': 'OpeningPeg',
        'FOK': 'FillOrKill',
        'FP': 'MarketPeg',
        'FQ': 'CancelOnSystemFailure',
        'FR': 'PrimaryPeg',
        'FS': 'Suspend',
        'FT': 'FixedPegToLocalBBO',
        'FW': 'PegToVWAP',
        'FX': 'TradeAlong',
        'FY': 'TryToStop',
        'FZ': 'CancelIfNotBest',
        'Fb': 'StrictLimit',
        'Fc': 'IgnorePriceValidityChecks',
        'Fd': 'PegToLimitPrice',
        'Fe': 'WorkToTargetStrategy',
        'G': 'GOrderAndFCMAPIorFIX',
        'H': 'AlgoEngine',
        'IDX': 'IntraDayCross',
        'IO': 'ImbalanceOnly',
        'IOC': 'ImmediateOrCancel',
        'ISO': 'IntermarketSweepOrder',
        'J': 'PriceAtExecution',
        'LOC': 'LimitOnClose',
        'LOO': 'LimitOnOpen',
        'MAC': 'MarketAtClose',
        'MAO': 'MarketAtOpen',
        'MOC': 'MarketOnClose',
        'MOO': 'MarketOnOpen',
        'MPT': 'MergerRelatedTransferPosition',
        'MQT': 'MinimumQuantity',
        'MTL': 'MarketToLimit',
        'ND': 'DeliveryInstructionsNextDay',
        'NH': 'NotHeld',
        'OPT': 'OptionsRelatedTransaction',
        'OVD': 'OverTheDay',
        'PEG': 'Pegged',
        'RSV': 'ReserveSizeOrder',
        'S.W': 'StopStockTransaction',
        'SCL': 'Scale',
        'SLR': 'DeliveryInstructionsSellersOption',
        'TMO': 'TimeOrder',
        'TS': 'TrailingStop',
        'W': 'DeskElectronic',
        'WRK': 'Work',
        'X': 'DeskPit',
        'Y': 'ClientElectronic',
        'Z': 'ClientPit',
    }
    PhoneSimple = 'A'
    AddOnOrder = 'ADD'
    AllOrNone = 'AON'
    PhoneComplex = 'B'
    FCMProvidedScreen = 'C'
    ConditionalOrder = 'CND'
    CashNotHeld = 'CNH'
    DeliveryInstructionsCash = 'CSH'
    OtherProvidedScreen = 'D'
    DirectedOrder = 'DIR'
    DiscretionaryLimitOrder = 'DLO'
    ClientProvidedPlatformControlledByFCM = 'E'
    ExchangeForPhysicalTransaction = 'E.W'
    ClientProvidedPlatformDirectToExchange = 'F'
    StayOnOfferside = 'F0'
    GoAlong = 'F3'
    ParticipateDoNotInitiate = 'F6'
    StrictScale = 'F7'
    TryToScale = 'F8'
    StayOnBidside = 'F9'
    NoCross = 'FA'
    OKToCross = 'FB'
    CallFirst = 'FC'
    PercentOfVolume = 'FD'
    ReinstateOnSystemFailure = 'FH'
    InstitutionOnly = 'FI'
    ReinstateOnTradingHalt = 'FJ'
    CancelOnTradingHalf = 'FK'
    LastPeg = 'FL'
    MidPricePeg = 'FM'
    NonNegotiable = 'FN'
    OpeningPeg = 'FO'
    FillOrKill = 'FOK'
    MarketPeg = 'FP'
    CancelOnSystemFailure = 'FQ'
    PrimaryPeg = 'FR'
    Suspend = 'FS'
    FixedPegToLocalBBO = 'FT'
    PegToVWAP = 'FW'
    TradeAlong = 'FX'
    TryToStop = 'FY'
    CancelIfNotBest = 'FZ'
    StrictLimit = 'Fb'
    IgnorePriceValidityChecks = 'Fc'
    PegToLimitPrice = 'Fd'
    WorkToTargetStrategy = 'Fe'
    GOrderAndFCMAPIorFIX = 'G'
    AlgoEngine = 'H'
    IntraDayCross = 'IDX'
    ImbalanceOnly = 'IO'
    ImmediateOrCancel = 'IOC'
    IntermarketSweepOrder = 'ISO'
    PriceAtExecution = 'J'
    LimitOnClose = 'LOC'
    LimitOnOpen = 'LOO'
    MarketAtClose = 'MAC'
    MarketAtOpen = 'MAO'
    MarketOnClose = 'MOC'
    MarketOnOpen = 'MOO'
    MergerRelatedTransferPosition = 'MPT'
    MinimumQuantity = 'MQT'
    MarketToLimit = 'MTL'
    DeliveryInstructionsNextDay = 'ND'
    NotHeld = 'NH'
    OptionsRelatedTransaction = 'OPT'
    OverTheDay = 'OVD'
    Pegged = 'PEG'
    ReserveSizeOrder = 'RSV'
    StopStockTransaction = 'S.W'
    Scale = 'SCL'
    DeliveryInstructionsSellersOption = 'SLR'
    TimeOrder = 'TMO'
    TrailingStop = 'TS'
    DeskElectronic = 'W'
    Work = 'WRK'
    DeskPit = 'X'
    ClientElectronic = 'Y'
    ClientPit = 'Z'


class OrderOrigination(fix.Field, Tag="1724", Name="OrderOrigination", Type=fix.FixInt):
    Values = {
        1: 'OrderReceivedFromCustomer',
        2: 'OrderReceivedFromWithinFirm',
        3: 'OrderReceivedFromAnotherBrokerDealer',
        4: 'OrderReceivedFromCustomerOrWithFirm',
        5: 'OrderReceivedFromDirectAccessOrSponsoredAccessCustomer',
    }
    OrderReceivedFromCustomer = 1
    OrderReceivedFromWithinFirm = 2
    OrderReceivedFromAnotherBrokerDealer = 3
    OrderReceivedFromCustomerOrWithFirm = 4
    OrderReceivedFromDirectAccessOrSponsoredAccessCustomer = 5


class NoTrdRegTimestamps(fix.Field, Tag="768", Name="NoTrdRegTimestamps", Type=fix.FixInt):
    Values = {
    }


class TrdRegTimestamp(fix.Field, Tag="769", Name="TrdRegTimestamp", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class TrdRegTimestampType(fix.Field, Tag="770", Name="TrdRegTimestampType", Type=fix.FixInt):
    Values = {
        1: 'ExecutionTime',
        10: 'OrderSubmissionTime',
        11: 'PubliclyReported',
        12: 'PublicReportUpdated',
        13: 'NonPubliclyReported',
        14: 'NonPublicReportUpdated',
        15: 'SubmittedForConfirmation',
        16: 'UpdatedForConfirmation',
        17: 'Confirmed',
        18: 'UpdatedForClearing',
        19: 'Cleared',
        2: 'TimeIn',
        20: 'AllocationsSubmitted',
        21: 'AllocationsUpdated',
        22: 'ApplicationCompleted',
        23: 'SubmittedToRepository',
        24: 'PostTrdContntnEvnt',
        25: 'PostTradeValuation',
        3: 'TimeOut',
        4: 'BrokerReceipt',
        5: 'BrokerExecution',
        6: 'DeskReceipt',
        7: 'SubmissionToClearing',
        8: 'TimePriority',
        9: 'OrderbookEntryTime',
    }
    ExecutionTime = 1
    OrderSubmissionTime = 10
    PubliclyReported = 11
    PublicReportUpdated = 12
    NonPubliclyReported = 13
    NonPublicReportUpdated = 14
    SubmittedForConfirmation = 15
    UpdatedForConfirmation = 16
    Confirmed = 17
    UpdatedForClearing = 18
    Cleared = 19
    TimeIn = 2
    AllocationsSubmitted = 20
    AllocationsUpdated = 21
    ApplicationCompleted = 22
    SubmittedToRepository = 23
    PostTrdContntnEvnt = 24
    PostTradeValuation = 25
    TimeOut = 3
    BrokerReceipt = 4
    BrokerExecution = 5
    DeskReceipt = 6
    SubmissionToClearing = 7
    TimePriority = 8
    OrderbookEntryTime = 9


class DeskOrderHandlingInst(fix.Field, Tag="1035", Name="DeskOrderHandlingInst", Type=fix.FixMultipleValueString):
    Values = {
        'A': 'PhoneSimple',
        'ADD': 'AddOnOrder',
        'AON': 'AllOrNone',
        'B': 'PhoneComplex',
        'C': 'FCMProvidedScreen',
        'CND': 'ConditionalOrder',
        'CNH': 'CashNotHeld',
        'CSH': 'DeliveryInstructionsCash',
        'D': 'OtherProvidedScreen',
        'DIR': 'DirectedOrder',
        'DLO': 'DiscretionaryLimitOrder',
        'E': 'ClientProvidedPlatformControlledByFCM',
        'E.W': 'ExchangeForPhysicalTransaction',
        'F': 'ClientProvidedPlatformDirectToExchange',
        'F0': 'StayOnOfferside',
        'F3': 'GoAlong',
        'F6': 'ParticipateDoNotInitiate',
        'F7': 'StrictScale',
        'F8': 'TryToScale',
        'F9': 'StayOnBidside',
        'FA': 'NoCross',
        'FB': 'OKToCross',
        'FC': 'CallFirst',
        'FD': 'PercentOfVolume',
        'FH': 'ReinstateOnSystemFailure',
        'FI': 'InstitutionOnly',
        'FJ': 'ReinstateOnTradingHalt',
        'FK': 'CancelOnTradingHalf',
        'FL': 'LastPeg',
        'FM': 'MidPricePeg',
        'FN': 'NonNegotiable',
        'FO': 'OpeningPeg',
        'FOK': 'FillOrKill',
        'FP': 'MarketPeg',
        'FQ': 'CancelOnSystemFailure',
        'FR': 'PrimaryPeg',
        'FS': 'Suspend',
        'FT': 'FixedPegToLocalBBO',
        'FW': 'PegToVWAP',
        'FX': 'TradeAlong',
        'FY': 'TryToStop',
        'FZ': 'CancelIfNotBest',
        'Fb': 'StrictLimit',
        'Fc': 'IgnorePriceValidityChecks',
        'Fd': 'PegToLimitPrice',
        'Fe': 'WorkToTargetStrategy',
        'G': 'GOrderAndFCMAPIorFIX',
        'H': 'AlgoEngine',
        'IDX': 'IntraDayCross',
        'IO': 'ImbalanceOnly',
        'IOC': 'ImmediateOrCancel',
        'ISO': 'IntermarketSweepOrder',
        'J': 'PriceAtExecution',
        'LOC': 'LimitOnClose',
        'LOO': 'LimitOnOpen',
        'MAC': 'MarketAtClose',
        'MAO': 'MarketAtOpen',
        'MOC': 'MarketOnClose',
        'MOO': 'MarketOnOpen',
        'MPT': 'MergerRelatedTransferPosition',
        'MQT': 'MinimumQuantity',
        'MTL': 'MarketToLimit',
        'ND': 'DeliveryInstructionsNextDay',
        'NH': 'NotHeld',
        'OPT': 'OptionsRelatedTransaction',
        'OVD': 'OverTheDay',
        'PEG': 'Pegged',
        'RSV': 'ReserveSizeOrder',
        'S.W': 'StopStockTransaction',
        'SCL': 'Scale',
        'SLR': 'DeliveryInstructionsSellersOption',
        'TMO': 'TimeOrder',
        'TS': 'TrailingStop',
        'W': 'DeskElectronic',
        'WRK': 'Work',
        'X': 'DeskPit',
        'Y': 'ClientElectronic',
        'Z': 'ClientPit',
    }
    PhoneSimple = 'A'
    AddOnOrder = 'ADD'
    AllOrNone = 'AON'
    PhoneComplex = 'B'
    FCMProvidedScreen = 'C'
    ConditionalOrder = 'CND'
    CashNotHeld = 'CNH'
    DeliveryInstructionsCash = 'CSH'
    OtherProvidedScreen = 'D'
    DirectedOrder = 'DIR'
    DiscretionaryLimitOrder = 'DLO'
    ClientProvidedPlatformControlledByFCM = 'E'
    ExchangeForPhysicalTransaction = 'E.W'
    ClientProvidedPlatformDirectToExchange = 'F'
    StayOnOfferside = 'F0'
    GoAlong = 'F3'
    ParticipateDoNotInitiate = 'F6'
    StrictScale = 'F7'
    TryToScale = 'F8'
    StayOnBidside = 'F9'
    NoCross = 'FA'
    OKToCross = 'FB'
    CallFirst = 'FC'
    PercentOfVolume = 'FD'
    ReinstateOnSystemFailure = 'FH'
    InstitutionOnly = 'FI'
    ReinstateOnTradingHalt = 'FJ'
    CancelOnTradingHalf = 'FK'
    LastPeg = 'FL'
    MidPricePeg = 'FM'
    NonNegotiable = 'FN'
    OpeningPeg = 'FO'
    FillOrKill = 'FOK'
    MarketPeg = 'FP'
    CancelOnSystemFailure = 'FQ'
    PrimaryPeg = 'FR'
    Suspend = 'FS'
    FixedPegToLocalBBO = 'FT'
    PegToVWAP = 'FW'
    TradeAlong = 'FX'
    TryToStop = 'FY'
    CancelIfNotBest = 'FZ'
    StrictLimit = 'Fb'
    IgnorePriceValidityChecks = 'Fc'
    PegToLimitPrice = 'Fd'
    WorkToTargetStrategy = 'Fe'
    GOrderAndFCMAPIorFIX = 'G'
    AlgoEngine = 'H'
    IntraDayCross = 'IDX'
    ImbalanceOnly = 'IO'
    ImmediateOrCancel = 'IOC'
    IntermarketSweepOrder = 'ISO'
    PriceAtExecution = 'J'
    LimitOnClose = 'LOC'
    LimitOnOpen = 'LOO'
    MarketAtClose = 'MAC'
    MarketAtOpen = 'MAO'
    MarketOnClose = 'MOC'
    MarketOnOpen = 'MOO'
    MergerRelatedTransferPosition = 'MPT'
    MinimumQuantity = 'MQT'
    MarketToLimit = 'MTL'
    DeliveryInstructionsNextDay = 'ND'
    NotHeld = 'NH'
    OptionsRelatedTransaction = 'OPT'
    OverTheDay = 'OVD'
    Pegged = 'PEG'
    ReserveSizeOrder = 'RSV'
    StopStockTransaction = 'S.W'
    Scale = 'SCL'
    DeliveryInstructionsSellersOption = 'SLR'
    TimeOrder = 'TMO'
    TrailingStop = 'TS'
    DeskElectronic = 'W'
    Work = 'WRK'
    DeskPit = 'X'
    ClientElectronic = 'Y'
    ClientPit = 'Z'


class OrigClOrdID(fix.Field, Tag="41", Name="OrigClOrdID", Type=fix.FixString):
    Values = {
    }


class OrderID(fix.Field, Tag="37", Name="OrderID", Type=fix.FixString):
    Values = {
    }


class TradSesReqID(fix.Field, Tag="335", Name="TradSesReqID", Type=fix.FixString):
    Values = {
    }


class SubscriptionRequestType(fix.Field, Tag="263", Name="SubscriptionRequestType", Type=fix.FixChar):
    Values = {
        '0': 'Snapshot',
        '1': 'SnapshotAndUpdates',
        '2': 'DisablePreviousSnapshot',
    }
    Snapshot = '0'
    SnapshotAndUpdates = '1'
    DisablePreviousSnapshot = '2'


class TradingSessionDesc(fix.Field, Tag="1326", Name="TradingSessionDesc", Type=fix.FixString):
    Values = {
    }


class TradSesStatus(fix.Field, Tag="340", Name="TradSesStatus", Type=fix.FixInt):
    Values = {
        0: 'Unknown',
        1: 'Halted',
        2: 'Open',
        3: 'Closed',
        4: 'PreOpen',
        5: 'PreClose',
        6: 'RequestRejected',
    }
    Unknown = 0
    Halted = 1
    Open = 2
    Closed = 3
    PreOpen = 4
    PreClose = 5
    RequestRejected = 6


class NoOrdTypeRules(fix.Field, Tag="1237", Name="NoOrdTypeRules", Type=fix.FixInt):
    Values = {
    }


class NoTimeInForceRules(fix.Field, Tag="1239", Name="NoTimeInForceRules", Type=fix.FixInt):
    Values = {
    }


class NoExecInstRules(fix.Field, Tag="1232", Name="NoExecInstRules", Type=fix.FixInt):
    Values = {
    }


class NoMatchRules(fix.Field, Tag="1235", Name="NoMatchRules", Type=fix.FixInt):
    Values = {
    }


class MatchAlgorithm(fix.Field, Tag="1142", Name="MatchAlgorithm", Type=fix.FixString):
    Values = {
    }


class MatchType(fix.Field, Tag="574", Name="MatchType", Type=fix.FixString):
    Values = {
        '1': 'OnePartyTradeReport',
        '10': 'AutoMatchLastLook',
        '11': 'CrossAuctionLastLook',
        '2': 'TwoPartyTradeReport',
        '3': 'ConfirmedTradeReport',
        '4': 'AutoMatch',
        '5': 'CrossAuction',
        '6': 'CounterOrderSelection',
        '7': 'CallAuction',
        '8': 'Issuing',
        '9': 'SystematicInternalizer',
        'A1': 'ExactMatchPlus4BadgesExecTime',
        'A2': 'ExactMatchPlus4Badges',
        'A3': 'ExactMatchPlus2BadgesExecTime',
        'A4': 'ExactMatchPlus2Badges',
        'A5': 'ExactMatchPlusExecTime',
        'AQ': 'StampedAdvisoriesOrSpecialistAccepts',
        'M1': 'ExactMatchMinusBadgesTimes',
        'M2': 'SummarizedMatchMinusBadgesTimes',
        'M3': 'ACTAcceptedTrade',
        'M4': 'ACTDefaultTrade',
        'M5': 'ACTDefaultAfterM2',
        'M6': 'ACTM6Match',
        'MT': 'OCSLockedIn',
        'S1': 'A1ExactMatchSummarizedQuantity',
        'S2': 'A2ExactMatchSummarizedQuantity',
        'S3': 'A3ExactMatchSummarizedQuantity',
        'S4': 'A4ExactMatchSummarizedQuantity',
        'S5': 'A5ExactMatchSummarizedQuantity',
    }
    OnePartyTradeReport = '1'
    AutoMatchLastLook = '10'
    CrossAuctionLastLook = '11'
    TwoPartyTradeReport = '2'
    ConfirmedTradeReport = '3'
    AutoMatch = '4'
    CrossAuction = '5'
    CounterOrderSelection = '6'
    CallAuction = '7'
    Issuing = '8'
    SystematicInternalizer = '9'
    ExactMatchPlus4BadgesExecTime = 'A1'
    ExactMatchPlus4Badges = 'A2'
    ExactMatchPlus2BadgesExecTime = 'A3'
    ExactMatchPlus2Badges = 'A4'
    ExactMatchPlusExecTime = 'A5'
    StampedAdvisoriesOrSpecialistAccepts = 'AQ'
    ExactMatchMinusBadgesTimes = 'M1'
    SummarizedMatchMinusBadgesTimes = 'M2'
    ACTAcceptedTrade = 'M3'
    ACTDefaultTrade = 'M4'
    ACTDefaultAfterM2 = 'M5'
    ACTM6Match = 'M6'
    OCSLockedIn = 'MT'
    A1ExactMatchSummarizedQuantity = 'S1'
    A2ExactMatchSummarizedQuantity = 'S2'
    A3ExactMatchSummarizedQuantity = 'S3'
    A4ExactMatchSummarizedQuantity = 'S4'
    A5ExactMatchSummarizedQuantity = 'S5'


class NoMDFeedTypes(fix.Field, Tag="1141", Name="NoMDFeedTypes", Type=fix.FixInt):
    Values = {
    }


class SecurityListID(fix.Field, Tag="1465", Name="SecurityListID", Type=fix.FixString):
    Values = {
    }


class SecurityReqID(fix.Field, Tag="320", Name="SecurityReqID", Type=fix.FixString):
    Values = {
    }


class SecurityRequestResult(fix.Field, Tag="560", Name="SecurityRequestResult", Type=fix.FixInt):
    Values = {
        0: 'ValidRequest',
        1: 'InvalidOrUnsupportedRequest',
        2: 'NoInstrumentsFound',
        3: 'NotAuthorizedToRetrieveInstrumentData',
        4: 'InstrumentDataTemporarilyUnavailable',
        5: 'RequestForInstrumentDataNotSupported',
    }
    ValidRequest = 0
    InvalidOrUnsupportedRequest = 1
    NoInstrumentsFound = 2
    NotAuthorizedToRetrieveInstrumentData = 3
    InstrumentDataTemporarilyUnavailable = 4
    RequestForInstrumentDataNotSupported = 5


class TotNoRelatedSym(fix.Field, Tag="393", Name="TotNoRelatedSym", Type=fix.FixInt):
    Values = {
    }


class CorporateAction(fix.Field, Tag="292", Name="CorporateAction", Type=fix.FixString):
    Values = {
        'A': 'ExDividend',
        'B': 'ExDistribution',
        'C': 'ExRights',
        'D': 'New',
        'E': 'ExInterest',
        'F': 'CashDividend',
        'G': 'StockDividend',
        'H': 'NonIntegerStockSplit',
        'I': 'ReverseStockSplit',
        'J': 'StandardIntegerStockSplit',
        'K': 'PositionConsolidation',
        'L': 'LiquidationReorganization',
        'M': 'MergerReorganization',
        'N': 'RightsOffering',
        'O': 'ShareholderMeeting',
        'P': 'Spinoff',
        'Q': 'TenderOffer',
        'R': 'Warrant',
        'S': 'SpecialAction',
        'T': 'SymbolConversion',
        'U': 'CUSIP',
        'V': 'LeapRollover',
        'W': 'SuccessionEvent',
    }
    ExDividend = 'A'
    ExDistribution = 'B'
    ExRights = 'C'
    New = 'D'
    ExInterest = 'E'
    CashDividend = 'F'
    StockDividend = 'G'
    NonIntegerStockSplit = 'H'
    ReverseStockSplit = 'I'
    StandardIntegerStockSplit = 'J'
    PositionConsolidation = 'K'
    LiquidationReorganization = 'L'
    MergerReorganization = 'M'
    RightsOffering = 'N'
    ShareholderMeeting = 'O'
    Spinoff = 'P'
    TenderOffer = 'Q'
    Warrant = 'R'
    SpecialAction = 'S'
    SymbolConversion = 'T'
    CUSIP = 'U'
    LeapRollover = 'V'
    SuccessionEvent = 'W'


class LastFragment(fix.Field, Tag="893", Name="LastFragment", Type=fix.FixBool):
    Values = {
        'N': 'NotLastMessage',
        'Y': 'LastMessage',
    }
    NotLastMessage = 'N'
    LastMessage = 'Y'


class ListUpdateAction(fix.Field, Tag="1324", Name="ListUpdateAction", Type=fix.FixChar):
    Values = {
        'A': 'Add',
        'D': 'Delete',
        'M': 'Modify',
        'S': 'Snapshot',
    }
    Add = 'A'
    Delete = 'D'
    Modify = 'M'
    Snapshot = 'S'


class NoTickRules(fix.Field, Tag="1205", Name="NoTickRules", Type=fix.FixInt):
    Values = {
    }


class StartTickPriceRange(fix.Field, Tag="1206", Name="StartTickPriceRange", Type=fix.FixPrice):
    Values = {
    }


class EndTickPriceRange(fix.Field, Tag="1207", Name="EndTickPriceRange", Type=fix.FixPrice):
    Values = {
    }


class TickIncrement(fix.Field, Tag="1208", Name="TickIncrement", Type=fix.FixPrice):
    Values = {
    }


class NoLotTypeRules(fix.Field, Tag="1234", Name="NoLotTypeRules", Type=fix.FixInt):
    Values = {
    }


class LotType(fix.Field, Tag="1093", Name="LotType", Type=fix.FixChar):
    Values = {
        '1': 'OddLot',
        '2': 'RoundLot',
        '3': 'BlockLot',
        '4': 'RoundLotBasedUpon',
    }
    OddLot = '1'
    RoundLot = '2'
    BlockLot = '3'
    RoundLotBasedUpon = '4'


class MinLotSize(fix.Field, Tag="1231", Name="MinLotSize", Type=fix.FixQuantity):
    Values = {
    }


class NoPriceRangeRules(fix.Field, Tag="2550", Name="NoPriceRangeRules", Type=fix.FixInt):
    Values = {
    }


class NoQuoteSizeRules(fix.Field, Tag="2558", Name="NoQuoteSizeRules", Type=fix.FixInt):
    Values = {
    }


class RoundLot(fix.Field, Tag="561", Name="RoundLot", Type=fix.FixQuantity):
    Values = {
    }


class NoTradingSessionRules(fix.Field, Tag="1309", Name="NoTradingSessionRules", Type=fix.FixInt):
    Values = {
    }


class NoNestedInstrAttrib(fix.Field, Tag="1312", Name="NoNestedInstrAttrib", Type=fix.FixInt):
    Values = {
    }


class NoStrikeRules(fix.Field, Tag="1201", Name="NoStrikeRules", Type=fix.FixInt):
    Values = {
    }


class NoMaturityRules(fix.Field, Tag="1236", Name="NoMaturityRules", Type=fix.FixInt):
    Values = {
    }


class NoLegStipulations(fix.Field, Tag="683", Name="NoLegStipulations", Type=fix.FixInt):
    Values = {
    }


class MarketReqID(fix.Field, Tag="1393", Name="MarketReqID", Type=fix.FixString):
    Values = {
    }


class QuoteReqID(fix.Field, Tag="131", Name="QuoteReqID", Type=fix.FixString):
    Values = {
    }


class PrivateQuote(fix.Field, Tag="1171", Name="PrivateQuote", Type=fix.FixBool):
    Values = {
        'N': 'PublicQuote',
        'Y': 'PrivateQuote',
    }
    PublicQuote = 'N'
    PrivateQuote = 'Y'


class RespondentType(fix.Field, Tag="1172", Name="RespondentType", Type=fix.FixInt):
    Values = {
        1: 'AllMarketParticipants',
        2: 'SpecifiedMarketParticipants',
        3: 'AllMarketMakers',
        4: 'PrimaryMarketMaker',
    }
    AllMarketParticipants = 1
    SpecifiedMarketParticipants = 2
    AllMarketMakers = 3
    PrimaryMarketMaker = 4


class NoRootPartyIDs(fix.Field, Tag="1116", Name="NoRootPartyIDs", Type=fix.FixInt):
    Values = {
    }


class RootPartyID(fix.Field, Tag="1117", Name="RootPartyID", Type=fix.FixString):
    Values = {
    }


class RootPartyIDSource(fix.Field, Tag="1118", Name="RootPartyIDSource", Type=fix.FixChar):
    Values = {
        '1': 'KoreanInvestorID',
        '2': 'TaiwaneseForeignInvestorID',
        '3': 'TaiwaneseTradingAcct',
        '4': 'MalaysianCentralDepository',
        '5': 'ChineseInvestorID',
        '6': 'UKNationalInsuranceOrPensionNumber',
        '7': 'USSocialSecurityNumber',
        '8': 'USEmployerOrTaxIDNumber',
        '9': 'AustralianBusinessNumber',
        'A': 'AustralianTaxFileNumber',
        'B': 'BIC',
        'C': 'GeneralIdentifier',
        'D': 'Proprietary',
        'E': 'ISOCountryCode',
        'F': 'SettlementEntityLocation',
        'G': 'MIC',
        'H': 'CSDParticipant',
        'I': 'ISITCAcronym',
        'J': 'TaxID',
        'K': 'AustralianCompanyNumber',
        'L': 'AustralianRegisteredBodyNumber',
        'M': 'CFTCReportingFirmIdentifier',
        'N': 'LegalEntityIdentifier',
        'O': 'InterimIdentifier',
        'P': 'ShortCodeIdentifier',
    }
    KoreanInvestorID = '1'
    TaiwaneseForeignInvestorID = '2'
    TaiwaneseTradingAcct = '3'
    MalaysianCentralDepository = '4'
    ChineseInvestorID = '5'
    UKNationalInsuranceOrPensionNumber = '6'
    USSocialSecurityNumber = '7'
    USEmployerOrTaxIDNumber = '8'
    AustralianBusinessNumber = '9'
    AustralianTaxFileNumber = 'A'
    BIC = 'B'
    GeneralIdentifier = 'C'
    Proprietary = 'D'
    ISOCountryCode = 'E'
    SettlementEntityLocation = 'F'
    MIC = 'G'
    CSDParticipant = 'H'
    ISITCAcronym = 'I'
    TaxID = 'J'
    AustralianCompanyNumber = 'K'
    AustralianRegisteredBodyNumber = 'L'
    CFTCReportingFirmIdentifier = 'M'
    LegalEntityIdentifier = 'N'
    InterimIdentifier = 'O'
    ShortCodeIdentifier = 'P'


class RootPartyRole(fix.Field, Tag="1119", Name="RootPartyRole", Type=fix.FixInt):
    Values = {
        1: 'ExecutingFirm',
        10: 'SettlementLocation',
        100: 'MarginAccount',
        101: 'CollateralAssetAccount',
        102: 'DataRepository',
        103: 'CalculationAgent',
        104: 'ExerciseNoticeSender',
        105: 'ExerciseNoticeReceiver',
        106: 'RateReferenceBank',
        107: 'Correspondent',
        109: 'BeneficiaryBank',
        11: 'OrderOriginationTrader',
        110: 'Borrower',
        111: 'PrimaryObligator',
        112: 'Guarantor',
        113: 'ExcludedReferenceEntity',
        114: 'DeterminingParty',
        115: 'HedgingParty',
        116: 'ReportingEntity',
        117: 'SalesPerson',
        118: 'Operator',
        119: 'CSD',
        12: 'ExecutingTrader',
        120: 'ICSD',
        122: 'InvestmentDecisionMaker',
        125: 'Issuer',
        13: 'OrderOriginationFirm',
        14: 'GiveupClearingFirmfirmtowhichtradeisgivenup',
        15: 'CorrespondantClearingFirm',
        16: 'ExecutingSystem',
        17: 'ContraFirm',
        18: 'ContraClearingFirm',
        19: 'SponsoringFirm',
        2: 'BrokerOfCredit',
        20: 'UnderlyingContraFirm',
        21: 'ClearingOrganization',
        22: 'Exchange',
        24: 'CustomerAccount',
        25: 'CorrespondentClearingOrganization',
        26: 'CorrespondentBroker',
        27: 'Buyer',
        28: 'Custodian',
        29: 'Intermediary',
        3: 'ClientID',
        30: 'Agent',
        31: 'SubCustodian',
        32: 'Beneficiary',
        33: 'InterestedParty',
        34: 'RegulatoryBody',
        35: 'LiquidityProvider',
        36: 'EnteringTrader',
        37: 'ContraTrader',
        38: 'PositionAccount',
        39: 'ContraInvestorID',
        4: 'ClearingFirm',
        40: 'TransferToFirm',
        41: 'ContraPositionAccount',
        42: 'ContraExchange',
        43: 'InternalCarryAccount',
        44: 'OrderEntryOperatorID',
        45: 'SecondaryAccountNumber',
        46: 'ForeignFirm',
        47: 'ThirdPartyAllocationFirm',
        48: 'ClaimingAccount',
        49: 'AssetManager',
        5: 'InvestorID',
        50: 'PledgorAccount',
        51: 'PledgeeAccount',
        52: 'LargeTraderReportableAccount',
        53: 'TraderMnemonic',
        54: 'SenderLocation',
        55: 'SessionID',
        56: 'AcceptableCounterparty',
        57: 'UnacceptableCounterparty',
        58: 'EnteringUnit',
        59: 'ExecutingUnit',
        6: 'IntroducingFirm',
        60: 'IntroducingBroker',
        61: 'QuoteOriginator',
        62: 'ReportOriginator',
        63: 'SystematicInternaliser',
        64: 'MultilateralTradingFacility',
        65: 'RegulatedMarket',
        66: 'MarketMaker',
        67: 'InvestmentFirm',
        68: 'HostCompetentAuthority',
        69: 'HomeCompetentAuthority',
        7: 'EnteringFirm',
        70: 'CompetentAuthorityLiquidity',
        71: 'CompetentAuthorityTransactionVenue',
        72: 'ReportingIntermediary',
        73: 'ExecutionVenue',
        74: 'MarketDataEntryOriginator',
        75: 'LocationID',
        76: 'DeskID',
        77: 'MarketDataMarket',
        78: 'AllocationEntity',
        79: 'PrimeBroker',
        8: 'Locate',
        80: 'StepOutFirm',
        81: 'BrokerClearingID',
        82: 'CentralRegistrationDepository',
        83: 'ClearingAccount',
        84: 'AcceptableSettlingCounterparty',
        85: 'UnacceptableSettlingCounterparty',
        86: 'CLSMemberBank',
        87: 'InConcertGroup',
        88: 'InConcertControllingEntity',
        89: 'LargePositionsReportingAccount',
        9: 'FundManagerClientID',
        90: 'SettlementFirm',
        91: 'SettlementAccount',
        92: 'ReportingMarketCenter',
        93: 'RelatedReportingMarketCenter',
        94: 'AwayMarket',
        95: 'GiveupTradingFirm',
        96: 'TakeupTradingFirm',
        97: 'GiveupClearingFirm',
        98: 'TakeupClearingFirm',
        99: 'OriginatingMarket',
    }
    ExecutingFirm = 1
    SettlementLocation = 10
    MarginAccount = 100
    CollateralAssetAccount = 101
    DataRepository = 102
    CalculationAgent = 103
    ExerciseNoticeSender = 104
    ExerciseNoticeReceiver = 105
    RateReferenceBank = 106
    Correspondent = 107
    BeneficiaryBank = 109
    OrderOriginationTrader = 11
    Borrower = 110
    PrimaryObligator = 111
    Guarantor = 112
    ExcludedReferenceEntity = 113
    DeterminingParty = 114
    HedgingParty = 115
    ReportingEntity = 116
    SalesPerson = 117
    Operator = 118
    CSD = 119
    ExecutingTrader = 12
    ICSD = 120
    InvestmentDecisionMaker = 122
    Issuer = 125
    OrderOriginationFirm = 13
    GiveupClearingFirmfirmtowhichtradeisgivenup = 14
    CorrespondantClearingFirm = 15
    ExecutingSystem = 16
    ContraFirm = 17
    ContraClearingFirm = 18
    SponsoringFirm = 19
    BrokerOfCredit = 2
    UnderlyingContraFirm = 20
    ClearingOrganization = 21
    Exchange = 22
    CustomerAccount = 24
    CorrespondentClearingOrganization = 25
    CorrespondentBroker = 26
    Buyer = 27
    Custodian = 28
    Intermediary = 29
    ClientID = 3
    Agent = 30
    SubCustodian = 31
    Beneficiary = 32
    InterestedParty = 33
    RegulatoryBody = 34
    LiquidityProvider = 35
    EnteringTrader = 36
    ContraTrader = 37
    PositionAccount = 38
    ContraInvestorID = 39
    ClearingFirm = 4
    TransferToFirm = 40
    ContraPositionAccount = 41
    ContraExchange = 42
    InternalCarryAccount = 43
    OrderEntryOperatorID = 44
    SecondaryAccountNumber = 45
    ForeignFirm = 46
    ThirdPartyAllocationFirm = 47
    ClaimingAccount = 48
    AssetManager = 49
    InvestorID = 5
    PledgorAccount = 50
    PledgeeAccount = 51
    LargeTraderReportableAccount = 52
    TraderMnemonic = 53
    SenderLocation = 54
    SessionID = 55
    AcceptableCounterparty = 56
    UnacceptableCounterparty = 57
    EnteringUnit = 58
    ExecutingUnit = 59
    IntroducingFirm = 6
    IntroducingBroker = 60
    QuoteOriginator = 61
    ReportOriginator = 62
    SystematicInternaliser = 63
    MultilateralTradingFacility = 64
    RegulatedMarket = 65
    MarketMaker = 66
    InvestmentFirm = 67
    HostCompetentAuthority = 68
    HomeCompetentAuthority = 69
    EnteringFirm = 7
    CompetentAuthorityLiquidity = 70
    CompetentAuthorityTransactionVenue = 71
    ReportingIntermediary = 72
    ExecutionVenue = 73
    MarketDataEntryOriginator = 74
    LocationID = 75
    DeskID = 76
    MarketDataMarket = 77
    AllocationEntity = 78
    PrimeBroker = 79
    Locate = 8
    StepOutFirm = 80
    BrokerClearingID = 81
    CentralRegistrationDepository = 82
    ClearingAccount = 83
    AcceptableSettlingCounterparty = 84
    UnacceptableSettlingCounterparty = 85
    CLSMemberBank = 86
    InConcertGroup = 87
    InConcertControllingEntity = 88
    LargePositionsReportingAccount = 89
    FundManagerClientID = 9
    SettlementFirm = 90
    SettlementAccount = 91
    ReportingMarketCenter = 92
    RelatedReportingMarketCenter = 93
    AwayMarket = 94
    GiveupTradingFirm = 95
    TakeupTradingFirm = 96
    GiveupClearingFirm = 97
    TakeupClearingFirm = 98
    OriginatingMarket = 99


class NoRootPartySubIDs(fix.Field, Tag="1120", Name="NoRootPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class RootPartySubID(fix.Field, Tag="1121", Name="RootPartySubID", Type=fix.FixString):
    Values = {
    }


class RootPartySubIDType(fix.Field, Tag="1122", Name="RootPartySubIDType", Type=fix.FixInt):
    Values = {
        1: 'Firm',
        10: 'SecuritiesAccountNumber',
        11: 'RegistrationNumber',
        12: 'RegisteredAddressForConfirmation',
        13: 'RegulatoryStatus',
        14: 'RegistrationName',
        15: 'CashAccountNumber',
        16: 'BIC',
        17: 'CSDParticipantMemberCode',
        18: 'RegisteredAddress',
        19: 'FundAccountName',
        2: 'Person',
        20: 'TelexNumber',
        21: 'FaxNumber',
        22: 'SecuritiesAccountName',
        23: 'CashAccountName',
        24: 'Department',
        25: 'LocationDesk',
        26: 'PositionAccountType',
        27: 'SecurityLocateID',
        28: 'MarketMaker',
        29: 'EligibleCounterparty',
        3: 'System',
        30: 'ProfessionalClient',
        31: 'Location',
        32: 'ExecutionVenue',
        33: 'CurrencyDeliveryIdentifier',
        34: 'AddressCity',
        35: 'AddressStateOrProvince',
        36: 'AddressPostalCode',
        37: 'AddressStreet',
        38: 'AddressISOCountryCode',
        39: 'ISOCountryCode',
        4: 'Application',
        40: 'MarketSegment',
        4028: 'MarketMIC',
        4029: 'TradingSession',
        4030: 'OrderSource',
        41: 'CustomerAccountType',
        42: 'OmnibusAccount',
        43: 'FundsSegregationType',
        44: 'GuaranteeFund',
        45: 'SwapDealer',
        46: 'MajorParticipant',
        47: 'FinancialEntity',
        48: 'USPerson',
        49: 'ReportingEntityIndicator',
        5: 'FullLegalNameOfFirm',
        50: 'ElectedClearingRequirementException',
        51: 'BusinessCenter',
        52: 'ReferenceText',
        53: 'ShortMarkingExemptAccount',
        54: 'ParentFirmIdentifier',
        55: 'ParentFirmName',
        56: 'DealIdentifier',
        57: 'SystemTradeID',
        58: 'SystemTradeSubID',
        59: 'FCMCode',
        6: 'PostalAddress',
        60: 'DlvryTrmlCode',
        61: 'VolntyRptEntity',
        62: 'RptObligJursdctn',
        63: 'VolntyRptJursdctn',
        64: 'CompanyActivities',
        65: 'EEAreaDomiciled',
        66: 'ContractLinked',
        67: 'ContractAbove',
        68: 'VolntyRptPty',
        69: 'EndUser',
        7: 'PhoneNumber',
        70: 'LocationOrJurisdiction',
        71: 'DerivativesDealer',
        72: 'Domicile',
        73: 'ExemptFromRecognition',
        74: 'Payer',
        75: 'Receiver',
        8: 'EmailAddress',
        9: 'ContactName',
    }
    Firm = 1
    SecuritiesAccountNumber = 10
    RegistrationNumber = 11
    RegisteredAddressForConfirmation = 12
    RegulatoryStatus = 13
    RegistrationName = 14
    CashAccountNumber = 15
    BIC = 16
    CSDParticipantMemberCode = 17
    RegisteredAddress = 18
    FundAccountName = 19
    Person = 2
    TelexNumber = 20
    FaxNumber = 21
    SecuritiesAccountName = 22
    CashAccountName = 23
    Department = 24
    LocationDesk = 25
    PositionAccountType = 26
    SecurityLocateID = 27
    MarketMaker = 28
    EligibleCounterparty = 29
    System = 3
    ProfessionalClient = 30
    Location = 31
    ExecutionVenue = 32
    CurrencyDeliveryIdentifier = 33
    AddressCity = 34
    AddressStateOrProvince = 35
    AddressPostalCode = 36
    AddressStreet = 37
    AddressISOCountryCode = 38
    ISOCountryCode = 39
    Application = 4
    MarketSegment = 40
    MarketMIC = 4028
    TradingSession = 4029
    OrderSource = 4030
    CustomerAccountType = 41
    OmnibusAccount = 42
    FundsSegregationType = 43
    GuaranteeFund = 44
    SwapDealer = 45
    MajorParticipant = 46
    FinancialEntity = 47
    USPerson = 48
    ReportingEntityIndicator = 49
    FullLegalNameOfFirm = 5
    ElectedClearingRequirementException = 50
    BusinessCenter = 51
    ReferenceText = 52
    ShortMarkingExemptAccount = 53
    ParentFirmIdentifier = 54
    ParentFirmName = 55
    DealIdentifier = 56
    SystemTradeID = 57
    SystemTradeSubID = 58
    FCMCode = 59
    PostalAddress = 6
    DlvryTrmlCode = 60
    VolntyRptEntity = 61
    RptObligJursdctn = 62
    VolntyRptJursdctn = 63
    CompanyActivities = 64
    EEAreaDomiciled = 65
    ContractLinked = 66
    ContractAbove = 67
    VolntyRptPty = 68
    EndUser = 69
    PhoneNumber = 7
    LocationOrJurisdiction = 70
    DerivativesDealer = 71
    Domicile = 72
    ExemptFromRecognition = 73
    Payer = 74
    Receiver = 75
    EmailAddress = 8
    ContactName = 9


class SecondaryQuoteID(fix.Field, Tag="1751", Name="SecondaryQuoteID", Type=fix.FixString):
    Values = {
    }


class QuoteType(fix.Field, Tag="537", Name="QuoteType", Type=fix.FixInt):
    Values = {
        0: 'Indicative',
        1: 'Tradeable',
        2: 'RestrictedTradeable',
        3: 'Counter',
        4: 'InitiallyTradeable',
    }
    Indicative = 0
    Tradeable = 1
    RestrictedTradeable = 2
    Counter = 3
    InitiallyTradeable = 4


class NoRateSources(fix.Field, Tag="1445", Name="NoRateSources", Type=fix.FixInt):
    Values = {
    }


class NoQuoteQualifiers(fix.Field, Tag="735", Name="NoQuoteQualifiers", Type=fix.FixInt):
    Values = {
    }


class TrdType(fix.Field, Tag="828", Name="TrdType", Type=fix.FixInt):
    Values = {
        0: 'RegularTrade',
        1: 'BlockTrade',
        10: 'AfterHoursTrade',
        11: 'ExchangeForRisk',
        12: 'ExchangeForSwap',
        13: 'ExchangeOfFuturesFor',
        14: 'ExchangeOfOptionsForOptions',
        15: 'TradingAtSettlement',
        16: 'AllOrNone',
        17: 'FuturesLargeOrderExecution',
        18: 'ExchangeOfFuturesForFutures',
        19: 'OptionInterimTrade',
        2: 'EFP',
        20: 'OptionCabinetTrade',
        22: 'PrivatelyNegotiatedTrades',
        23: 'SubstitutionOfFuturesForForwards',
        24: 'ErrorTrade',
        25: 'SpecialCumDividend',
        26: 'SpecialExDividend',
        27: 'SpecialCumCoupon',
        28: 'SpecialExCoupon',
        29: 'CashSettlement',
        3: 'Transfer',
        30: 'SpecialPrice',
        31: 'GuaranteedDelivery',
        32: 'SpecialCumRights',
        33: 'SpecialExRights',
        34: 'SpecialCumCapitalRepayments',
        35: 'SpecialExCapitalRepayments',
        36: 'SpecialCumBonus',
        37: 'SpecialExBonus',
        38: 'LargeTrade',
        39: 'WorkedPrincipalTrade',
        4: 'LateTrade',
        40: 'BlockTrades',
        41: 'NameChange',
        42: 'PortfolioTransfer',
        43: 'ProrogationBuy',
        44: 'ProrogationSell',
        45: 'OptionExercise',
        46: 'DeltaNeutralTransaction',
        47: 'FinancingTransaction',
        48: 'NonStandardSettlement',
        49: 'DerivativeRelatedTransaction',
        5: 'TTrade',
        50: 'PortfolioTrade',
        51: 'VolumeWeightedAverageTrade',
        52: 'ExchangeGrantedTrade',
        53: 'RepurchaseAgreement',
        54: 'OTC',
        55: 'ExchangeBasisFacility',
        56: 'OpeningTrade',
        57: 'NettedTrade',
        58: 'BlockSwapTrade',
        59: 'CreditEventTrade',
        6: 'WeightedAveragePriceTrade',
        60: 'SuccessionEventTrade',
        61: 'GiveUpGiveInTrade',
        62: 'DarkTrade',
        63: 'TechnicalTrade',
        64: 'Benchmark',
        65: 'PackageTrade',
        7: 'BunchedTrade',
        8: 'LateBunchedTrade',
        9: 'PriorReferencePriceTrade',
    }
    RegularTrade = 0
    BlockTrade = 1
    AfterHoursTrade = 10
    ExchangeForRisk = 11
    ExchangeForSwap = 12
    ExchangeOfFuturesFor = 13
    ExchangeOfOptionsForOptions = 14
    TradingAtSettlement = 15
    AllOrNone = 16
    FuturesLargeOrderExecution = 17
    ExchangeOfFuturesForFutures = 18
    OptionInterimTrade = 19
    EFP = 2
    OptionCabinetTrade = 20
    PrivatelyNegotiatedTrades = 22
    SubstitutionOfFuturesForForwards = 23
    ErrorTrade = 24
    SpecialCumDividend = 25
    SpecialExDividend = 26
    SpecialCumCoupon = 27
    SpecialExCoupon = 28
    CashSettlement = 29
    Transfer = 3
    SpecialPrice = 30
    GuaranteedDelivery = 31
    SpecialCumRights = 32
    SpecialExRights = 33
    SpecialCumCapitalRepayments = 34
    SpecialExCapitalRepayments = 35
    SpecialCumBonus = 36
    SpecialExBonus = 37
    LargeTrade = 38
    WorkedPrincipalTrade = 39
    LateTrade = 4
    BlockTrades = 40
    NameChange = 41
    PortfolioTransfer = 42
    ProrogationBuy = 43
    ProrogationSell = 44
    OptionExercise = 45
    DeltaNeutralTransaction = 46
    FinancingTransaction = 47
    NonStandardSettlement = 48
    DerivativeRelatedTransaction = 49
    TTrade = 5
    PortfolioTrade = 50
    VolumeWeightedAverageTrade = 51
    ExchangeGrantedTrade = 52
    RepurchaseAgreement = 53
    OTC = 54
    ExchangeBasisFacility = 55
    OpeningTrade = 56
    NettedTrade = 57
    BlockSwapTrade = 58
    CreditEventTrade = 59
    WeightedAveragePriceTrade = 6
    SuccessionEventTrade = 60
    GiveUpGiveInTrade = 61
    DarkTrade = 62
    TechnicalTrade = 63
    Benchmark = 64
    PackageTrade = 65
    BunchedTrade = 7
    LateBunchedTrade = 8
    PriorReferencePriceTrade = 9


class ValidUntilTime(fix.Field, Tag="62", Name="ValidUntilTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class MarketReportID(fix.Field, Tag="1394", Name="MarketReportID", Type=fix.FixString):
    Values = {
    }


class MarketSegmentDesc(fix.Field, Tag="1396", Name="MarketSegmentDesc", Type=fix.FixString):
    Values = {
    }


class NoInstrumentScopes(fix.Field, Tag="1656", Name="NoInstrumentScopes", Type=fix.FixInt):
    Values = {
    }


class InstrumentScopeOperator(fix.Field, Tag="1535", Name="InstrumentScopeOperator", Type=fix.FixInt):
    Values = {
        1: 'Include',
        2: 'Exclude',
    }
    Include = 1
    Exclude = 2


class InstrumentScopeSecurityID(fix.Field, Tag="1538", Name="InstrumentScopeSecurityID", Type=fix.FixString):
    Values = {
    }


class InstrumentScopeSecurityIDSource(fix.Field, Tag="1539", Name="InstrumentScopeSecurityIDSource", Type=fix.FixString):
    Values = {
        '1': 'CUSIP',
        '127': 'MMEAssetID',
        '2': 'SEDOL',
        '3': 'QUIK',
        '4': 'ISINNumber',
        '5': 'RICCode',
        '6': 'ISOCurrencyCode',
        '7': 'ISOCountryCode',
        '8': 'ExchangeSymbol',
        '9': 'ConsolidatedTapeAssociation',
        'A': 'BloombergSymbol',
        'B': 'Wertpapier',
        'C': 'Dutch',
        'D': 'Valoren',
        'E': 'Sicovam',
        'F': 'Belgian',
        'G': 'Common',
        'H': 'ClearingHouse',
        'I': 'ISDAFpMLSpecification',
        'J': 'OptionPriceReportingAuthority',
        'K': 'ISDAFpMLURL',
        'L': 'LetterOfCredit',
        'M': 'MarketplaceAssignedIdentifier',
        'N': 'MarkitREDEntityCLIP',
        'P': 'MarkitREDPairCLIP',
        'Q': 'CFTCCommodityCode',
        'R': 'ISDACommodityReferencePrice',
        'S': 'FinancialInstrumentGlobalIdentifier',
        'T': 'LegalEntityIdentifier',
        'U': 'Synthetic',
    }
    CUSIP = '1'
    MMEAssetID = '127'
    SEDOL = '2'
    QUIK = '3'
    ISINNumber = '4'
    RICCode = '5'
    ISOCurrencyCode = '6'
    ISOCountryCode = '7'
    ExchangeSymbol = '8'
    ConsolidatedTapeAssociation = '9'
    BloombergSymbol = 'A'
    Wertpapier = 'B'
    Dutch = 'C'
    Valoren = 'D'
    Sicovam = 'E'
    Belgian = 'F'
    Common = 'G'
    ClearingHouse = 'H'
    ISDAFpMLSpecification = 'I'
    OptionPriceReportingAuthority = 'J'
    ISDAFpMLURL = 'K'
    LetterOfCredit = 'L'
    MarketplaceAssignedIdentifier = 'M'
    MarkitREDEntityCLIP = 'N'
    MarkitREDPairCLIP = 'P'
    CFTCCommodityCode = 'Q'
    ISDACommodityReferencePrice = 'R'
    FinancialInstrumentGlobalIdentifier = 'S'
    LegalEntityIdentifier = 'T'
    Synthetic = 'U'


class NoInstrumentScopeSecurityAltID(fix.Field, Tag="1540", Name="NoInstrumentScopeSecurityAltID", Type=fix.FixInt):
    Values = {
    }


class InstrumentScopeSecurityAltID(fix.Field, Tag="1541", Name="InstrumentScopeSecurityAltID", Type=fix.FixString):
    Values = {
    }


class InstrumentScopeSecurityAltIDSource(fix.Field, Tag="1542", Name="InstrumentScopeSecurityAltIDSource", Type=fix.FixString):
    Values = {
        '129': 'InstrumentScopeSecurityAltIDSource',
    }
    InstrumentScopeSecurityAltIDSource = '129'


class InstrumentScopeSecurityDesc(fix.Field, Tag="1556", Name="InstrumentScopeSecurityDesc", Type=fix.FixString):
    Values = {
    }


class NoRelatedMarketSegments(fix.Field, Tag="2545", Name="NoRelatedMarketSegments", Type=fix.FixInt):
    Values = {
    }


class NoAuctionTypeRules(fix.Field, Tag="2548", Name="NoAuctionTypeRules", Type=fix.FixInt):
    Values = {
    }


class NoFlexProductEligibilities(fix.Field, Tag="2560", Name="NoFlexProductEligibilities", Type=fix.FixInt):
    Values = {
    }


class QuoteRespID(fix.Field, Tag="693", Name="QuoteRespID", Type=fix.FixString):
    Values = {
    }


class QuoteModelType(fix.Field, Tag="2403", Name="QuoteModelType", Type=fix.FixInt):
    Values = {
        1: 'QuoteEntry',
        2: 'QuoteModification',
    }
    QuoteEntry = 1
    QuoteModification = 2


class QuoteResponseLevel(fix.Field, Tag="301", Name="QuoteResponseLevel", Type=fix.FixInt):
    Values = {
        0: 'NoAcknowledgement',
        1: 'AcknowledgeOnlyNegativeOrErroneousQuotes',
        2: 'AcknowledgeEachQuoteMessage',
        3: 'SummaryAcknowledgement',
    }
    NoAcknowledgement = 0
    AcknowledgeOnlyNegativeOrErroneousQuotes = 1
    AcknowledgeEachQuoteMessage = 2
    SummaryAcknowledgement = 3


class NoValueChecks(fix.Field, Tag="1868", Name="NoValueChecks", Type=fix.FixInt):
    Values = {
    }


class BidPx(fix.Field, Tag="132", Name="BidPx", Type=fix.FixPrice):
    Values = {
    }


class OfferPx(fix.Field, Tag="133", Name="OfferPx", Type=fix.FixPrice):
    Values = {
    }


class BidSize(fix.Field, Tag="134", Name="BidSize", Type=fix.FixQuantity):
    Values = {
    }


class OfferSize(fix.Field, Tag="135", Name="OfferSize", Type=fix.FixQuantity):
    Values = {
    }


class NoRelativeValues(fix.Field, Tag="2529", Name="NoRelativeValues", Type=fix.FixInt):
    Values = {
    }


class QuoteCancelType(fix.Field, Tag="298", Name="QuoteCancelType", Type=fix.FixInt):
    Values = {
        1: 'CancelForOneOrMoreSecurities',
        101: 'Offercancelledforoverallocation',
        102: 'Offercancelledfordeclined',
        103: 'Offercancelledbyuser',
        104: 'Offercancelledbysystem',
        2: 'CancelForSecurityType',
        3: 'CancelForUnderlyingSecurity',
        4: 'CancelAllQuotes',
        5: 'CancelSpecifiedSingleQuote',
        6: 'CancelByTypeOfQuote',
        7: 'CancelForSecurityIssuer',
        8: 'CancelForIssuerOfUnderlyingSecurity',
    }
    CancelForOneOrMoreSecurities = 1
    Offercancelledforoverallocation = 101
    Offercancelledfordeclined = 102
    Offercancelledbyuser = 103
    Offercancelledbysystem = 104
    CancelForSecurityType = 2
    CancelForUnderlyingSecurity = 3
    CancelAllQuotes = 4
    CancelSpecifiedSingleQuote = 5
    CancelByTypeOfQuote = 6
    CancelForSecurityIssuer = 7
    CancelForIssuerOfUnderlyingSecurity = 8


class NoQuoteEntries(fix.Field, Tag="295", Name="NoQuoteEntries", Type=fix.FixInt):
    Values = {
    }


class QuoteStatus(fix.Field, Tag="297", Name="QuoteStatus", Type=fix.FixInt):
    Values = {
        0: 'Accepted',
        1: 'Canceledforspecificsecurities',
        10: 'Pending',
        11: 'Pass',
        12: 'LockedMarketWarning',
        13: 'CrossMarketWarning',
        14: 'CanceledDueToLockMarket',
        15: 'CanceledDueToCrossMarket',
        16: 'Active',
        17: 'Canceled',
        18: 'UnsolicitedQuoteReplenishment',
        19: 'PendingEndTrade',
        2: 'CanceledforspecificSecurityTypes167',
        20: 'TooLateToEnd',
        21: 'Traded',
        22: 'TradedAndRemoved',
        3: 'Canceledforunderlying',
        4: 'Canceledall',
        5: 'Rejected',
        6: 'RemovedFromMarket',
        7: 'Expired',
        8: 'Query',
        9: 'QuoteNotFound',
    }
    Accepted = 0
    Canceledforspecificsecurities = 1
    Pending = 10
    Pass = 11
    LockedMarketWarning = 12
    CrossMarketWarning = 13
    CanceledDueToLockMarket = 14
    CanceledDueToCrossMarket = 15
    Active = 16
    Canceled = 17
    UnsolicitedQuoteReplenishment = 18
    PendingEndTrade = 19
    CanceledforspecificSecurityTypes167 = 2
    TooLateToEnd = 20
    Traded = 21
    TradedAndRemoved = 22
    Canceledforunderlying = 3
    Canceledall = 4
    Rejected = 5
    RemovedFromMarket = 6
    Expired = 7
    Query = 8
    QuoteNotFound = 9


class QuoteRejectReason(fix.Field, Tag="300", Name="QuoteRejectReason", Type=fix.FixInt):
    Values = {
        1: 'UnknownSymbol',
        10: 'PriceExceedsCurrentPriceBand',
        105: 'GatewayRejectOnInvalidQuoteEntry',
        11: 'QuoteLocked',
        12: 'InvalidOrUnknownSecurityIssuer',
        13: 'InvalidOrUnknownIssuerOfUnderlyingSecurity',
        14: 'NotionalValueExceedsThreshold',
        15: 'Priceexceedscurrentpriceband',
        16: 'ReferencePriceNotAvailable',
        17: 'InsufficientCreditLimit',
        18: 'ExceededClipSizeLimit',
        19: 'ExceededMaxNotionalOrderAmt',
        197: 'ActiveQuoteExists',
        199: 'InvalidQuantity',
        2: 'Exchange',
        20: 'ExceededDV01PV01Limit',
        201: 'UnknownQuoteRequestID',
        202: 'InvalidQuoteRespType',
        203: 'DuplicateResponse',
        21: 'ExceededCS01Limit',
        3: 'QuoteRequestExceedsLimit',
        4: 'TooLateToEnter',
        5: 'UnknownQuote',
        6: 'DuplicateQuote',
        7: 'InvalidBid',
        8: 'InvalidPrice',
        9: 'NotAuthorizedToQuoteSecurity',
        99: 'Other',
    }
    UnknownSymbol = 1
    PriceExceedsCurrentPriceBand = 10
    GatewayRejectOnInvalidQuoteEntry = 105
    QuoteLocked = 11
    InvalidOrUnknownSecurityIssuer = 12
    InvalidOrUnknownIssuerOfUnderlyingSecurity = 13
    NotionalValueExceedsThreshold = 14
    Priceexceedscurrentpriceband = 15
    ReferencePriceNotAvailable = 16
    InsufficientCreditLimit = 17
    ExceededClipSizeLimit = 18
    ExceededMaxNotionalOrderAmt = 19
    ActiveQuoteExists = 197
    InvalidQuantity = 199
    Exchange = 2
    ExceededDV01PV01Limit = 20
    UnknownQuoteRequestID = 201
    InvalidQuoteRespType = 202
    DuplicateResponse = 203
    ExceededCS01Limit = 21
    QuoteRequestExceedsLimit = 3
    TooLateToEnter = 4
    UnknownQuote = 5
    DuplicateQuote = 6
    InvalidBid = 7
    InvalidPrice = 8
    NotAuthorizedToQuoteSecurity = 9
    Other = 99


class NoQuoteSets(fix.Field, Tag="296", Name="NoQuoteSets", Type=fix.FixInt):
    Values = {
    }


class QuoteSetID(fix.Field, Tag="302", Name="QuoteSetID", Type=fix.FixString):
    Values = {
    }


class TotNoQuoteEntries(fix.Field, Tag="304", Name="TotNoQuoteEntries", Type=fix.FixInt):
    Values = {
    }


class TotNoRejQuotes(fix.Field, Tag="1170", Name="TotNoRejQuotes", Type=fix.FixInt):
    Values = {
    }


class QuoteEntryID(fix.Field, Tag="299", Name="QuoteEntryID", Type=fix.FixString):
    Values = {
    }


class QuoteEntryStatus(fix.Field, Tag="1167", Name="QuoteEntryStatus", Type=fix.FixInt):
    Values = {
        0: 'Accepted',
        12: 'LockedMarketWarning',
        13: 'CrossMarketWarning',
        14: 'CanceledDueToLockMarket',
        15: 'CanceledDueToCrossMarket',
        16: 'Active',
        5: 'Rejected',
        6: 'RemovedFromMarket',
        7: 'Expired',
    }
    Accepted = 0
    LockedMarketWarning = 12
    CrossMarketWarning = 13
    CanceledDueToLockMarket = 14
    CanceledDueToCrossMarket = 15
    Active = 16
    Rejected = 5
    RemovedFromMarket = 6
    Expired = 7


class QuoteEntryRejectReason(fix.Field, Tag="368", Name="QuoteEntryRejectReason", Type=fix.FixInt):
    Values = {
        1: 'UnknownSymbol',
        10: 'PriceExceedsCurrentPriceBand',
        105: 'GatewayRejectOnInvalidQuoteEntry',
        11: 'QuoteLocked',
        12: 'InvalidOrUnknownSecurityIssuer',
        13: 'InvalidOrUnknownIssuerOfUnderlyingSecurity',
        14: 'NotionalValueExceedsThreshold',
        15: 'Priceexceedscurrentpriceband',
        16: 'ReferencePriceNotAvailable',
        17: 'InsufficientCreditLimit',
        18: 'ExceededClipSizeLimit',
        19: 'ExceededMaxNotionalOrderAmt',
        197: 'ActiveQuoteExists',
        199: 'InvalidQuantity',
        2: 'Exchange',
        20: 'ExceededDV01PV01Limit',
        201: 'UnknownQuoteRequestID',
        202: 'InvalidQuoteRespType',
        203: 'DuplicateResponse',
        21: 'ExceededCS01Limit',
        3: 'QuoteRequestExceedsLimit',
        4: 'TooLateToEnter',
        5: 'UnknownQuote',
        6: 'DuplicateQuote',
        7: 'InvalidBid',
        8: 'InvalidPrice',
        9: 'NotAuthorizedToQuoteSecurity',
        99: 'Other',
    }
    UnknownSymbol = 1
    PriceExceedsCurrentPriceBand = 10
    GatewayRejectOnInvalidQuoteEntry = 105
    QuoteLocked = 11
    InvalidOrUnknownSecurityIssuer = 12
    InvalidOrUnknownIssuerOfUnderlyingSecurity = 13
    NotionalValueExceedsThreshold = 14
    Priceexceedscurrentpriceband = 15
    ReferencePriceNotAvailable = 16
    InsufficientCreditLimit = 17
    ExceededClipSizeLimit = 18
    ExceededMaxNotionalOrderAmt = 19
    ActiveQuoteExists = 197
    InvalidQuantity = 199
    Exchange = 2
    ExceededDV01PV01Limit = 20
    UnknownQuoteRequestID = 201
    InvalidQuoteRespType = 202
    DuplicateResponse = 203
    ExceededCS01Limit = 21
    QuoteRequestExceedsLimit = 3
    TooLateToEnter = 4
    UnknownQuote = 5
    DuplicateQuote = 6
    InvalidBid = 7
    InvalidPrice = 8
    NotAuthorizedToQuoteSecurity = 9
    Other = 99


class TradeRequestID(fix.Field, Tag="568", Name="TradeRequestID", Type=fix.FixString):
    Values = {
    }


class TradeID(fix.Field, Tag="1003", Name="TradeID", Type=fix.FixString):
    Values = {
    }


class SecondaryTradeID(fix.Field, Tag="1040", Name="SecondaryTradeID", Type=fix.FixString):
    Values = {
    }


class FirmTradeID(fix.Field, Tag="1041", Name="FirmTradeID", Type=fix.FixString):
    Values = {
    }


class TradeRequestType(fix.Field, Tag="569", Name="TradeRequestType", Type=fix.FixInt):
    Values = {
        0: 'AllTrades',
        1: 'MatchedTradesMatchingCriteria',
        2: 'UnmatchedTradesThatMatchCriteria',
        3: 'UnreportedTradesThatMatchCriteria',
        4: 'AdvisoriesThatMatchCriteria',
    }
    AllTrades = 0
    MatchedTradesMatchingCriteria = 1
    UnmatchedTradesThatMatchCriteria = 2
    UnreportedTradesThatMatchCriteria = 3
    AdvisoriesThatMatchCriteria = 4


class TradeReportID(fix.Field, Tag="571", Name="TradeReportID", Type=fix.FixString):
    Values = {
    }


class SecondaryExecID(fix.Field, Tag="527", Name="SecondaryExecID", Type=fix.FixString):
    Values = {
    }


class ExecID(fix.Field, Tag="17", Name="ExecID", Type=fix.FixString):
    Values = {
    }


class ExecType(fix.Field, Tag="150", Name="ExecType", Type=fix.FixChar):
    Values = {
        '0': 'New',
        '2': 'Fill',
        '3': 'DoneForDay',
        '4': 'Canceled',
        '5': 'Replaced',
        '6': 'PendingCancel',
        '7': 'Stopped',
        '8': 'Rejected',
        '9': 'Suspended',
        'A': 'PendingNew',
        'B': 'Calculated',
        'C': 'Expired',
        'D': 'Restated',
        'E': 'PendingReplace',
        'F': 'Trade',
        'G': 'TradeCorrect',
        'H': 'TradeCancel',
        'I': 'OrderStatus',
        'J': 'TradeInAClearingHold',
        'K': 'TradeHasBeenReleasedToClearing',
        'L': 'TriggeredOrActivatedBySystem',
        'M': 'Locked',
        'N': 'Released',
    }
    New = '0'
    Fill = '2'
    DoneForDay = '3'
    Canceled = '4'
    Replaced = '5'
    PendingCancel = '6'
    Stopped = '7'
    Rejected = '8'
    Suspended = '9'
    PendingNew = 'A'
    Calculated = 'B'
    Expired = 'C'
    Restated = 'D'
    PendingReplace = 'E'
    Trade = 'F'
    TradeCorrect = 'G'
    TradeCancel = 'H'
    OrderStatus = 'I'
    TradeInAClearingHold = 'J'
    TradeHasBeenReleasedToClearing = 'K'
    TriggeredOrActivatedBySystem = 'L'
    Locked = 'M'
    Released = 'N'


class MatchStatus(fix.Field, Tag="573", Name="MatchStatus", Type=fix.FixChar):
    Values = {
        '0': 'Compared',
        '1': 'Uncompared',
        '2': 'AdvisoryOrAlert',
    }
    Compared = '0'
    Uncompared = '1'
    AdvisoryOrAlert = '2'


class TrdSubType(fix.Field, Tag="829", Name="TrdSubType", Type=fix.FixInt):
    Values = {
        0: 'CMTA',
        1: 'InternalTransferOrAdjustment',
        10: 'TransactionFromAssignment',
        11: 'ACATS',
        14: 'AI',
        15: 'B',
        16: 'K',
        17: 'LC',
        18: 'M',
        19: 'N',
        2: 'ExternalTransferOrTransferOfAccount',
        20: 'NM',
        21: 'NR',
        22: 'P',
        23: 'PA',
        24: 'PC',
        25: 'PN',
        26: 'R',
        27: 'RO',
        28: 'RT',
        29: 'SW',
        3: 'RejectForSubmittingSide',
        30: 'T',
        31: 'WN',
        32: 'WT',
        33: 'OffHoursTrade',
        34: 'OnHoursTrade',
        35: 'OTCQuote',
        36: 'ConvertedSWAP',
        37: 'CrossedTrade',
        38: 'InterimProtectedTrade',
        39: 'LargeInScale',
        4: 'AdvisoryForContraSide',
        40: 'WashTrade',
        41: 'TradeAtSettlement',
        42: 'AuctionTrade',
        43: 'TradeAtMarker',
        44: 'CreditDefault',
        45: 'CreditRestructuring',
        46: 'Merger',
        47: 'SpinOff',
        48: 'MultilateralCompression',
        5: 'OffsetDueToAnAllocation',
        6: 'OnsetDueToAnAllocation',
        7: 'DifferentialSpread',
        8: 'ImpliedSpreadLegExecutedAgainstAnOutright',
        9: 'TransactionFromExercise',
    }
    CMTA = 0
    InternalTransferOrAdjustment = 1
    TransactionFromAssignment = 10
    ACATS = 11
    AI = 14
    B = 15
    K = 16
    LC = 17
    M = 18
    N = 19
    ExternalTransferOrTransferOfAccount = 2
    NM = 20
    NR = 21
    P = 22
    PA = 23
    PC = 24
    PN = 25
    R = 26
    RO = 27
    RT = 28
    SW = 29
    RejectForSubmittingSide = 3
    T = 30
    WN = 31
    WT = 32
    OffHoursTrade = 33
    OnHoursTrade = 34
    OTCQuote = 35
    ConvertedSWAP = 36
    CrossedTrade = 37
    InterimProtectedTrade = 38
    LargeInScale = 39
    AdvisoryForContraSide = 4
    WashTrade = 40
    TradeAtSettlement = 41
    AuctionTrade = 42
    TradeAtMarker = 43
    CreditDefault = 44
    CreditRestructuring = 45
    Merger = 46
    SpinOff = 47
    MultilateralCompression = 48
    OffsetDueToAnAllocation = 5
    OnsetDueToAnAllocation = 6
    DifferentialSpread = 7
    ImpliedSpreadLegExecutedAgainstAnOutright = 8
    TransactionFromExercise = 9


class TradeHandlingInstr(fix.Field, Tag="1123", Name="TradeHandlingInstr", Type=fix.FixChar):
    Values = {
        '0': 'TradeConfirmation',
        '1': 'TwoPartyReport',
        '2': 'OnePartyReportForMatching',
        '3': 'OnePartyReportForPassThrough',
        '4': 'AutomatedFloorOrderRouting',
        '5': 'TwoPartyReportForClaim',
        '6': 'OnePartyReport',
    }
    TradeConfirmation = '0'
    TwoPartyReport = '1'
    OnePartyReportForMatching = '2'
    OnePartyReportForPassThrough = '3'
    AutomatedFloorOrderRouting = '4'
    TwoPartyReportForClaim = '5'
    OnePartyReport = '6'


class SecondaryTrdType(fix.Field, Tag="855", Name="SecondaryTrdType", Type=fix.FixInt):
    Values = {
        0: 'RegularTrade',
        1: 'BlockTrade',
        10: 'AfterHoursTrade',
        11: 'ExchangeForRisk',
        12: 'ExchangeForSwap',
        13: 'ExchangeOfFuturesFor',
        14: 'ExchangeOfOptionsForOptions',
        15: 'TradingAtSettlement',
        16: 'AllOrNone',
        17: 'FuturesLargeOrderExecution',
        18: 'ExchangeOfFuturesForFutures',
        19: 'OptionInterimTrade',
        2: 'EFP',
        20: 'OptionCabinetTrade',
        22: 'PrivatelyNegotiatedTrades',
        23: 'SubstitutionOfFuturesForForwards',
        24: 'ErrorTrade',
        25: 'SpecialCumDividend',
        26: 'SpecialExDividend',
        27: 'SpecialCumCoupon',
        28: 'SpecialExCoupon',
        29: 'CashSettlement',
        3: 'Transfer',
        30: 'SpecialPrice',
        31: 'GuaranteedDelivery',
        32: 'SpecialCumRights',
        33: 'SpecialExRights',
        34: 'SpecialCumCapitalRepayments',
        35: 'SpecialExCapitalRepayments',
        36: 'SpecialCumBonus',
        37: 'SpecialExBonus',
        38: 'LargeTrade',
        39: 'WorkedPrincipalTrade',
        4: 'LateTrade',
        40: 'BlockTrades',
        41: 'NameChange',
        42: 'PortfolioTransfer',
        43: 'ProrogationBuy',
        44: 'ProrogationSell',
        45: 'OptionExercise',
        46: 'DeltaNeutralTransaction',
        47: 'FinancingTransaction',
        48: 'NonStandardSettlement',
        49: 'DerivativeRelatedTransaction',
        5: 'TTrade',
        50: 'PortfolioTrade',
        51: 'VolumeWeightedAverageTrade',
        52: 'ExchangeGrantedTrade',
        53: 'RepurchaseAgreement',
        54: 'OTC',
        55: 'ExchangeBasisFacility',
        56: 'OpeningTrade',
        57: 'NettedTrade',
        58: 'BlockSwapTrade',
        59: 'CreditEventTrade',
        6: 'WeightedAveragePriceTrade',
        60: 'SuccessionEventTrade',
        61: 'GiveUpGiveInTrade',
        62: 'DarkTrade',
        63: 'TechnicalTrade',
        64: 'Benchmark',
        65: 'PackageTrade',
        7: 'BunchedTrade',
        8: 'LateBunchedTrade',
        9: 'PriorReferencePriceTrade',
    }
    RegularTrade = 0
    BlockTrade = 1
    AfterHoursTrade = 10
    ExchangeForRisk = 11
    ExchangeForSwap = 12
    ExchangeOfFuturesFor = 13
    ExchangeOfOptionsForOptions = 14
    TradingAtSettlement = 15
    AllOrNone = 16
    FuturesLargeOrderExecution = 17
    ExchangeOfFuturesForFutures = 18
    OptionInterimTrade = 19
    EFP = 2
    OptionCabinetTrade = 20
    PrivatelyNegotiatedTrades = 22
    SubstitutionOfFuturesForForwards = 23
    ErrorTrade = 24
    SpecialCumDividend = 25
    SpecialExDividend = 26
    SpecialCumCoupon = 27
    SpecialExCoupon = 28
    CashSettlement = 29
    Transfer = 3
    SpecialPrice = 30
    GuaranteedDelivery = 31
    SpecialCumRights = 32
    SpecialExRights = 33
    SpecialCumCapitalRepayments = 34
    SpecialExCapitalRepayments = 35
    SpecialCumBonus = 36
    SpecialExBonus = 37
    LargeTrade = 38
    WorkedPrincipalTrade = 39
    LateTrade = 4
    BlockTrades = 40
    NameChange = 41
    PortfolioTransfer = 42
    ProrogationBuy = 43
    ProrogationSell = 44
    OptionExercise = 45
    DeltaNeutralTransaction = 46
    FinancingTransaction = 47
    NonStandardSettlement = 48
    DerivativeRelatedTransaction = 49
    TTrade = 5
    PortfolioTrade = 50
    VolumeWeightedAverageTrade = 51
    ExchangeGrantedTrade = 52
    RepurchaseAgreement = 53
    OTC = 54
    ExchangeBasisFacility = 55
    OpeningTrade = 56
    NettedTrade = 57
    BlockSwapTrade = 58
    CreditEventTrade = 59
    WeightedAveragePriceTrade = 6
    SuccessionEventTrade = 60
    GiveUpGiveInTrade = 61
    DarkTrade = 62
    TechnicalTrade = 63
    Benchmark = 64
    PackageTrade = 65
    BunchedTrade = 7
    LateBunchedTrade = 8
    PriorReferencePriceTrade = 9


class TradeLinkID(fix.Field, Tag="820", Name="TradeLinkID", Type=fix.FixString):
    Values = {
    }


class TrdMatchID(fix.Field, Tag="880", Name="TrdMatchID", Type=fix.FixString):
    Values = {
    }


class NoDates(fix.Field, Tag="580", Name="NoDates", Type=fix.FixInt):
    Values = {
    }


class TradeReportType(fix.Field, Tag="856", Name="TradeReportType", Type=fix.FixInt):
    Values = {
        0: 'Submit',
        1: 'Alleged',
        10: 'Pended',
        11: 'AllegedNew',
        12: 'AllegedAddendum',
        13: 'AllegedNo',
        14: 'AllegedTradeReportCancel',
        15: 'AllegedTradeBreak',
        16: 'Verify',
        17: 'Dispute',
        2: 'Accept',
        3: 'Decline',
        4: 'Addendum',
        5: 'No',
        6: 'TradeReportCancel',
        7: 'LockedIn',
        8: 'Defaulted',
        9: 'InvalidCMTA',
    }
    Submit = 0
    Alleged = 1
    Pended = 10
    AllegedNew = 11
    AllegedAddendum = 12
    AllegedNo = 13
    AllegedTradeReportCancel = 14
    AllegedTradeBreak = 15
    Verify = 16
    Dispute = 17
    Accept = 2
    Decline = 3
    Addendum = 4
    No = 5
    TradeReportCancel = 6
    LockedIn = 7
    Defaulted = 8
    InvalidCMTA = 9


class TrdRptStatus(fix.Field, Tag="939", Name="TrdRptStatus", Type=fix.FixInt):
    Values = {
        0: 'Accepted',
        1: 'Rejected',
        10: 'Verified',
        11: 'Disputed',
        2: 'Cancelled',
        3: 'AcceptedWithErrors',
        4: 'PendingNew',
        5: 'PendingCancel',
        6: 'PendingReplace',
        7: 'Terminated',
        8: 'PendingVerification',
        9: 'DeemedVerified',
    }
    Accepted = 0
    Rejected = 1
    Verified = 10
    Disputed = 11
    Cancelled = 2
    AcceptedWithErrors = 3
    PendingNew = 4
    PendingCancel = 5
    PendingReplace = 6
    Terminated = 7
    PendingVerification = 8
    DeemedVerified = 9


class NoTradePriceConditions(fix.Field, Tag="1838", Name="NoTradePriceConditions", Type=fix.FixInt):
    Values = {
    }


class OrigTradeID(fix.Field, Tag="1126", Name="OrigTradeID", Type=fix.FixString):
    Values = {
    }


class TotNumTradeReports(fix.Field, Tag="748", Name="TotNumTradeReports", Type=fix.FixInt):
    Values = {
    }


class ExecRestatementReason(fix.Field, Tag="378", Name="ExecRestatementReason", Type=fix.FixInt):
    Values = {
        0: 'GTCorporateAction',
        1: 'GTRenewal',
        10: 'WarehouseRecap',
        100: 'OrderRejectedWhenTriggered',
        101: 'CancelledduetoCircuitBreaker',
        102: 'CancelledduetoCorporateAction',
        103: 'CxldSMPGroupDefault',
        11: 'PegRefresh',
        12: 'CancelOnConnectionLoss',
        13: 'CancelOnLogout',
        14: 'AssignTimePriority',
        15: 'CancelledForTradePriceViolation',
        16: 'CancelledForCrossImbalance',
        17: 'CxldSMP',
        2: 'VerbalChange',
        3: 'RepricingOfOrder',
        4: 'BrokerOption',
        5: 'PartialDeclineOfOrderQty',
        6: 'CancelOnTradingHalt',
        7: 'CancelOnSystemFailure',
        8: 'Market',
        9: 'Canceled',
        99: 'Other',
    }
    GTCorporateAction = 0
    GTRenewal = 1
    WarehouseRecap = 10
    OrderRejectedWhenTriggered = 100
    CancelledduetoCircuitBreaker = 101
    CancelledduetoCorporateAction = 102
    CxldSMPGroupDefault = 103
    PegRefresh = 11
    CancelOnConnectionLoss = 12
    CancelOnLogout = 13
    AssignTimePriority = 14
    CancelledForTradePriceViolation = 15
    CancelledForCrossImbalance = 16
    CxldSMP = 17
    VerbalChange = 2
    RepricingOfOrder = 3
    BrokerOption = 4
    PartialDeclineOfOrderQty = 5
    CancelOnTradingHalt = 6
    CancelOnSystemFailure = 7
    Market = 8
    Canceled = 9
    Other = 99


class NoRegulatoryTradeIDs(fix.Field, Tag="1907", Name="NoRegulatoryTradeIDs", Type=fix.FixInt):
    Values = {
    }


class RegulatoryTradeID(fix.Field, Tag="1903", Name="RegulatoryTradeID", Type=fix.FixString):
    Values = {
    }


class RegulatoryTradeIDType(fix.Field, Tag="1906", Name="RegulatoryTradeIDType", Type=fix.FixInt):
    Values = {
        0: 'Current',
        1: 'Previous',
        2: 'Block',
        3: 'Related',
        4: 'ClearedBlockTrade',
        5: 'TradingVenueTransactionIdentifier',
    }
    Current = 0
    Previous = 1
    Block = 2
    Related = 3
    ClearedBlockTrade = 4
    TradingVenueTransactionIdentifier = 5


class PreviouslyReported(fix.Field, Tag="570", Name="PreviouslyReported", Type=fix.FixBool):
    Values = {
        'N': 'NotReportedToCounterparty',
        'Y': 'PreviouslyReportedToCounterparty',
    }
    NotReportedToCounterparty = 'N'
    PreviouslyReportedToCounterparty = 'Y'


class VenueType(fix.Field, Tag="1430", Name="VenueType", Type=fix.FixChar):
    Values = {
        'B': 'CentralLimitOrderBook',
        'C': 'ClearingHouse',
        'D': 'DarkOrderBook',
        'E': 'Electronic',
        'N': 'QuoteNegotiation',
        'O': 'OffMarket',
        'P': 'Pit',
        'Q': 'QuoteDrivenMarket',
        'R': 'RegisteredMarket',
        'X': 'ExPit',
    }
    CentralLimitOrderBook = 'B'
    ClearingHouse = 'C'
    DarkOrderBook = 'D'
    Electronic = 'E'
    QuoteNegotiation = 'N'
    OffMarket = 'O'
    Pit = 'P'
    QuoteDrivenMarket = 'Q'
    RegisteredMarket = 'R'
    ExPit = 'X'


class NoPayments(fix.Field, Tag="40212", Name="NoPayments", Type=fix.FixInt):
    Values = {
    }


class NoPaymentBusinessCenters(fix.Field, Tag="40944", Name="NoPaymentBusinessCenters", Type=fix.FixInt):
    Values = {
    }


class NoPaymentSettls(fix.Field, Tag="40230", Name="NoPaymentSettls", Type=fix.FixInt):
    Values = {
    }


class NoPaymentSettlPartyIDs(fix.Field, Tag="40233", Name="NoPaymentSettlPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoPaymentSettlPartySubIDs(fix.Field, Tag="40238", Name="NoPaymentSettlPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoCollateralAmounts(fix.Field, Tag="1703", Name="NoCollateralAmounts", Type=fix.FixInt):
    Values = {
    }


class LastQty(fix.Field, Tag="32", Name="LastQty", Type=fix.FixQuantity):
    Values = {
    }


class LastPx(fix.Field, Tag="31", Name="LastPx", Type=fix.FixPrice):
    Values = {
    }


class LastMkt(fix.Field, Tag="30", Name="LastMkt", Type=fix.FixExchange):
    Values = {
    }


class AvgPx(fix.Field, Tag="6", Name="AvgPx", Type=fix.FixPrice):
    Values = {
    }


class NoPosAmt(fix.Field, Tag="753", Name="NoPosAmt", Type=fix.FixInt):
    Values = {
    }


class NoLegPosAmt(fix.Field, Tag="1586", Name="NoLegPosAmt", Type=fix.FixInt):
    Values = {
    }


class LegLastPx(fix.Field, Tag="637", Name="LegLastPx", Type=fix.FixPrice):
    Values = {
    }


class LegLastQty(fix.Field, Tag="1418", Name="LegLastQty", Type=fix.FixQuantity):
    Values = {
    }


class NoOfLegUnderlyings(fix.Field, Tag="1342", Name="NoOfLegUnderlyings", Type=fix.FixInt):
    Values = {
    }


class NoUnderlyingLegSecurityAltID(fix.Field, Tag="1334", Name="NoUnderlyingLegSecurityAltID", Type=fix.FixInt):
    Values = {
    }


class NoTradeQtys(fix.Field, Tag="1841", Name="NoTradeQtys", Type=fix.FixInt):
    Values = {
    }


class NoSides(fix.Field, Tag="552", Name="NoSides", Type=fix.FixInt):
    Values = {
        1: 'OneSide',
        2: 'BothSides',
    }
    OneSide = 1
    BothSides = 2


class NoLimitAmts(fix.Field, Tag="1630", Name="NoLimitAmts", Type=fix.FixInt):
    Values = {
    }


class NoClearingInstructions(fix.Field, Tag="576", Name="NoClearingInstructions", Type=fix.FixInt):
    Values = {
    }


class NoSideRegulatoryTradeIDs(fix.Field, Tag="1971", Name="NoSideRegulatoryTradeIDs", Type=fix.FixInt):
    Values = {
    }


class StartCash(fix.Field, Tag="921", Name="StartCash", Type=fix.FixAmount):
    Values = {
    }


class EndCash(fix.Field, Tag="922", Name="EndCash", Type=fix.FixAmount):
    Values = {
    }


class NoContAmts(fix.Field, Tag="518", Name="NoContAmts", Type=fix.FixInt):
    Values = {
    }


class NoMiscFees(fix.Field, Tag="136", Name="NoMiscFees", Type=fix.FixInt):
    Values = {
    }


class NoMiscFeeSubTypes(fix.Field, Tag="2633", Name="NoMiscFeeSubTypes", Type=fix.FixInt):
    Values = {
    }


class NoAllocRegulatoryTradeIDs(fix.Field, Tag="1908", Name="NoAllocRegulatoryTradeIDs", Type=fix.FixInt):
    Values = {
    }


class NoNested2PartyIDs(fix.Field, Tag="756", Name="NoNested2PartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoNested2PartySubIDs(fix.Field, Tag="806", Name="NoNested2PartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoTradeAllocAmts(fix.Field, Tag="1844", Name="NoTradeAllocAmts", Type=fix.FixInt):
    Values = {
    }


class NoAllocCommissions(fix.Field, Tag="2653", Name="NoAllocCommissions", Type=fix.FixInt):
    Values = {
    }


class NoSideTrdRegTS(fix.Field, Tag="1016", Name="NoSideTrdRegTS", Type=fix.FixInt):
    Values = {
    }


class NoSettlDetails(fix.Field, Tag="1158", Name="NoSettlDetails", Type=fix.FixInt):
    Values = {
    }


class NoSettlPartyIDs(fix.Field, Tag="781", Name="NoSettlPartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoSettlPartySubIDs(fix.Field, Tag="801", Name="NoSettlPartySubIDs", Type=fix.FixInt):
    Values = {
    }


class AggressorIndicator(fix.Field, Tag="1057", Name="AggressorIndicator", Type=fix.FixBool):
    Values = {
        'N': 'OrderInitiatorIsPassive',
        'Y': 'OrderInitiatorIsAggressor',
    }
    OrderInitiatorIsPassive = 'N'
    OrderInitiatorIsAggressor = 'Y'


class OrderCategory(fix.Field, Tag="1115", Name="OrderCategory", Type=fix.FixChar):
    Values = {
        '1': 'Order',
        '2': 'Quote',
        '3': 'PrivatelyNegotiatedTrade',
        '4': 'MultilegOrder',
        '5': 'LinkedOrder',
        '6': 'QuoteRequest',
        '7': 'ImpliedOrder',
        '8': 'CrossOrder',
        '9': 'StreamingPrice',
        'A': 'InternalCrossOrder',
    }
    Order = '1'
    Quote = '2'
    PrivatelyNegotiatedTrade = '3'
    MultilegOrder = '4'
    LinkedOrder = '5'
    QuoteRequest = '6'
    ImpliedOrder = '7'
    CrossOrder = '8'
    StreamingPrice = '9'
    InternalCrossOrder = 'A'


class StrategyLinkID(fix.Field, Tag="1851", Name="StrategyLinkID", Type=fix.FixString):
    Values = {
    }


class SecondaryOrderID(fix.Field, Tag="198", Name="SecondaryOrderID", Type=fix.FixString):
    Values = {
    }


class OrdStatus(fix.Field, Tag="39", Name="OrdStatus", Type=fix.FixChar):
    Values = {
        '0': 'New',
        '1': 'PartiallyFilled',
        '2': 'Filled',
        '3': 'DoneForDay',
        '4': 'Canceled',
        '5': 'ReplacedNolongerused',
        '6': 'PendingCancel',
        '7': 'Stopped',
        '8': 'Rejected',
        '9': 'Suspended',
        'A': 'PendingNew',
        'B': 'Calculated',
        'C': 'Expired',
        'D': 'AcceptedForBidding',
        'E': 'PendingReplace',
    }
    New = '0'
    PartiallyFilled = '1'
    Filled = '2'
    DoneForDay = '3'
    Canceled = '4'
    ReplacedNolongerused = '5'
    PendingCancel = '6'
    Stopped = '7'
    Rejected = '8'
    Suspended = '9'
    PendingNew = 'A'
    Calculated = 'B'
    Expired = 'C'
    AcceptedForBidding = 'D'
    PendingReplace = 'E'


class LeavesQty(fix.Field, Tag="151", Name="LeavesQty", Type=fix.FixQuantity):
    Values = {
    }


class CumQty(fix.Field, Tag="14", Name="CumQty", Type=fix.FixQuantity):
    Values = {
    }


class TransBkdTime(fix.Field, Tag="483", Name="TransBkdTime", Type=fix.FixUTCTimeStamp):
    Values = {
    }


class NoPositions(fix.Field, Tag="702", Name="NoPositions", Type=fix.FixInt):
    Values = {
    }


class NoRelatedTrades(fix.Field, Tag="1855", Name="NoRelatedTrades", Type=fix.FixInt):
    Values = {
    }


class RelatedTradeID(fix.Field, Tag="1856", Name="RelatedTradeID", Type=fix.FixString):
    Values = {
    }


class RelatedTradeIDSource(fix.Field, Tag="1857", Name="RelatedTradeIDSource", Type=fix.FixInt):
    Values = {
        0: 'NonFIXSource',
        1: 'TradeID',
        2: 'SecondaryTradeID',
        3: 'TradeReportID',
        4: 'FirmTradeID',
        5: 'SecondaryFirmTradeID',
        6: 'RegulatoryTradeID',
    }
    NonFIXSource = 0
    TradeID = 1
    SecondaryTradeID = 2
    TradeReportID = 3
    FirmTradeID = 4
    SecondaryFirmTradeID = 5
    RegulatoryTradeID = 6


class NoRelatedPositions(fix.Field, Tag="1861", Name="NoRelatedPositions", Type=fix.FixInt):
    Values = {
    }


class CopyMsgIndicator(fix.Field, Tag="797", Name="CopyMsgIndicator", Type=fix.FixBool):
    Values = {
    }


class NoTrdRepIndicators(fix.Field, Tag="1387", Name="NoTrdRepIndicators", Type=fix.FixInt):
    Values = {
    }


class TradeReportRejectReason(fix.Field, Tag="751", Name="TradeReportRejectReason", Type=fix.FixInt):
    Values = {
        0: 'Successful',
        1: 'InvalidPartyOnformation',
        149: 'Dealcancelledbyintermediary',
        2: 'UnknownInstrument',
        3: 'UnauthorizedToReportTrades',
        4: 'InvalidTradeType',
        5: 'PriceExceedsCurrentPriceBand',
        6: 'ReferencePriceNotAvailable',
        7: 'NotionalValueExceedsThreshold',
        99: 'Other',
    }
    Successful = 0
    InvalidPartyOnformation = 1
    Dealcancelledbyintermediary = 149
    UnknownInstrument = 2
    UnauthorizedToReportTrades = 3
    InvalidTradeType = 4
    PriceExceedsCurrentPriceBand = 5
    ReferencePriceNotAvailable = 6
    NotionalValueExceedsThreshold = 7
    Other = 99


class RejectText(fix.Field, Tag="1328", Name="RejectText", Type=fix.FixString):
    Values = {
    }


class NoMandatoryClearingJurisdictions(fix.Field, Tag="41312", Name="NoMandatoryClearingJurisdictions", Type=fix.FixInt):
    Values = {
    }


class RegulatoryReportType(fix.Field, Tag="1934", Name="RegulatoryReportType", Type=fix.FixInt):
    Values = {
        0: 'RT',
        1: 'PET',
        10: 'PstTrdEvntRTReportable',
        2: 'Snapshot',
        3: 'Confirmation',
        4: 'RTPET',
        5: 'PETConfirmation',
        6: 'RTPETConfirmation',
        7: 'PostTrade',
        8: 'Verification',
        9: 'PstTrdEvnt',
    }
    RT = 0
    PET = 1
    PstTrdEvntRTReportable = 10
    Snapshot = 2
    Confirmation = 3
    RTPET = 4
    PETConfirmation = 5
    RTPETConfirmation = 6
    PostTrade = 7
    Verification = 8
    PstTrdEvnt = 9


class NoAttachments(fix.Field, Tag="2104", Name="NoAttachments", Type=fix.FixInt):
    Values = {
    }


class NoAttachmentKeywords(fix.Field, Tag="2113", Name="NoAttachmentKeywords", Type=fix.FixInt):
    Values = {
    }


class MassStatusReqID(fix.Field, Tag="584", Name="MassStatusReqID", Type=fix.FixString):
    Values = {
    }


class MassStatusReqType(fix.Field, Tag="585", Name="MassStatusReqType", Type=fix.FixInt):
    Values = {
        1: 'StatusForOrdersForASecurity',
        10: 'StatusForIssuerOfUnderlyingSecurity',
        2: 'StatusForOrdersForAnUnderlyingSecurity',
        3: 'StatusForOrdersForAProduct',
        4: 'StatusForOrdersForACFICode',
        5: 'StatusForOrdersForASecurityType',
        6: 'StatusForOrdersForATradingSession',
        7: 'StatusForAllOrders',
        701: 'SnapshotAllOrders',
        702: 'SnapshotAndUpdatesAllOrders',
        703: 'UnsubscribeAllOrders',
        8: 'StatusForOrdersForAPartyID',
        9: 'StatusForSecurityIssuer',
    }
    StatusForOrdersForASecurity = 1
    StatusForIssuerOfUnderlyingSecurity = 10
    StatusForOrdersForAnUnderlyingSecurity = 2
    StatusForOrdersForAProduct = 3
    StatusForOrdersForACFICode = 4
    StatusForOrdersForASecurityType = 5
    StatusForOrdersForATradingSession = 6
    StatusForAllOrders = 7
    SnapshotAllOrders = 701
    SnapshotAndUpdatesAllOrders = 702
    UnsubscribeAllOrders = 703
    StatusForOrdersForAPartyID = 8
    StatusForSecurityIssuer = 9


class QuoteRequestRejectReason(fix.Field, Tag="658", Name="QuoteRequestRejectReason", Type=fix.FixInt):
    Values = {
        1: 'UnknownSymbol',
        10: 'Pass',
        101: 'InvalidExposureDuration',
        102: 'UnknownRecipient',
        103: 'UnacceptableCounterPartyRole',
        104: 'TooManyRecipientsSpecified',
        105: 'DuplicateRecipients',
        11: 'InsufficientCredit',
        12: 'ExceededClipSizeLimit',
        13: 'ExceededMaxNotionalOrderAmt',
        14: 'ExceededDV01PV01Limit',
        15: 'ExceededCS01Limit',
        2: 'Exchange',
        3: 'QuoteRequestExceedsLimit',
        4: 'TooLateToEnter',
        5: 'InvalidPrice',
        6: 'NotAuthorizedToRequestQuote',
        7: 'NoMatchForInquiry',
        8: 'NoMarketForInstrument',
        9: 'NoInventory',
        99: 'Other',
    }
    UnknownSymbol = 1
    Pass = 10
    InvalidExposureDuration = 101
    UnknownRecipient = 102
    UnacceptableCounterPartyRole = 103
    TooManyRecipientsSpecified = 104
    DuplicateRecipients = 105
    InsufficientCredit = 11
    ExceededClipSizeLimit = 12
    ExceededMaxNotionalOrderAmt = 13
    ExceededDV01PV01Limit = 14
    ExceededCS01Limit = 15
    Exchange = 2
    QuoteRequestExceedsLimit = 3
    TooLateToEnter = 4
    InvalidPrice = 5
    NotAuthorizedToRequestQuote = 6
    NoMatchForInquiry = 7
    NoMarketForInstrument = 8
    NoInventory = 9
    Other = 99


class QuoteRespType(fix.Field, Tag="694", Name="QuoteRespType", Type=fix.FixInt):
    Values = {
        1: 'Hit',
        10: 'TiedCover',
        2: 'Counter',
        3: 'Expired',
        4: 'Cover',
        5: 'DoneAway',
        6: 'Pass',
        7: 'EndTrade',
        8: 'TimedOut',
        9: 'Tied',
    }
    Hit = 1
    TiedCover = 10
    Counter = 2
    Expired = 3
    Cover = 4
    DoneAway = 5
    Pass = 6
    EndTrade = 7
    TimedOut = 8
    Tied = 9


class RefSeqNum(fix.Field, Tag="45", Name="RefSeqNum", Type=fix.FixInt):
    Values = {
    }


class BusinessRejectReason(fix.Field, Tag="380", Name="BusinessRejectReason", Type=fix.FixInt):
    Values = {
        0: 'Other',
        1: 'UnknownID',
        10: 'ThrottledMessagesRejectedOnRequest',
        18: 'InvalidPriceIncrement',
        2: 'UnknownSecurity',
        3: 'UnsupportedMessageType',
        4: 'ApplicationNotAvailable',
        5: 'ConditionallyRequiredFieldMissing',
        6: 'NotAuthorized',
        7: 'DeliverToFirmNotAvailableAtThisTime',
        8: 'ThrottleLimitExceeded',
        9: 'ThrottleLimitExceededSessionDisconnected',
    }
    Other = 0
    UnknownID = 1
    ThrottledMessagesRejectedOnRequest = 10
    InvalidPriceIncrement = 18
    UnknownSecurity = 2
    UnsupportedMessageType = 3
    ApplicationNotAvailable = 4
    ConditionallyRequiredFieldMissing = 5
    NotAuthorized = 6
    DeliverToFirmNotAvailableAtThisTime = 7
    ThrottleLimitExceeded = 8
    ThrottleLimitExceededSessionDisconnected = 9


class TestReqID(fix.Field, Tag="112", Name="TestReqID", Type=fix.FixString):
    Values = {
    }


class TradeRequestResult(fix.Field, Tag="749", Name="TradeRequestResult", Type=fix.FixInt):
    Values = {
        0: 'Successful',
        1: 'InvalidOrUnknownInstrument',
        2: 'InvalidTypeOfTradeRequested',
        3: 'InvalidParties',
        4: 'InvalidTransportTypeRequested',
        5: 'InvalidDestinationRequested',
        8: 'TradeRequestTypeNotSupported',
        9: 'NotAuthorized',
        99: 'Other',
    }
    Successful = 0
    InvalidOrUnknownInstrument = 1
    InvalidTypeOfTradeRequested = 2
    InvalidParties = 3
    InvalidTransportTypeRequested = 4
    InvalidDestinationRequested = 5
    TradeRequestTypeNotSupported = 8
    NotAuthorized = 9
    Other = 99


class TradeRequestStatus(fix.Field, Tag="750", Name="TradeRequestStatus", Type=fix.FixInt):
    Values = {
        0: 'Accepted',
        1: 'Completed',
        2: 'Rejected',
    }
    Accepted = 0
    Completed = 1
    Rejected = 2


class BeginSeqNo(fix.Field, Tag="7", Name="BeginSeqNo", Type=fix.FixInt):
    Values = {
    }


class EndSeqNo(fix.Field, Tag="16", Name="EndSeqNo", Type=fix.FixInt):
    Values = {
    }


class RefTagID(fix.Field, Tag="371", Name="RefTagID", Type=fix.FixInt):
    Values = {
    }


class SessionRejectReason(fix.Field, Tag="373", Name="SessionRejectReason", Type=fix.FixInt):
    Values = {
        0: 'InvalidTagNumber',
        1: 'RequiredTagMissing',
        10: 'SendingTimeAccuracyProblem',
        11: 'InvalidMsgType',
        12: 'XMLValidationError',
        13: 'TagAppearsMoreThanOnce',
        14: 'TagSpecifiedOutOfRequiredOrder',
        15: 'RepeatingGroupFieldsOutOfOrder',
        16: 'IncorrectNumInGroupCountForRepeatingGroup',
        17: 'Non',
        18: 'Invalid',
        2: 'TagNotDefinedForThisMessageType',
        3: 'UndefinedTag',
        4: 'TagSpecifiedWithoutAValue',
        5: 'ValueIsIncorrect',
        6: 'IncorrectDataFormatForValue',
        7: 'DecryptionProblem',
        8: 'SignatureProblem',
        9: 'CompIDProblem',
        99: 'Other',
    }
    InvalidTagNumber = 0
    RequiredTagMissing = 1
    SendingTimeAccuracyProblem = 10
    InvalidMsgType = 11
    XMLValidationError = 12
    TagAppearsMoreThanOnce = 13
    TagSpecifiedOutOfRequiredOrder = 14
    RepeatingGroupFieldsOutOfOrder = 15
    IncorrectNumInGroupCountForRepeatingGroup = 16
    Non = 17
    Invalid = 18
    TagNotDefinedForThisMessageType = 2
    UndefinedTag = 3
    TagSpecifiedWithoutAValue = 4
    ValueIsIncorrect = 5
    IncorrectDataFormatForValue = 6
    DecryptionProblem = 7
    SignatureProblem = 8
    CompIDProblem = 9
    Other = 99


class QuoteAckStatus(fix.Field, Tag="1865", Name="QuoteAckStatus", Type=fix.FixInt):
    Values = {
        0: 'ReceivedNotYetProcessed',
        1: 'Accepted',
        2: 'Rejected',
    }
    ReceivedNotYetProcessed = 0
    Accepted = 1
    Rejected = 2


class GapFillFlag(fix.Field, Tag="123", Name="GapFillFlag", Type=fix.FixBool):
    Values = {
        'N': 'SequenceReset',
        'Y': 'GapFillMessage',
    }
    SequenceReset = 'N'
    GapFillMessage = 'Y'


class NewSeqNo(fix.Field, Tag="36", Name="NewSeqNo", Type=fix.FixInt):
    Values = {
    }


class NoContraBrokers(fix.Field, Tag="382", Name="NoContraBrokers", Type=fix.FixInt):
    Values = {
    }


class ExecRefID(fix.Field, Tag="19", Name="ExecRefID", Type=fix.FixString):
    Values = {
    }


class ExecTypeReason(fix.Field, Tag="2431", Name="ExecTypeReason", Type=fix.FixInt):
    Values = {
        1: 'OrdAddedOnRequest',
        10: 'OrdCxlPending',
        11: 'PendingCxlExecuted',
        117: 'Cancelledbyotheruser',
        118: 'Modifiedbyotheruser',
        12: 'RestingOrdTriggered',
        13: 'SuspendedOrdActivated',
        14: 'ActiveOrdSuspended',
        15: 'OrdExpired',
        2: 'OrdReplacedOnRequest',
        3: 'OrdCxldOnRequest',
        4: 'UnsolicitedOrdCxl',
        5: 'NonRestingOrdAddedOnRequest',
        6: 'OrdReplacedWithNonRestingOrdOnRequest',
        7: 'TriggerOrdReplacedOnRequest',
        8: 'SuspendedOrdReplacedOnRequest',
        9: 'SuspendedOrdCxldOnRequest',
    }
    OrdAddedOnRequest = 1
    OrdCxlPending = 10
    PendingCxlExecuted = 11
    Cancelledbyotheruser = 117
    Modifiedbyotheruser = 118
    RestingOrdTriggered = 12
    SuspendedOrdActivated = 13
    ActiveOrdSuspended = 14
    OrdExpired = 15
    OrdReplacedOnRequest = 2
    OrdCxldOnRequest = 3
    UnsolicitedOrdCxl = 4
    NonRestingOrdAddedOnRequest = 5
    OrdReplacedWithNonRestingOrdOnRequest = 6
    TriggerOrdReplacedOnRequest = 7
    SuspendedOrdReplacedOnRequest = 8
    SuspendedOrdCxldOnRequest = 9


class OrdRejReason(fix.Field, Tag="103", Name="OrdRejReason", Type=fix.FixInt):
    Values = {
        0: 'BrokerCredit',
        1: 'UnknownSymbol',
        10: 'InvalidInvestorID',
        11: 'UnsupportedOrderCharacteristic',
        12: 'SurveillanceOption',
        13: 'IncorrectQuantity',
        14: 'IncorrectAllocatedQuantity',
        15: 'UnknownAccount',
        16: 'PriceExceedsCurrentPriceBand',
        18: 'InvalidPriceIncrement',
        19: 'ReferencePriceNotAvailable',
        2: 'ExchangeClosed',
        20: 'NotionalValueExceedsThreshold',
        21: 'AlgorithRiskThresholdBreached',
        22: 'ShortSellNotPermitted',
        23: 'ShortSellSecurityPreBorrowRestriction',
        24: 'ShortSellAccountPreBorrowRestriction',
        25: 'InsufficientCreditLimit',
        26: 'ExceededClipSizeLimit',
        27: 'ExceededMaxNotionalOrderAmt',
        28: 'ExceededDV01PV01Limit',
        29: 'ExceededCS01Limit',
        3: 'OrderExceedsLimit',
        4: 'TooLateToEnter',
        5: 'UnknownOrder',
        6: 'DuplicateOrder',
        7: 'DuplicateOfAVerballyCommunicatedOrder',
        8: 'StaleOrder',
        9: 'TradeAlongRequired',
        99: 'Other',
    }
    BrokerCredit = 0
    UnknownSymbol = 1
    InvalidInvestorID = 10
    UnsupportedOrderCharacteristic = 11
    SurveillanceOption = 12
    IncorrectQuantity = 13
    IncorrectAllocatedQuantity = 14
    UnknownAccount = 15
    PriceExceedsCurrentPriceBand = 16
    InvalidPriceIncrement = 18
    ReferencePriceNotAvailable = 19
    ExchangeClosed = 2
    NotionalValueExceedsThreshold = 20
    AlgorithRiskThresholdBreached = 21
    ShortSellNotPermitted = 22
    ShortSellSecurityPreBorrowRestriction = 23
    ShortSellAccountPreBorrowRestriction = 24
    InsufficientCreditLimit = 25
    ExceededClipSizeLimit = 26
    ExceededMaxNotionalOrderAmt = 27
    ExceededDV01PV01Limit = 28
    ExceededCS01Limit = 29
    OrderExceedsLimit = 3
    TooLateToEnter = 4
    UnknownOrder = 5
    DuplicateOrder = 6
    DuplicateOfAVerballyCommunicatedOrder = 7
    StaleOrder = 8
    TradeAlongRequired = 9
    Other = 99


class PeggedPrice(fix.Field, Tag="839", Name="PeggedPrice", Type=fix.FixPrice):
    Values = {
    }


class CxlQty(fix.Field, Tag="84", Name="CxlQty", Type=fix.FixQuantity):
    Values = {
    }


class NoFills(fix.Field, Tag="1362", Name="NoFills", Type=fix.FixInt):
    Values = {
    }


class NoNested4PartyIDs(fix.Field, Tag="1414", Name="NoNested4PartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoNested4PartySubIDs(fix.Field, Tag="1413", Name="NoNested4PartySubIDs", Type=fix.FixInt):
    Values = {
    }


class NoOrderEvents(fix.Field, Tag="1795", Name="NoOrderEvents", Type=fix.FixInt):
    Values = {
    }


class NoLegAllocs(fix.Field, Tag="670", Name="NoLegAllocs", Type=fix.FixInt):
    Values = {
    }


class NoNested3PartyIDs(fix.Field, Tag="948", Name="NoNested3PartyIDs", Type=fix.FixInt):
    Values = {
    }


class NoNested3PartySubIDs(fix.Field, Tag="952", Name="NoNested3PartySubIDs", Type=fix.FixInt):
    Values = {
    }


class SecurityListRequestType(fix.Field, Tag="559", Name="SecurityListRequestType", Type=fix.FixInt):
    Values = {
        0: 'Symbol',
        1: 'SecurityTypeAnd',
        2: 'Product',
        3: 'TradingSessionID',
        4: 'AllSecurities',
        5: 'MarketIDOrMarketID',
    }
    Symbol = 0
    SecurityTypeAnd = 1
    Product = 2
    TradingSessionID = 3
    AllSecurities = 4
    MarketIDOrMarketID = 5


class CxlRejResponseTo(fix.Field, Tag="434", Name="CxlRejResponseTo", Type=fix.FixChar):
    Values = {
        '1': 'OrderCancelRequest',
        '2': 'OrderCancelReplaceRequest',
    }
    OrderCancelRequest = '1'
    OrderCancelReplaceRequest = '2'


class CxlRejReason(fix.Field, Tag="102", Name="CxlRejReason", Type=fix.FixInt):
    Values = {
        0: 'TooLateToCancel',
        1: 'UnknownOrder',
        18: 'InvalidPriceIncrement',
        2: 'BrokerCredit',
        3: 'OrderAlreadyInPendingStatus',
        4: 'UnableToProcessOrderMassCancelRequest',
        5: 'OrigOrdModTime',
        6: 'DuplicateClOrdID',
        7: 'PriceExceedsCurrentPrice',
        8: 'PriceExceedsCurrentPriceBand',
        99: 'Other',
    }
    TooLateToCancel = 0
    UnknownOrder = 1
    InvalidPriceIncrement = 18
    BrokerCredit = 2
    OrderAlreadyInPendingStatus = 3
    UnableToProcessOrderMassCancelRequest = 4
    OrigOrdModTime = 5
    DuplicateClOrdID = 6
    PriceExceedsCurrentPrice = 7
    PriceExceedsCurrentPriceBand = 8
    Other = 99


class NoSecurityClassifications(fix.Field, Tag="1582", Name="NoSecurityClassifications", Type=fix.FixInt):
    Values = {
    }


class SecurityClassificationReason(fix.Field, Tag="1583", Name="SecurityClassificationReason", Type=fix.FixInt):
    Values = {
        0: 'Fee',
        1: 'CreditControls',
        104: 'AssetType',
        105: 'ListingBoard',
        2: 'Margin',
        3: 'EntitlementOrEligibility',
        4: 'MarketData',
        5: 'AccountSelection',
        6: 'DeliveryProcess',
        7: 'Sector',
    }
    Fee = 0
    CreditControls = 1
    AssetType = 104
    ListingBoard = 105
    Margin = 2
    EntitlementOrEligibility = 3
    MarketData = 4
    AccountSelection = 5
    DeliveryProcess = 6
    Sector = 7


class SecurityClassificationValue(fix.Field, Tag="1584", Name="SecurityClassificationValue", Type=fix.FixString):
    Values = {
    }


class NoPriceMovements(fix.Field, Tag="1919", Name="NoPriceMovements", Type=fix.FixInt):
    Values = {
    }


class NoPriceMovementValues(fix.Field, Tag="1920", Name="NoPriceMovementValues", Type=fix.FixInt):
    Values = {
    }


class NoClearingAccountTypes(fix.Field, Tag="1918", Name="NoClearingAccountTypes", Type=fix.FixInt):
    Values = {
    }


class SelfMatchPreventionID(fix.Field, Tag="2362", Name="SelfMatchPreventionID", Type=fix.FixString):
    Values = {
    }


class SingleQuoteIndicator(fix.Field, Tag="2837", Name="SingleQuoteIndicator", Type=fix.FixBool):
    Values = {
    }


class NoQuoteAttributes(fix.Field, Tag="2706", Name="NoQuoteAttributes", Type=fix.FixInt):
    Values = {
    }


class QuoteAttributeType(fix.Field, Tag="2707", Name="QuoteAttributeType", Type=fix.FixInt):
    Values = {
        0: 'QuoteAboveStandardMarketSize',
        1: 'QuoteAboveSpecificInstrumentSize',
        2: 'QuoteApplicableForLiquidtyProvisionActivity',
        3: 'QuoteIssuerStatus',
        4: 'BidOrAskRequest',
    }
    QuoteAboveStandardMarketSize = 0
    QuoteAboveSpecificInstrumentSize = 1
    QuoteApplicableForLiquidtyProvisionActivity = 2
    QuoteIssuerStatus = 3
    BidOrAskRequest = 4


class QuoteAttributeValue(fix.Field, Tag="2708", Name="QuoteAttributeValue", Type=fix.FixString):
    Values = {
    }


class NoOrderAttributes(fix.Field, Tag="2593", Name="NoOrderAttributes", Type=fix.FixInt):
    Values = {
    }


class OrderAttributeType(fix.Field, Tag="2594", Name="OrderAttributeType", Type=fix.FixInt):
    Values = {
        0: 'AggregatedOrder',
        1: 'PendingAllocation',
        1002: 'GreenShoe',
        1003: 'BookBuilding',
        1005: 'PreAgreement',
        1006: 'MarginOrder',
        2: 'LiquidityProvision',
        3: 'RiskReductionOrder',
        4: 'AlgorithmicOrder',
        5: 'SystematicInternalizerOrder',
    }
    AggregatedOrder = 0
    PendingAllocation = 1
    GreenShoe = 1002
    BookBuilding = 1003
    PreAgreement = 1005
    MarginOrder = 1006
    LiquidityProvision = 2
    RiskReductionOrder = 3
    AlgorithmicOrder = 4
    SystematicInternalizerOrder = 5


class OrderAttributeValue(fix.Field, Tag="2595", Name="OrderAttributeValue", Type=fix.FixString):
    Values = {
        'N': 'No',
        'Y': 'Yes',
    }
    No = 'N'
    Yes = 'Y'


class TrdRegPublicationType(fix.Field, Tag="2669", Name="TrdRegPublicationType", Type=fix.FixInt):
    Values = {
        1: 'Posttradedeferral',
    }
    Posttradedeferral = 1


class TrdRegPublicationReason(fix.Field, Tag="2670", Name="TrdRegPublicationReason", Type=fix.FixInt):
    Values = {
        102: 'DeferredPublicationEOD',
        6: 'DeferralduetoLargeinScaleLRGS',
        7: 'DeferralduetoilliquidinstrumentILQD',
        8: 'DeferralduetoSizeSpecificSIZE',
    }
    DeferredPublicationEOD = 102
    DeferralduetoLargeinScaleLRGS = 6
    DeferralduetoilliquidinstrumentILQD = 7
    DeferralduetoSizeSpecificSIZE = 8


class NBBOEntryType(fix.Field, Tag="2831", Name="NBBOEntryType", Type=fix.FixInt):
    Values = {
    }


class NBBOPrice(fix.Field, Tag="2832", Name="NBBOPrice", Type=fix.FixPrice):
    Values = {
    }


class NBBOQty(fix.Field, Tag="2833", Name="NBBOQty", Type=fix.FixPrice):
    Values = {
    }


class NBBOSource(fix.Field, Tag="2834", Name="NBBOSource", Type=fix.FixInt):
    Values = {
    }


class SessionSubtype(fix.Field, Tag="28032", Name="SessionSubtype", Type=fix.FixInt):
    Values = {
    }


class CorpActionID(fix.Field, Tag="29001", Name="CorpActionID", Type=fix.FixInt):
    Values = {
    }


class CorpActionCode(fix.Field, Tag="29002", Name="CorpActionCode", Type=fix.FixString):
    Values = {
    }


class CorpActionCodeDesc(fix.Field, Tag="29003", Name="CorpActionCodeDesc", Type=fix.FixString):
    Values = {
    }


class CorpActionDesc(fix.Field, Tag="29004", Name="CorpActionDesc", Type=fix.FixString):
    Values = {
    }


class CorpActionCodeType(fix.Field, Tag="29005", Name="CorpActionCodeType", Type=fix.FixChar):
    Values = {
    }


class CorpActionStartDate(fix.Field, Tag="29006", Name="CorpActionStartDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class CorpActionEndDate(fix.Field, Tag="29007", Name="CorpActionEndDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class CorpActionRecordDate(fix.Field, Tag="29008", Name="CorpActionRecordDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class CorpActionStatus(fix.Field, Tag="29009", Name="CorpActionStatus", Type=fix.FixInt):
    Values = {
    }


class CorporateActionExtended(fix.Field, Tag="29010", Name="CorporateActionExtended", Type=fix.FixString):
    Values = {
    }


class NoOfCorpActionDetail(fix.Field, Tag="29011", Name="NoOfCorpActionDetail", Type=fix.FixInt):
    Values = {
    }


class CorpActionExDate(fix.Field, Tag="29012", Name="CorpActionExDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class CorpActionPaymentDate(fix.Field, Tag="29013", Name="CorpActionPaymentDate", Type=fix.FixLocalMktDate):
    Values = {
    }


class CorpActionValue(fix.Field, Tag="29014", Name="CorpActionValue", Type=fix.FixInt):
    Values = {
    }



