from nasdaq_protocols import fix
from . import fix_fix_oe_50_fields as fields


class NoNewsRefIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.NewsRefID, False),
    ]

    NewsRefID: str


class NoNewsRefIDs_1_List(fix.GroupContainer, CountCls=fields.NoNewsRefIDs, GroupCls=NoNewsRefIDs_1):
    def __getitem__(self, idx) -> NoNewsRefIDs_1:
        return super(NoNewsRefIDs_1_List, self).__getitem__(idx)


class NoSecurityAltID_1(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_1_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_1):
    def __getitem__(self, idx) -> NoSecurityAltID_1:
        return super(NoSecurityAltID_1_List, self).__getitem__(idx)


class NoEvents_1(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_1_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_1):
    def __getitem__(self, idx) -> NoEvents_1:
        return super(NoEvents_1_List, self).__getitem__(idx)


class NoInstrumentParties_1(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_1_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_1):
    def __getitem__(self, idx) -> NoInstrumentParties_1:
        return super(NoInstrumentParties_1_List, self).__getitem__(idx)


class NoStreams_1(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_1_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_1):
    def __getitem__(self, idx) -> NoStreams_1:
        return super(NoStreams_1_List, self).__getitem__(idx)


class NoInstrAttrib_1(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_1_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_1):
    def __getitem__(self, idx) -> NoInstrAttrib_1:
        return super(NoInstrAttrib_1_List, self).__getitem__(idx)


class NoSecurityAltID_2(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_2_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_2):
    def __getitem__(self, idx) -> NoSecurityAltID_2:
        return super(NoSecurityAltID_2_List, self).__getitem__(idx)


class NoEvents_2(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_2_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_2):
    def __getitem__(self, idx) -> NoEvents_2:
        return super(NoEvents_2_List, self).__getitem__(idx)


class NoInstrumentParties_2(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_2_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_2):
    def __getitem__(self, idx) -> NoInstrumentParties_2:
        return super(NoInstrumentParties_2_List, self).__getitem__(idx)


class NoStreams_2(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_2_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_2):
    def __getitem__(self, idx) -> NoStreams_2:
        return super(NoStreams_2_List, self).__getitem__(idx)


class NoInstrAttrib_2(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_2_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_2):
    def __getitem__(self, idx) -> NoInstrAttrib_2:
        return super(NoInstrAttrib_2_List, self).__getitem__(idx)


class NoRelatedSym_1(fix.Group):
    Entries = [
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_2_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_2_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_2_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_2_List, False),
        fix.Entry(NoInstrAttrib_2_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
    ]

    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_2_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_2_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_2_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_2_List
    NoInstrAttrib: NoInstrAttrib_2_List
    StartDate: str
    EndDate: str


class NoRelatedSym_1_List(fix.GroupContainer, CountCls=fields.NoRelatedSym, GroupCls=NoRelatedSym_1):
    def __getitem__(self, idx) -> NoRelatedSym_1:
        return super(NoRelatedSym_1_List, self).__getitem__(idx)


class NoLegSecurityAltID_1(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_1_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_1):
    def __getitem__(self, idx) -> NoLegSecurityAltID_1:
        return super(NoLegSecurityAltID_1_List, self).__getitem__(idx)


class NoLegSecurityAltID_2(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_2_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_2):
    def __getitem__(self, idx) -> NoLegSecurityAltID_2:
        return super(NoLegSecurityAltID_2_List, self).__getitem__(idx)


class NoLegs_1(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_2_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_2_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_1_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_1):
    def __getitem__(self, idx) -> NoLegs_1:
        return super(NoLegs_1_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_1(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_1_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_1):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_1:
        return super(NoUnderlyingSecurityAltID_1_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_2(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_2_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_2):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_2:
        return super(NoUnderlyingSecurityAltID_2_List, self).__getitem__(idx)


class NoUnderlyings_1(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_2_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_2_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_1_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_1):
    def __getitem__(self, idx) -> NoUnderlyings_1:
        return super(NoUnderlyings_1_List, self).__getitem__(idx)


class NoLinesOfText_1(fix.Group):
    Entries = [
        fix.Entry(fields.Text, True),
        fix.Entry(fields.EncodedTextLen, False),
        fix.Entry(fields.EncodedText, False),
    ]

    Text: str
    EncodedTextLen: int
    EncodedText: str


class NoLinesOfText_1_List(fix.GroupContainer, CountCls=fields.NoLinesOfText, GroupCls=NoLinesOfText_1):
    def __getitem__(self, idx) -> NoLinesOfText_1:
        return super(NoLinesOfText_1_List, self).__getitem__(idx)


class NoSecurityAltID_3(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_3_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_3):
    def __getitem__(self, idx) -> NoSecurityAltID_3:
        return super(NoSecurityAltID_3_List, self).__getitem__(idx)


class NoEvents_3(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_3_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_3):
    def __getitem__(self, idx) -> NoEvents_3:
        return super(NoEvents_3_List, self).__getitem__(idx)


class NoInstrumentParties_3(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_3_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_3):
    def __getitem__(self, idx) -> NoInstrumentParties_3:
        return super(NoInstrumentParties_3_List, self).__getitem__(idx)


class NoStreams_3(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_3_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_3):
    def __getitem__(self, idx) -> NoStreams_3:
        return super(NoStreams_3_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_3(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_3_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_3):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_3:
        return super(NoUnderlyingSecurityAltID_3_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_4(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_4_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_4):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_4:
        return super(NoUnderlyingSecurityAltID_4_List, self).__getitem__(idx)


class NoUnderlyings_2(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_4_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_4_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_2_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_2):
    def __getitem__(self, idx) -> NoUnderlyings_2:
        return super(NoUnderlyings_2_List, self).__getitem__(idx)


class NoOrdTypeRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_1_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_1):
    def __getitem__(self, idx) -> NoOrdTypeRules_1:
        return super(NoOrdTypeRules_1_List, self).__getitem__(idx)


class NoTimeInForceRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_1_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_1):
    def __getitem__(self, idx) -> NoTimeInForceRules_1:
        return super(NoTimeInForceRules_1_List, self).__getitem__(idx)


class NoMatchRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_1_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_1):
    def __getitem__(self, idx) -> NoMatchRules_1:
        return super(NoMatchRules_1_List, self).__getitem__(idx)


class NoOrdTypeRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_2_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_2):
    def __getitem__(self, idx) -> NoOrdTypeRules_2:
        return super(NoOrdTypeRules_2_List, self).__getitem__(idx)


class NoTimeInForceRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_2_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_2):
    def __getitem__(self, idx) -> NoTimeInForceRules_2:
        return super(NoTimeInForceRules_2_List, self).__getitem__(idx)


class NoMatchRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_2_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_2):
    def __getitem__(self, idx) -> NoMatchRules_2:
        return super(NoMatchRules_2_List, self).__getitem__(idx)


class NoTradingSessions_1(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, True),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.MarketID, False),
        fix.Entry(fields.MarketSegmentID, False),
        fix.Entry(fields.TradingSessionDesc, False),
        fix.Entry(fields.TradSesStatus, True),
        fix.Entry(NoOrdTypeRules_2_List, False),
        fix.Entry(NoTimeInForceRules_2_List, False),
        fix.Entry(NoMatchRules_2_List, False),
        fix.Entry(fields.TransactTime, False),
        fix.Entry(fields.Text, False),
        fix.Entry(fields.EncodedTextLen, False),
        fix.Entry(fields.EncodedText, False),
        fix.Entry(fields.SessionSubtype, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str
    MarketID: str
    MarketSegmentID: str
    TradingSessionDesc: str
    TradSesStatus: int
    NoOrdTypeRules: NoOrdTypeRules_2_List
    NoTimeInForceRules: NoTimeInForceRules_2_List
    NoMatchRules: NoMatchRules_2_List
    TransactTime: str
    Text: str
    EncodedTextLen: int
    EncodedText: str
    SessionSubtype: int


class NoTradingSessions_1_List(fix.GroupContainer, CountCls=fields.NoTradingSessions, GroupCls=NoTradingSessions_1):
    def __getitem__(self, idx) -> NoTradingSessions_1:
        return super(NoTradingSessions_1_List, self).__getitem__(idx)


class NoSecurityAltID_4(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_4_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_4):
    def __getitem__(self, idx) -> NoSecurityAltID_4:
        return super(NoSecurityAltID_4_List, self).__getitem__(idx)


class NoEvents_4(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_4_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_4):
    def __getitem__(self, idx) -> NoEvents_4:
        return super(NoEvents_4_List, self).__getitem__(idx)


class NoInstrumentParties_4(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_4_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_4):
    def __getitem__(self, idx) -> NoInstrumentParties_4:
        return super(NoInstrumentParties_4_List, self).__getitem__(idx)


class NoStreams_4(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_4_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_4):
    def __getitem__(self, idx) -> NoStreams_4:
        return super(NoStreams_4_List, self).__getitem__(idx)


class NoInstrAttrib_3(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_3_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_3):
    def __getitem__(self, idx) -> NoInstrAttrib_3:
        return super(NoInstrAttrib_3_List, self).__getitem__(idx)


class NoSecurityClassifications_1(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityClassificationReason, False),
        fix.Entry(fields.SecurityClassificationValue, False),
    ]

    SecurityClassificationReason: int
    SecurityClassificationValue: str


class NoSecurityClassifications_1_List(fix.GroupContainer, CountCls=fields.NoSecurityClassifications, GroupCls=NoSecurityClassifications_1):
    def __getitem__(self, idx) -> NoSecurityClassifications_1:
        return super(NoSecurityClassifications_1_List, self).__getitem__(idx)


class NoTickRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.StartTickPriceRange, False),
        fix.Entry(fields.EndTickPriceRange, False),
        fix.Entry(fields.TickIncrement, False),
    ]

    StartTickPriceRange: float
    EndTickPriceRange: float
    TickIncrement: float


class NoTickRules_1_List(fix.GroupContainer, CountCls=fields.NoTickRules, GroupCls=NoTickRules_1):
    def __getitem__(self, idx) -> NoTickRules_1:
        return super(NoTickRules_1_List, self).__getitem__(idx)


class NoLotTypeRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.MinLotSize, False),
    ]

    LotType: str
    MinLotSize: float


class NoLotTypeRules_1_List(fix.GroupContainer, CountCls=fields.NoLotTypeRules, GroupCls=NoLotTypeRules_1):
    def __getitem__(self, idx) -> NoLotTypeRules_1:
        return super(NoLotTypeRules_1_List, self).__getitem__(idx)


class NoOrdTypeRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_3_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_3):
    def __getitem__(self, idx) -> NoOrdTypeRules_3:
        return super(NoOrdTypeRules_3_List, self).__getitem__(idx)


class NoTimeInForceRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_3_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_3):
    def __getitem__(self, idx) -> NoTimeInForceRules_3:
        return super(NoTimeInForceRules_3_List, self).__getitem__(idx)


class NoMatchRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_3_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_3):
    def __getitem__(self, idx) -> NoMatchRules_3:
        return super(NoMatchRules_3_List, self).__getitem__(idx)


class NoOrdTypeRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_4_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_4):
    def __getitem__(self, idx) -> NoOrdTypeRules_4:
        return super(NoOrdTypeRules_4_List, self).__getitem__(idx)


class NoTimeInForceRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_4_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_4):
    def __getitem__(self, idx) -> NoTimeInForceRules_4:
        return super(NoTimeInForceRules_4_List, self).__getitem__(idx)


class NoMatchRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_4_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_4):
    def __getitem__(self, idx) -> NoMatchRules_4:
        return super(NoMatchRules_4_List, self).__getitem__(idx)


class NoTradingSessionRules_1(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(NoOrdTypeRules_4_List, False),
        fix.Entry(NoTimeInForceRules_4_List, False),
        fix.Entry(NoMatchRules_4_List, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str
    NoOrdTypeRules: NoOrdTypeRules_4_List
    NoTimeInForceRules: NoTimeInForceRules_4_List
    NoMatchRules: NoMatchRules_4_List


class NoTradingSessionRules_1_List(fix.GroupContainer, CountCls=fields.NoTradingSessionRules, GroupCls=NoTradingSessionRules_1):
    def __getitem__(self, idx) -> NoTradingSessionRules_1:
        return super(NoTradingSessionRules_1_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_5(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_5_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_5):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_5:
        return super(NoUnderlyingSecurityAltID_5_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_6(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_6_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_6):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_6:
        return super(NoUnderlyingSecurityAltID_6_List, self).__getitem__(idx)


class NoUnderlyings_3(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_6_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_6_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_3_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_3):
    def __getitem__(self, idx) -> NoUnderlyings_3:
        return super(NoUnderlyings_3_List, self).__getitem__(idx)


class NoLegSecurityAltID_3(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_3_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_3):
    def __getitem__(self, idx) -> NoLegSecurityAltID_3:
        return super(NoLegSecurityAltID_3_List, self).__getitem__(idx)


class NoLegSecurityAltID_4(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_4_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_4):
    def __getitem__(self, idx) -> NoLegSecurityAltID_4:
        return super(NoLegSecurityAltID_4_List, self).__getitem__(idx)


class NoLegs_2(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_4_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_4_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_2_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_2):
    def __getitem__(self, idx) -> NoLegs_2:
        return super(NoLegs_2_List, self).__getitem__(idx)


class NoOfCorpActionDetail_1(fix.Group):
    Entries = [
        fix.Entry(fields.CorpActionID, False),
        fix.Entry(fields.CorpActionCode, False),
        fix.Entry(fields.CorpActionCodeDesc, False),
        fix.Entry(fields.CorpActionDesc, False),
        fix.Entry(fields.CorpActionCodeType, False),
        fix.Entry(fields.CorpActionStartDate, False),
        fix.Entry(fields.CorpActionEndDate, False),
        fix.Entry(fields.CorpActionRecordDate, False),
        fix.Entry(fields.CorpActionStatus, False),
        fix.Entry(fields.CorporateActionExtended, False),
        fix.Entry(fields.CorpActionExDate, False),
        fix.Entry(fields.CorpActionPaymentDate, False),
        fix.Entry(fields.CorpActionValue, False),
    ]

    CorpActionID: int
    CorpActionCode: str
    CorpActionCodeDesc: str
    CorpActionDesc: str
    CorpActionCodeType: str
    CorpActionStartDate: str
    CorpActionEndDate: str
    CorpActionRecordDate: str
    CorpActionStatus: int
    CorporateActionExtended: str
    CorpActionExDate: str
    CorpActionPaymentDate: str
    CorpActionValue: int


class NoOfCorpActionDetail_1_List(fix.GroupContainer, CountCls=fields.NoOfCorpActionDetail, GroupCls=NoOfCorpActionDetail_1):
    def __getitem__(self, idx) -> NoOfCorpActionDetail_1:
        return super(NoOfCorpActionDetail_1_List, self).__getitem__(idx)


class NoSecurityAltID_5(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_5_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_5):
    def __getitem__(self, idx) -> NoSecurityAltID_5:
        return super(NoSecurityAltID_5_List, self).__getitem__(idx)


class NoEvents_5(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_5_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_5):
    def __getitem__(self, idx) -> NoEvents_5:
        return super(NoEvents_5_List, self).__getitem__(idx)


class NoInstrumentParties_5(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_5_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_5):
    def __getitem__(self, idx) -> NoInstrumentParties_5:
        return super(NoInstrumentParties_5_List, self).__getitem__(idx)


class NoStreams_5(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_5_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_5):
    def __getitem__(self, idx) -> NoStreams_5:
        return super(NoStreams_5_List, self).__getitem__(idx)


class NoInstrAttrib_4(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_4_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_4):
    def __getitem__(self, idx) -> NoInstrAttrib_4:
        return super(NoInstrAttrib_4_List, self).__getitem__(idx)


class NoSecurityClassifications_2(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityClassificationReason, False),
        fix.Entry(fields.SecurityClassificationValue, False),
    ]

    SecurityClassificationReason: int
    SecurityClassificationValue: str


class NoSecurityClassifications_2_List(fix.GroupContainer, CountCls=fields.NoSecurityClassifications, GroupCls=NoSecurityClassifications_2):
    def __getitem__(self, idx) -> NoSecurityClassifications_2:
        return super(NoSecurityClassifications_2_List, self).__getitem__(idx)


class NoTickRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.StartTickPriceRange, False),
        fix.Entry(fields.EndTickPriceRange, False),
        fix.Entry(fields.TickIncrement, False),
    ]

    StartTickPriceRange: float
    EndTickPriceRange: float
    TickIncrement: float


class NoTickRules_2_List(fix.GroupContainer, CountCls=fields.NoTickRules, GroupCls=NoTickRules_2):
    def __getitem__(self, idx) -> NoTickRules_2:
        return super(NoTickRules_2_List, self).__getitem__(idx)


class NoLotTypeRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.MinLotSize, False),
    ]

    LotType: str
    MinLotSize: float


class NoLotTypeRules_2_List(fix.GroupContainer, CountCls=fields.NoLotTypeRules, GroupCls=NoLotTypeRules_2):
    def __getitem__(self, idx) -> NoLotTypeRules_2:
        return super(NoLotTypeRules_2_List, self).__getitem__(idx)


class NoOrdTypeRules_5(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_5_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_5):
    def __getitem__(self, idx) -> NoOrdTypeRules_5:
        return super(NoOrdTypeRules_5_List, self).__getitem__(idx)


class NoTimeInForceRules_5(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_5_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_5):
    def __getitem__(self, idx) -> NoTimeInForceRules_5:
        return super(NoTimeInForceRules_5_List, self).__getitem__(idx)


class NoMatchRules_5(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_5_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_5):
    def __getitem__(self, idx) -> NoMatchRules_5:
        return super(NoMatchRules_5_List, self).__getitem__(idx)


class NoOrdTypeRules_6(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_6_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_6):
    def __getitem__(self, idx) -> NoOrdTypeRules_6:
        return super(NoOrdTypeRules_6_List, self).__getitem__(idx)


class NoTimeInForceRules_6(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_6_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_6):
    def __getitem__(self, idx) -> NoTimeInForceRules_6:
        return super(NoTimeInForceRules_6_List, self).__getitem__(idx)


class NoMatchRules_6(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_6_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_6):
    def __getitem__(self, idx) -> NoMatchRules_6:
        return super(NoMatchRules_6_List, self).__getitem__(idx)


class NoTradingSessionRules_2(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(NoOrdTypeRules_6_List, False),
        fix.Entry(NoTimeInForceRules_6_List, False),
        fix.Entry(NoMatchRules_6_List, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str
    NoOrdTypeRules: NoOrdTypeRules_6_List
    NoTimeInForceRules: NoTimeInForceRules_6_List
    NoMatchRules: NoMatchRules_6_List


class NoTradingSessionRules_2_List(fix.GroupContainer, CountCls=fields.NoTradingSessionRules, GroupCls=NoTradingSessionRules_2):
    def __getitem__(self, idx) -> NoTradingSessionRules_2:
        return super(NoTradingSessionRules_2_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_7(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_7_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_7):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_7:
        return super(NoUnderlyingSecurityAltID_7_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_8(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_8_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_8):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_8:
        return super(NoUnderlyingSecurityAltID_8_List, self).__getitem__(idx)


class NoUnderlyings_4(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_8_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_8_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_4_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_4):
    def __getitem__(self, idx) -> NoUnderlyings_4:
        return super(NoUnderlyings_4_List, self).__getitem__(idx)


class NoLegSecurityAltID_5(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_5_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_5):
    def __getitem__(self, idx) -> NoLegSecurityAltID_5:
        return super(NoLegSecurityAltID_5_List, self).__getitem__(idx)


class NoLegSecurityAltID_6(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_6_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_6):
    def __getitem__(self, idx) -> NoLegSecurityAltID_6:
        return super(NoLegSecurityAltID_6_List, self).__getitem__(idx)


class NoLegs_3(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_6_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_6_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_3_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_3):
    def __getitem__(self, idx) -> NoLegs_3:
        return super(NoLegs_3_List, self).__getitem__(idx)


class NoOfCorpActionDetail_2(fix.Group):
    Entries = [
        fix.Entry(fields.CorpActionID, False),
        fix.Entry(fields.CorpActionCode, False),
        fix.Entry(fields.CorpActionCodeDesc, False),
        fix.Entry(fields.CorpActionDesc, False),
        fix.Entry(fields.CorpActionCodeType, False),
        fix.Entry(fields.CorpActionStartDate, False),
        fix.Entry(fields.CorpActionEndDate, False),
        fix.Entry(fields.CorpActionRecordDate, False),
        fix.Entry(fields.CorpActionStatus, False),
        fix.Entry(fields.CorporateActionExtended, False),
        fix.Entry(fields.CorpActionExDate, False),
        fix.Entry(fields.CorpActionPaymentDate, False),
        fix.Entry(fields.CorpActionValue, False),
    ]

    CorpActionID: int
    CorpActionCode: str
    CorpActionCodeDesc: str
    CorpActionDesc: str
    CorpActionCodeType: str
    CorpActionStartDate: str
    CorpActionEndDate: str
    CorpActionRecordDate: str
    CorpActionStatus: int
    CorporateActionExtended: str
    CorpActionExDate: str
    CorpActionPaymentDate: str
    CorpActionValue: int


class NoOfCorpActionDetail_2_List(fix.GroupContainer, CountCls=fields.NoOfCorpActionDetail, GroupCls=NoOfCorpActionDetail_2):
    def __getitem__(self, idx) -> NoOfCorpActionDetail_2:
        return super(NoOfCorpActionDetail_2_List, self).__getitem__(idx)


class NoRelatedSym_2(fix.Group):
    Entries = [
        fix.Entry(fields.ListUpdateAction, False),
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_5_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_5_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_5_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_5_List, False),
        fix.Entry(NoInstrAttrib_4_List, False),
        fix.Entry(NoSecurityClassifications_2_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
        fix.Entry(NoTickRules_2_List, False),
        fix.Entry(NoLotTypeRules_2_List, False),
        fix.Entry(fields.RoundLot, False),
        fix.Entry(NoTradingSessionRules_2_List, False),
        fix.Entry(NoUnderlyings_4_List, False),
        fix.Entry(fields.Currency, False),
        fix.Entry(NoLegs_3_List, False),
        fix.Entry(fields.Text, False),
        fix.Entry(fields.EncodedTextLen, False),
        fix.Entry(fields.EncodedText, False),
        fix.Entry(NoOfCorpActionDetail_2_List, False),
    ]

    ListUpdateAction: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_5_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_5_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_5_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_5_List
    NoInstrAttrib: NoInstrAttrib_4_List
    NoSecurityClassifications: NoSecurityClassifications_2_List
    StartDate: str
    EndDate: str
    NoTickRules: NoTickRules_2_List
    NoLotTypeRules: NoLotTypeRules_2_List
    RoundLot: float
    NoTradingSessionRules: NoTradingSessionRules_2_List
    NoUnderlyings: NoUnderlyings_4_List
    Currency: str
    NoLegs: NoLegs_3_List
    Text: str
    EncodedTextLen: int
    EncodedText: str
    NoOfCorpActionDetail: NoOfCorpActionDetail_2_List


class NoRelatedSym_2_List(fix.GroupContainer, CountCls=fields.NoRelatedSym, GroupCls=NoRelatedSym_2):
    def __getitem__(self, idx) -> NoRelatedSym_2:
        return super(NoRelatedSym_2_List, self).__getitem__(idx)


class NoInstrumentScopeSecurityAltID_1(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentScopeSecurityAltID, False),
        fix.Entry(fields.InstrumentScopeSecurityAltIDSource, False),
    ]

    InstrumentScopeSecurityAltID: str
    InstrumentScopeSecurityAltIDSource: str


class NoInstrumentScopeSecurityAltID_1_List(fix.GroupContainer, CountCls=fields.NoInstrumentScopeSecurityAltID, GroupCls=NoInstrumentScopeSecurityAltID_1):
    def __getitem__(self, idx) -> NoInstrumentScopeSecurityAltID_1:
        return super(NoInstrumentScopeSecurityAltID_1_List, self).__getitem__(idx)


class NoInstrumentScopeSecurityAltID_2(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentScopeSecurityAltID, False),
        fix.Entry(fields.InstrumentScopeSecurityAltIDSource, False),
    ]

    InstrumentScopeSecurityAltID: str
    InstrumentScopeSecurityAltIDSource: str


class NoInstrumentScopeSecurityAltID_2_List(fix.GroupContainer, CountCls=fields.NoInstrumentScopeSecurityAltID, GroupCls=NoInstrumentScopeSecurityAltID_2):
    def __getitem__(self, idx) -> NoInstrumentScopeSecurityAltID_2:
        return super(NoInstrumentScopeSecurityAltID_2_List, self).__getitem__(idx)


class NoInstrumentScopes_1(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentScopeOperator, False),
        fix.Entry(fields.InstrumentScopeSecurityID, False),
        fix.Entry(fields.InstrumentScopeSecurityIDSource, False),
        fix.Entry(NoInstrumentScopeSecurityAltID_2_List, False),
        fix.Entry(fields.InstrumentScopeSecurityDesc, False),
    ]

    InstrumentScopeOperator: int
    InstrumentScopeSecurityID: str
    InstrumentScopeSecurityIDSource: str
    NoInstrumentScopeSecurityAltID: NoInstrumentScopeSecurityAltID_2_List
    InstrumentScopeSecurityDesc: str


class NoInstrumentScopes_1_List(fix.GroupContainer, CountCls=fields.NoInstrumentScopes, GroupCls=NoInstrumentScopes_1):
    def __getitem__(self, idx) -> NoInstrumentScopes_1:
        return super(NoInstrumentScopes_1_List, self).__getitem__(idx)


class NoTickRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.StartTickPriceRange, False),
        fix.Entry(fields.EndTickPriceRange, False),
        fix.Entry(fields.TickIncrement, False),
    ]

    StartTickPriceRange: float
    EndTickPriceRange: float
    TickIncrement: float


class NoTickRules_3_List(fix.GroupContainer, CountCls=fields.NoTickRules, GroupCls=NoTickRules_3):
    def __getitem__(self, idx) -> NoTickRules_3:
        return super(NoTickRules_3_List, self).__getitem__(idx)


class NoLotTypeRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.MinLotSize, False),
    ]

    LotType: str
    MinLotSize: float


class NoLotTypeRules_3_List(fix.GroupContainer, CountCls=fields.NoLotTypeRules, GroupCls=NoLotTypeRules_3):
    def __getitem__(self, idx) -> NoLotTypeRules_3:
        return super(NoLotTypeRules_3_List, self).__getitem__(idx)


class NoOrdTypeRules_7(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_7_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_7):
    def __getitem__(self, idx) -> NoOrdTypeRules_7:
        return super(NoOrdTypeRules_7_List, self).__getitem__(idx)


class NoTimeInForceRules_7(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_7_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_7):
    def __getitem__(self, idx) -> NoTimeInForceRules_7:
        return super(NoTimeInForceRules_7_List, self).__getitem__(idx)


class NoMatchRules_7(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_7_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_7):
    def __getitem__(self, idx) -> NoMatchRules_7:
        return super(NoMatchRules_7_List, self).__getitem__(idx)


class NoPartySubIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_1_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_1):
    def __getitem__(self, idx) -> NoPartySubIDs_1:
        return super(NoPartySubIDs_1_List, self).__getitem__(idx)


class NoPartySubIDs_2(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_2_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_2):
    def __getitem__(self, idx) -> NoPartySubIDs_2:
        return super(NoPartySubIDs_2_List, self).__getitem__(idx)


class NoPartyIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_2_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_2_List


class NoPartyIDs_1_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_1):
    def __getitem__(self, idx) -> NoPartyIDs_1:
        return super(NoPartyIDs_1_List, self).__getitem__(idx)


class NoPartySubIDs_3(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_3_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_3):
    def __getitem__(self, idx) -> NoPartySubIDs_3:
        return super(NoPartySubIDs_3_List, self).__getitem__(idx)


class NoPartySubIDs_4(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_4_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_4):
    def __getitem__(self, idx) -> NoPartySubIDs_4:
        return super(NoPartySubIDs_4_List, self).__getitem__(idx)


class NoPartyIDs_2(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_4_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_4_List


class NoPartyIDs_2_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_2):
    def __getitem__(self, idx) -> NoPartyIDs_2:
        return super(NoPartyIDs_2_List, self).__getitem__(idx)


class NoSecurityAltID_6(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_6_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_6):
    def __getitem__(self, idx) -> NoSecurityAltID_6:
        return super(NoSecurityAltID_6_List, self).__getitem__(idx)


class NoEvents_6(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_6_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_6):
    def __getitem__(self, idx) -> NoEvents_6:
        return super(NoEvents_6_List, self).__getitem__(idx)


class NoInstrumentParties_6(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_6_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_6):
    def __getitem__(self, idx) -> NoInstrumentParties_6:
        return super(NoInstrumentParties_6_List, self).__getitem__(idx)


class NoStreams_6(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_6_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_6):
    def __getitem__(self, idx) -> NoStreams_6:
        return super(NoStreams_6_List, self).__getitem__(idx)


class NoInstrAttrib_5(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_5_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_5):
    def __getitem__(self, idx) -> NoInstrAttrib_5:
        return super(NoInstrAttrib_5_List, self).__getitem__(idx)


class NoRegulatoryTradeIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.RegulatoryTradeID, False),
        fix.Entry(fields.RegulatoryTradeIDType, False),
    ]

    RegulatoryTradeID: str
    RegulatoryTradeIDType: int


class NoRegulatoryTradeIDs_1_List(fix.GroupContainer, CountCls=fields.NoRegulatoryTradeIDs, GroupCls=NoRegulatoryTradeIDs_1):
    def __getitem__(self, idx) -> NoRegulatoryTradeIDs_1:
        return super(NoRegulatoryTradeIDs_1_List, self).__getitem__(idx)


class NoRootPartySubIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_1_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_1):
    def __getitem__(self, idx) -> NoRootPartySubIDs_1:
        return super(NoRootPartySubIDs_1_List, self).__getitem__(idx)


class NoRootPartySubIDs_2(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_2_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_2):
    def __getitem__(self, idx) -> NoRootPartySubIDs_2:
        return super(NoRootPartySubIDs_2_List, self).__getitem__(idx)


class NoRootPartyIDs_1(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartyID, False),
        fix.Entry(fields.RootPartyIDSource, False),
        fix.Entry(fields.RootPartyRole, False),
        fix.Entry(NoRootPartySubIDs_2_List, False),
        fix.Entry(fields.PartyRoleQualifier, False),
    ]

    RootPartyID: str
    RootPartyIDSource: str
    RootPartyRole: int
    NoRootPartySubIDs: NoRootPartySubIDs_2_List
    PartyRoleQualifier: int


class NoRootPartyIDs_1_List(fix.GroupContainer, CountCls=fields.NoRootPartyIDs, GroupCls=NoRootPartyIDs_1):
    def __getitem__(self, idx) -> NoRootPartyIDs_1:
        return super(NoRootPartyIDs_1_List, self).__getitem__(idx)


class NoSecurityAltID_7(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_7_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_7):
    def __getitem__(self, idx) -> NoSecurityAltID_7:
        return super(NoSecurityAltID_7_List, self).__getitem__(idx)


class NoEvents_7(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_7_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_7):
    def __getitem__(self, idx) -> NoEvents_7:
        return super(NoEvents_7_List, self).__getitem__(idx)


class NoInstrumentParties_7(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_7_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_7):
    def __getitem__(self, idx) -> NoInstrumentParties_7:
        return super(NoInstrumentParties_7_List, self).__getitem__(idx)


class NoStreams_7(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_7_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_7):
    def __getitem__(self, idx) -> NoStreams_7:
        return super(NoStreams_7_List, self).__getitem__(idx)


class NoInstrAttrib_6(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_6_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_6):
    def __getitem__(self, idx) -> NoInstrAttrib_6:
        return super(NoInstrAttrib_6_List, self).__getitem__(idx)


class NoLegSecurityAltID_7(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_7_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_7):
    def __getitem__(self, idx) -> NoLegSecurityAltID_7:
        return super(NoLegSecurityAltID_7_List, self).__getitem__(idx)


class NoLegSecurityAltID_8(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_8_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_8):
    def __getitem__(self, idx) -> NoLegSecurityAltID_8:
        return super(NoLegSecurityAltID_8_List, self).__getitem__(idx)


class NoLegs_4(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_8_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
        fix.Entry(fields.LegLastPx, False),
        fix.Entry(fields.LegLastQty, False),
        fix.Entry(fields.TransBkdTime, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_8_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str
    LegLastPx: float
    LegLastQty: float
    TransBkdTime: str


class NoLegs_4_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_4):
    def __getitem__(self, idx) -> NoLegs_4:
        return super(NoLegs_4_List, self).__getitem__(idx)


class NoTrdRegTimestamps_1(fix.Group):
    Entries = [
        fix.Entry(fields.TrdRegTimestamp, False),
        fix.Entry(fields.TrdRegTimestampType, False),
        fix.Entry(fields.DeskOrderHandlingInst, False),
        fix.Entry(fields.NBBOPrice, False),
        fix.Entry(fields.NBBOQty, False),
        fix.Entry(fields.NBBOSource, False),
        fix.Entry(fields.NBBOEntryType, False),
    ]

    TrdRegTimestamp: str
    TrdRegTimestampType: int
    DeskOrderHandlingInst: str
    NBBOPrice: float
    NBBOQty: float
    NBBOSource: int
    NBBOEntryType: int


class NoTrdRegTimestamps_1_List(fix.GroupContainer, CountCls=fields.NoTrdRegTimestamps, GroupCls=NoTrdRegTimestamps_1):
    def __getitem__(self, idx) -> NoTrdRegTimestamps_1:
        return super(NoTrdRegTimestamps_1_List, self).__getitem__(idx)


class NoPartySubIDs_5(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_5_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_5):
    def __getitem__(self, idx) -> NoPartySubIDs_5:
        return super(NoPartySubIDs_5_List, self).__getitem__(idx)


class NoPartySubIDs_6(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_6_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_6):
    def __getitem__(self, idx) -> NoPartySubIDs_6:
        return super(NoPartySubIDs_6_List, self).__getitem__(idx)


class NoPartyIDs_3(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_6_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_6_List


class NoPartyIDs_3_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_3):
    def __getitem__(self, idx) -> NoPartyIDs_3:
        return super(NoPartyIDs_3_List, self).__getitem__(idx)


class NoOrderAttributes_1(fix.Group):
    Entries = [
        fix.Entry(fields.OrderAttributeType, False),
        fix.Entry(fields.OrderAttributeValue, False),
    ]

    OrderAttributeType: int
    OrderAttributeValue: str


class NoOrderAttributes_1_List(fix.GroupContainer, CountCls=fields.NoOrderAttributes, GroupCls=NoOrderAttributes_1):
    def __getitem__(self, idx) -> NoOrderAttributes_1:
        return super(NoOrderAttributes_1_List, self).__getitem__(idx)


class NoRelatedTrades_1(fix.Group):
    Entries = [
        fix.Entry(fields.RelatedTradeID, False),
        fix.Entry(fields.RelatedTradeIDSource, False),
    ]

    RelatedTradeID: str
    RelatedTradeIDSource: int


class NoRelatedTrades_1_List(fix.GroupContainer, CountCls=fields.NoRelatedTrades, GroupCls=NoRelatedTrades_1):
    def __getitem__(self, idx) -> NoRelatedTrades_1:
        return super(NoRelatedTrades_1_List, self).__getitem__(idx)


class NoPartySubIDs_7(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_7_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_7):
    def __getitem__(self, idx) -> NoPartySubIDs_7:
        return super(NoPartySubIDs_7_List, self).__getitem__(idx)


class NoPartySubIDs_8(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_8_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_8):
    def __getitem__(self, idx) -> NoPartySubIDs_8:
        return super(NoPartySubIDs_8_List, self).__getitem__(idx)


class NoPartyIDs_4(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_8_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_8_List


class NoPartyIDs_4_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_4):
    def __getitem__(self, idx) -> NoPartyIDs_4:
        return super(NoPartyIDs_4_List, self).__getitem__(idx)


class NoOrderAttributes_2(fix.Group):
    Entries = [
        fix.Entry(fields.OrderAttributeType, False),
        fix.Entry(fields.OrderAttributeValue, False),
    ]

    OrderAttributeType: int
    OrderAttributeValue: str


class NoOrderAttributes_2_List(fix.GroupContainer, CountCls=fields.NoOrderAttributes, GroupCls=NoOrderAttributes_2):
    def __getitem__(self, idx) -> NoOrderAttributes_2:
        return super(NoOrderAttributes_2_List, self).__getitem__(idx)


class NoRelatedTrades_2(fix.Group):
    Entries = [
        fix.Entry(fields.RelatedTradeID, False),
        fix.Entry(fields.RelatedTradeIDSource, False),
    ]

    RelatedTradeID: str
    RelatedTradeIDSource: int


class NoRelatedTrades_2_List(fix.GroupContainer, CountCls=fields.NoRelatedTrades, GroupCls=NoRelatedTrades_2):
    def __getitem__(self, idx) -> NoRelatedTrades_2:
        return super(NoRelatedTrades_2_List, self).__getitem__(idx)


class NoSides_1(fix.Group):
    Entries = [
        fix.Entry(fields.Side, True),
        fix.Entry(NoPartyIDs_4_List, False),
        fix.Entry(NoOrderAttributes_2_List, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.StartCash, False),
        fix.Entry(fields.EndCash, False),
        fix.Entry(fields.PositionEffect, False),
        fix.Entry(fields.Text, False),
        fix.Entry(fields.AggressorIndicator, False),
        fix.Entry(fields.OrderCategory, False),
        fix.Entry(fields.StrategyLinkID, False),
        fix.Entry(fields.OrderID, False),
        fix.Entry(fields.SecondaryOrderID, False),
        fix.Entry(fields.ClOrdID, False),
        fix.Entry(fields.SecondaryClOrdID, False),
        fix.Entry(fields.PreTradeAnonymity, False),
        fix.Entry(fields.OrderQty, False),
        fix.Entry(fields.ExposureDuration, False),
        fix.Entry(fields.InitialDisplayQty, False),
        fix.Entry(fields.DisplayMethod, False),
        fix.Entry(fields.RefreshQty, False),
        fix.Entry(fields.OrderCapacity, False),
        fix.Entry(fields.OrderRestrictions, False),
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.TransBkdTime, False),
        fix.Entry(fields.CustOrderHandlingInst, False),
        fix.Entry(NoRelatedTrades_2_List, False),
        fix.Entry(fields.OrderOrigination, False),
    ]

    Side: str
    NoPartyIDs: NoPartyIDs_4_List
    NoOrderAttributes: NoOrderAttributes_2_List
    TradingSessionSubID: str
    StartCash: float
    EndCash: float
    PositionEffect: str
    Text: str
    AggressorIndicator: bool
    OrderCategory: str
    StrategyLinkID: str
    OrderID: str
    SecondaryOrderID: str
    ClOrdID: str
    SecondaryClOrdID: str
    PreTradeAnonymity: bool
    OrderQty: float
    ExposureDuration: int
    InitialDisplayQty: float
    DisplayMethod: str
    RefreshQty: float
    OrderCapacity: str
    OrderRestrictions: str
    LotType: str
    TransBkdTime: str
    CustOrderHandlingInst: str
    NoRelatedTrades: NoRelatedTrades_2_List
    OrderOrigination: int


class NoSides_1_List(fix.GroupContainer, CountCls=fields.NoSides, GroupCls=NoSides_1):
    def __getitem__(self, idx) -> NoSides_1:
        return super(NoSides_1_List, self).__getitem__(idx)


class NoPartySubIDs_9(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_9_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_9):
    def __getitem__(self, idx) -> NoPartySubIDs_9:
        return super(NoPartySubIDs_9_List, self).__getitem__(idx)


class NoPartySubIDs_10(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_10_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_10):
    def __getitem__(self, idx) -> NoPartySubIDs_10:
        return super(NoPartySubIDs_10_List, self).__getitem__(idx)


class NoPartyIDs_5(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_10_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_10_List


class NoPartyIDs_5_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_5):
    def __getitem__(self, idx) -> NoPartyIDs_5:
        return super(NoPartyIDs_5_List, self).__getitem__(idx)


class NoSecurityAltID_8(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_8_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_8):
    def __getitem__(self, idx) -> NoSecurityAltID_8:
        return super(NoSecurityAltID_8_List, self).__getitem__(idx)


class NoEvents_8(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_8_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_8):
    def __getitem__(self, idx) -> NoEvents_8:
        return super(NoEvents_8_List, self).__getitem__(idx)


class NoInstrumentParties_8(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_8_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_8):
    def __getitem__(self, idx) -> NoInstrumentParties_8:
        return super(NoInstrumentParties_8_List, self).__getitem__(idx)


class NoStreams_8(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_8_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_8):
    def __getitem__(self, idx) -> NoStreams_8:
        return super(NoStreams_8_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_9(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_9_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_9):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_9:
        return super(NoUnderlyingSecurityAltID_9_List, self).__getitem__(idx)


class NoSecurityAltID_9(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_9_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_9):
    def __getitem__(self, idx) -> NoSecurityAltID_9:
        return super(NoSecurityAltID_9_List, self).__getitem__(idx)


class NoEvents_9(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_9_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_9):
    def __getitem__(self, idx) -> NoEvents_9:
        return super(NoEvents_9_List, self).__getitem__(idx)


class NoInstrumentParties_9(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_9_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_9):
    def __getitem__(self, idx) -> NoInstrumentParties_9:
        return super(NoInstrumentParties_9_List, self).__getitem__(idx)


class NoStreams_9(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_9_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_9):
    def __getitem__(self, idx) -> NoStreams_9:
        return super(NoStreams_9_List, self).__getitem__(idx)


class NoInstrAttrib_7(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_7_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_7):
    def __getitem__(self, idx) -> NoInstrAttrib_7:
        return super(NoInstrAttrib_7_List, self).__getitem__(idx)


class NoRootPartySubIDs_3(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_3_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_3):
    def __getitem__(self, idx) -> NoRootPartySubIDs_3:
        return super(NoRootPartySubIDs_3_List, self).__getitem__(idx)


class NoInstrumentParties_10(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_10_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_10):
    def __getitem__(self, idx) -> NoInstrumentParties_10:
        return super(NoInstrumentParties_10_List, self).__getitem__(idx)


class NoStreams_10(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_10_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_10):
    def __getitem__(self, idx) -> NoStreams_10:
        return super(NoStreams_10_List, self).__getitem__(idx)


class NoInstrAttrib_8(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_8_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_8):
    def __getitem__(self, idx) -> NoInstrAttrib_8:
        return super(NoInstrAttrib_8_List, self).__getitem__(idx)


class NoTrdRegTimestamps_2(fix.Group):
    Entries = [
        fix.Entry(fields.TrdRegTimestamp, False),
        fix.Entry(fields.TrdRegTimestampType, False),
        fix.Entry(fields.DeskOrderHandlingInst, False),
        fix.Entry(fields.NBBOPrice, False),
        fix.Entry(fields.NBBOQty, False),
        fix.Entry(fields.NBBOSource, False),
        fix.Entry(fields.NBBOEntryType, False),
    ]

    TrdRegTimestamp: str
    TrdRegTimestampType: int
    DeskOrderHandlingInst: str
    NBBOPrice: float
    NBBOQty: float
    NBBOSource: int
    NBBOEntryType: int


class NoTrdRegTimestamps_2_List(fix.GroupContainer, CountCls=fields.NoTrdRegTimestamps, GroupCls=NoTrdRegTimestamps_2):
    def __getitem__(self, idx) -> NoTrdRegTimestamps_2:
        return super(NoTrdRegTimestamps_2_List, self).__getitem__(idx)


class NoPartySubIDs_11(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_11_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_11):
    def __getitem__(self, idx) -> NoPartySubIDs_11:
        return super(NoPartySubIDs_11_List, self).__getitem__(idx)


class NoPartySubIDs_12(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_12_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_12):
    def __getitem__(self, idx) -> NoPartySubIDs_12:
        return super(NoPartySubIDs_12_List, self).__getitem__(idx)


class NoPartyIDs_6(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_12_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_12_List


class NoPartyIDs_6_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_6):
    def __getitem__(self, idx) -> NoPartyIDs_6:
        return super(NoPartyIDs_6_List, self).__getitem__(idx)


class NoRelatedTrades_3(fix.Group):
    Entries = [
        fix.Entry(fields.RelatedTradeID, False),
        fix.Entry(fields.RelatedTradeIDSource, False),
    ]

    RelatedTradeID: str
    RelatedTradeIDSource: int


class NoRelatedTrades_3_List(fix.GroupContainer, CountCls=fields.NoRelatedTrades, GroupCls=NoRelatedTrades_3):
    def __getitem__(self, idx) -> NoRelatedTrades_3:
        return super(NoRelatedTrades_3_List, self).__getitem__(idx)


class NoPartySubIDs_13(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_13_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_13):
    def __getitem__(self, idx) -> NoPartySubIDs_13:
        return super(NoPartySubIDs_13_List, self).__getitem__(idx)


class NoPartySubIDs_14(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_14_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_14):
    def __getitem__(self, idx) -> NoPartySubIDs_14:
        return super(NoPartySubIDs_14_List, self).__getitem__(idx)


class NoPartyIDs_7(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_14_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_14_List


class NoPartyIDs_7_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_7):
    def __getitem__(self, idx) -> NoPartyIDs_7:
        return super(NoPartyIDs_7_List, self).__getitem__(idx)


class NoRelatedTrades_4(fix.Group):
    Entries = [
        fix.Entry(fields.RelatedTradeID, False),
        fix.Entry(fields.RelatedTradeIDSource, False),
    ]

    RelatedTradeID: str
    RelatedTradeIDSource: int


class NoRelatedTrades_4_List(fix.GroupContainer, CountCls=fields.NoRelatedTrades, GroupCls=NoRelatedTrades_4):
    def __getitem__(self, idx) -> NoRelatedTrades_4:
        return super(NoRelatedTrades_4_List, self).__getitem__(idx)


class NoSides_2(fix.Group):
    Entries = [
        fix.Entry(fields.Side, True),
        fix.Entry(NoPartyIDs_7_List, False),
        fix.Entry(fields.Account, False),
        fix.Entry(fields.CustOrderCapacity, False),
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.StartCash, False),
        fix.Entry(fields.EndCash, False),
        fix.Entry(fields.PositionEffect, False),
        fix.Entry(fields.AggressorIndicator, False),
        fix.Entry(fields.OrderCategory, False),
        fix.Entry(fields.StrategyLinkID, False),
        fix.Entry(fields.OrderID, False),
        fix.Entry(fields.SecondaryOrderID, False),
        fix.Entry(fields.ClOrdID, False),
        fix.Entry(fields.SecondaryClOrdID, False),
        fix.Entry(fields.PreTradeAnonymity, False),
        fix.Entry(fields.OrdType, False),
        fix.Entry(fields.Price, False),
        fix.Entry(fields.ExecInst, False),
        fix.Entry(fields.OrdStatus, False),
        fix.Entry(fields.OrderQty, False),
        fix.Entry(fields.LeavesQty, False),
        fix.Entry(fields.CumQty, False),
        fix.Entry(fields.TimeInForce, False),
        fix.Entry(fields.ExposureDuration, False),
        fix.Entry(fields.DisplayQty, False),
        fix.Entry(fields.InitialDisplayQty, False),
        fix.Entry(fields.DisplayMethod, False),
        fix.Entry(fields.RefreshQty, False),
        fix.Entry(fields.OrderCapacity, False),
        fix.Entry(fields.OrderRestrictions, False),
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.TransBkdTime, False),
        fix.Entry(fields.CustOrderHandlingInst, False),
        fix.Entry(NoRelatedTrades_4_List, False),
    ]

    Side: str
    NoPartyIDs: NoPartyIDs_7_List
    Account: str
    CustOrderCapacity: int
    TradingSessionID: str
    TradingSessionSubID: str
    StartCash: float
    EndCash: float
    PositionEffect: str
    AggressorIndicator: bool
    OrderCategory: str
    StrategyLinkID: str
    OrderID: str
    SecondaryOrderID: str
    ClOrdID: str
    SecondaryClOrdID: str
    PreTradeAnonymity: bool
    OrdType: str
    Price: float
    ExecInst: str
    OrdStatus: str
    OrderQty: float
    LeavesQty: float
    CumQty: float
    TimeInForce: str
    ExposureDuration: int
    DisplayQty: float
    InitialDisplayQty: float
    DisplayMethod: str
    RefreshQty: float
    OrderCapacity: str
    OrderRestrictions: str
    LotType: str
    TransBkdTime: str
    CustOrderHandlingInst: str
    NoRelatedTrades: NoRelatedTrades_4_List


class NoSides_2_List(fix.GroupContainer, CountCls=fields.NoSides, GroupCls=NoSides_2):
    def __getitem__(self, idx) -> NoSides_2:
        return super(NoSides_2_List, self).__getitem__(idx)


class NoSecurityAltID_10(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_10_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_10):
    def __getitem__(self, idx) -> NoSecurityAltID_10:
        return super(NoSecurityAltID_10_List, self).__getitem__(idx)


class NoEvents_10(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_10_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_10):
    def __getitem__(self, idx) -> NoEvents_10:
        return super(NoEvents_10_List, self).__getitem__(idx)


class NoInstrumentParties_11(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_11_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_11):
    def __getitem__(self, idx) -> NoInstrumentParties_11:
        return super(NoInstrumentParties_11_List, self).__getitem__(idx)


class NoStreams_11(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_11_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_11):
    def __getitem__(self, idx) -> NoStreams_11:
        return super(NoStreams_11_List, self).__getitem__(idx)


class NoInstrAttrib_9(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_9_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_9):
    def __getitem__(self, idx) -> NoInstrAttrib_9:
        return super(NoInstrAttrib_9_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_10(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_10_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_10):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_10:
        return super(NoUnderlyingSecurityAltID_10_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_11(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_11_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_11):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_11:
        return super(NoUnderlyingSecurityAltID_11_List, self).__getitem__(idx)


class NoUnderlyings_5(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_11_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_11_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_5_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_5):
    def __getitem__(self, idx) -> NoUnderlyings_5:
        return super(NoUnderlyings_5_List, self).__getitem__(idx)


class NoLegSecurityAltID_9(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_9_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_9):
    def __getitem__(self, idx) -> NoLegSecurityAltID_9:
        return super(NoLegSecurityAltID_9_List, self).__getitem__(idx)


class NoLegSecurityAltID_10(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_10_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_10):
    def __getitem__(self, idx) -> NoLegSecurityAltID_10:
        return super(NoLegSecurityAltID_10_List, self).__getitem__(idx)


class NoLegs_5(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_10_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_10_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_5_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_5):
    def __getitem__(self, idx) -> NoLegs_5:
        return super(NoLegs_5_List, self).__getitem__(idx)


class NoSecurityAltID_11(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_11_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_11):
    def __getitem__(self, idx) -> NoSecurityAltID_11:
        return super(NoSecurityAltID_11_List, self).__getitem__(idx)


class NoEvents_11(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_11_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_11):
    def __getitem__(self, idx) -> NoEvents_11:
        return super(NoEvents_11_List, self).__getitem__(idx)


class NoInstrumentParties_12(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_12_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_12):
    def __getitem__(self, idx) -> NoInstrumentParties_12:
        return super(NoInstrumentParties_12_List, self).__getitem__(idx)


class NoStreams_12(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_12_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_12):
    def __getitem__(self, idx) -> NoStreams_12:
        return super(NoStreams_12_List, self).__getitem__(idx)


class NoInstrAttrib_10(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_10_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_10):
    def __getitem__(self, idx) -> NoInstrAttrib_10:
        return super(NoInstrAttrib_10_List, self).__getitem__(idx)


class NoSecurityClassifications_3(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityClassificationReason, False),
        fix.Entry(fields.SecurityClassificationValue, False),
    ]

    SecurityClassificationReason: int
    SecurityClassificationValue: str


class NoSecurityClassifications_3_List(fix.GroupContainer, CountCls=fields.NoSecurityClassifications, GroupCls=NoSecurityClassifications_3):
    def __getitem__(self, idx) -> NoSecurityClassifications_3:
        return super(NoSecurityClassifications_3_List, self).__getitem__(idx)


class NoTickRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.StartTickPriceRange, False),
        fix.Entry(fields.EndTickPriceRange, False),
        fix.Entry(fields.TickIncrement, False),
    ]

    StartTickPriceRange: float
    EndTickPriceRange: float
    TickIncrement: float


class NoTickRules_4_List(fix.GroupContainer, CountCls=fields.NoTickRules, GroupCls=NoTickRules_4):
    def __getitem__(self, idx) -> NoTickRules_4:
        return super(NoTickRules_4_List, self).__getitem__(idx)


class NoLotTypeRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.MinLotSize, False),
    ]

    LotType: str
    MinLotSize: float


class NoLotTypeRules_4_List(fix.GroupContainer, CountCls=fields.NoLotTypeRules, GroupCls=NoLotTypeRules_4):
    def __getitem__(self, idx) -> NoLotTypeRules_4:
        return super(NoLotTypeRules_4_List, self).__getitem__(idx)


class NoOrdTypeRules_8(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_8_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_8):
    def __getitem__(self, idx) -> NoOrdTypeRules_8:
        return super(NoOrdTypeRules_8_List, self).__getitem__(idx)


class NoTimeInForceRules_8(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_8_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_8):
    def __getitem__(self, idx) -> NoTimeInForceRules_8:
        return super(NoTimeInForceRules_8_List, self).__getitem__(idx)


class NoMatchRules_8(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_8_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_8):
    def __getitem__(self, idx) -> NoMatchRules_8:
        return super(NoMatchRules_8_List, self).__getitem__(idx)


class NoOrdTypeRules_9(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_9_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_9):
    def __getitem__(self, idx) -> NoOrdTypeRules_9:
        return super(NoOrdTypeRules_9_List, self).__getitem__(idx)


class NoTimeInForceRules_9(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_9_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_9):
    def __getitem__(self, idx) -> NoTimeInForceRules_9:
        return super(NoTimeInForceRules_9_List, self).__getitem__(idx)


class NoMatchRules_9(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_9_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_9):
    def __getitem__(self, idx) -> NoMatchRules_9:
        return super(NoMatchRules_9_List, self).__getitem__(idx)


class NoTradingSessionRules_3(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(NoOrdTypeRules_9_List, False),
        fix.Entry(NoTimeInForceRules_9_List, False),
        fix.Entry(NoMatchRules_9_List, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str
    NoOrdTypeRules: NoOrdTypeRules_9_List
    NoTimeInForceRules: NoTimeInForceRules_9_List
    NoMatchRules: NoMatchRules_9_List


class NoTradingSessionRules_3_List(fix.GroupContainer, CountCls=fields.NoTradingSessionRules, GroupCls=NoTradingSessionRules_3):
    def __getitem__(self, idx) -> NoTradingSessionRules_3:
        return super(NoTradingSessionRules_3_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_12(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_12_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_12):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_12:
        return super(NoUnderlyingSecurityAltID_12_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_13(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_13_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_13):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_13:
        return super(NoUnderlyingSecurityAltID_13_List, self).__getitem__(idx)


class NoUnderlyings_6(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_13_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_13_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_6_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_6):
    def __getitem__(self, idx) -> NoUnderlyings_6:
        return super(NoUnderlyings_6_List, self).__getitem__(idx)


class NoLegSecurityAltID_11(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_11_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_11):
    def __getitem__(self, idx) -> NoLegSecurityAltID_11:
        return super(NoLegSecurityAltID_11_List, self).__getitem__(idx)


class NoLegSecurityAltID_12(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_12_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_12):
    def __getitem__(self, idx) -> NoLegSecurityAltID_12:
        return super(NoLegSecurityAltID_12_List, self).__getitem__(idx)


class NoLegs_6(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_12_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_12_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_6_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_6):
    def __getitem__(self, idx) -> NoLegs_6:
        return super(NoLegs_6_List, self).__getitem__(idx)


class NoOfCorpActionDetail_3(fix.Group):
    Entries = [
        fix.Entry(fields.CorpActionID, False),
        fix.Entry(fields.CorpActionCode, False),
        fix.Entry(fields.CorpActionCodeDesc, False),
        fix.Entry(fields.CorpActionDesc, False),
        fix.Entry(fields.CorpActionCodeType, False),
        fix.Entry(fields.CorpActionStartDate, False),
        fix.Entry(fields.CorpActionEndDate, False),
        fix.Entry(fields.CorpActionRecordDate, False),
        fix.Entry(fields.CorpActionStatus, False),
        fix.Entry(fields.CorporateActionExtended, False),
        fix.Entry(fields.CorpActionExDate, False),
        fix.Entry(fields.CorpActionPaymentDate, False),
        fix.Entry(fields.CorpActionValue, False),
    ]

    CorpActionID: int
    CorpActionCode: str
    CorpActionCodeDesc: str
    CorpActionDesc: str
    CorpActionCodeType: str
    CorpActionStartDate: str
    CorpActionEndDate: str
    CorpActionRecordDate: str
    CorpActionStatus: int
    CorporateActionExtended: str
    CorpActionExDate: str
    CorpActionPaymentDate: str
    CorpActionValue: int


class NoOfCorpActionDetail_3_List(fix.GroupContainer, CountCls=fields.NoOfCorpActionDetail, GroupCls=NoOfCorpActionDetail_3):
    def __getitem__(self, idx) -> NoOfCorpActionDetail_3:
        return super(NoOfCorpActionDetail_3_List, self).__getitem__(idx)


class NoSecurityAltID_12(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_12_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_12):
    def __getitem__(self, idx) -> NoSecurityAltID_12:
        return super(NoSecurityAltID_12_List, self).__getitem__(idx)


class NoEvents_12(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_12_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_12):
    def __getitem__(self, idx) -> NoEvents_12:
        return super(NoEvents_12_List, self).__getitem__(idx)


class NoInstrumentParties_13(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_13_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_13):
    def __getitem__(self, idx) -> NoInstrumentParties_13:
        return super(NoInstrumentParties_13_List, self).__getitem__(idx)


class NoStreams_13(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_13_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_13):
    def __getitem__(self, idx) -> NoStreams_13:
        return super(NoStreams_13_List, self).__getitem__(idx)


class NoInstrAttrib_11(fix.Group):
    Entries = [
        fix.Entry(fields.InstrAttribType, False),
        fix.Entry(fields.InstrAttribValue, False),
    ]

    InstrAttribType: int
    InstrAttribValue: str


class NoInstrAttrib_11_List(fix.GroupContainer, CountCls=fields.NoInstrAttrib, GroupCls=NoInstrAttrib_11):
    def __getitem__(self, idx) -> NoInstrAttrib_11:
        return super(NoInstrAttrib_11_List, self).__getitem__(idx)


class NoSecurityClassifications_4(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityClassificationReason, False),
        fix.Entry(fields.SecurityClassificationValue, False),
    ]

    SecurityClassificationReason: int
    SecurityClassificationValue: str


class NoSecurityClassifications_4_List(fix.GroupContainer, CountCls=fields.NoSecurityClassifications, GroupCls=NoSecurityClassifications_4):
    def __getitem__(self, idx) -> NoSecurityClassifications_4:
        return super(NoSecurityClassifications_4_List, self).__getitem__(idx)


class NoTickRules_5(fix.Group):
    Entries = [
        fix.Entry(fields.StartTickPriceRange, False),
        fix.Entry(fields.EndTickPriceRange, False),
        fix.Entry(fields.TickIncrement, False),
    ]

    StartTickPriceRange: float
    EndTickPriceRange: float
    TickIncrement: float


class NoTickRules_5_List(fix.GroupContainer, CountCls=fields.NoTickRules, GroupCls=NoTickRules_5):
    def __getitem__(self, idx) -> NoTickRules_5:
        return super(NoTickRules_5_List, self).__getitem__(idx)


class NoLotTypeRules_5(fix.Group):
    Entries = [
        fix.Entry(fields.LotType, False),
        fix.Entry(fields.MinLotSize, False),
    ]

    LotType: str
    MinLotSize: float


class NoLotTypeRules_5_List(fix.GroupContainer, CountCls=fields.NoLotTypeRules, GroupCls=NoLotTypeRules_5):
    def __getitem__(self, idx) -> NoLotTypeRules_5:
        return super(NoLotTypeRules_5_List, self).__getitem__(idx)


class NoOrdTypeRules_10(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_10_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_10):
    def __getitem__(self, idx) -> NoOrdTypeRules_10:
        return super(NoOrdTypeRules_10_List, self).__getitem__(idx)


class NoTimeInForceRules_10(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_10_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_10):
    def __getitem__(self, idx) -> NoTimeInForceRules_10:
        return super(NoTimeInForceRules_10_List, self).__getitem__(idx)


class NoMatchRules_10(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_10_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_10):
    def __getitem__(self, idx) -> NoMatchRules_10:
        return super(NoMatchRules_10_List, self).__getitem__(idx)


class NoOrdTypeRules_11(fix.Group):
    Entries = [
        fix.Entry(fields.OrdType, False),
    ]

    OrdType: str


class NoOrdTypeRules_11_List(fix.GroupContainer, CountCls=fields.NoOrdTypeRules, GroupCls=NoOrdTypeRules_11):
    def __getitem__(self, idx) -> NoOrdTypeRules_11:
        return super(NoOrdTypeRules_11_List, self).__getitem__(idx)


class NoTimeInForceRules_11(fix.Group):
    Entries = [
        fix.Entry(fields.TimeInForce, False),
    ]

    TimeInForce: str


class NoTimeInForceRules_11_List(fix.GroupContainer, CountCls=fields.NoTimeInForceRules, GroupCls=NoTimeInForceRules_11):
    def __getitem__(self, idx) -> NoTimeInForceRules_11:
        return super(NoTimeInForceRules_11_List, self).__getitem__(idx)


class NoMatchRules_11(fix.Group):
    Entries = [
        fix.Entry(fields.MatchAlgorithm, False),
        fix.Entry(fields.MatchType, False),
    ]

    MatchAlgorithm: str
    MatchType: str


class NoMatchRules_11_List(fix.GroupContainer, CountCls=fields.NoMatchRules, GroupCls=NoMatchRules_11):
    def __getitem__(self, idx) -> NoMatchRules_11:
        return super(NoMatchRules_11_List, self).__getitem__(idx)


class NoTradingSessionRules_4(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(NoOrdTypeRules_11_List, False),
        fix.Entry(NoTimeInForceRules_11_List, False),
        fix.Entry(NoMatchRules_11_List, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str
    NoOrdTypeRules: NoOrdTypeRules_11_List
    NoTimeInForceRules: NoTimeInForceRules_11_List
    NoMatchRules: NoMatchRules_11_List


class NoTradingSessionRules_4_List(fix.GroupContainer, CountCls=fields.NoTradingSessionRules, GroupCls=NoTradingSessionRules_4):
    def __getitem__(self, idx) -> NoTradingSessionRules_4:
        return super(NoTradingSessionRules_4_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_14(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_14_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_14):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_14:
        return super(NoUnderlyingSecurityAltID_14_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_15(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_15_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_15):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_15:
        return super(NoUnderlyingSecurityAltID_15_List, self).__getitem__(idx)


class NoUnderlyings_7(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_15_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_15_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_7_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_7):
    def __getitem__(self, idx) -> NoUnderlyings_7:
        return super(NoUnderlyings_7_List, self).__getitem__(idx)


class NoLegSecurityAltID_13(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_13_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_13):
    def __getitem__(self, idx) -> NoLegSecurityAltID_13:
        return super(NoLegSecurityAltID_13_List, self).__getitem__(idx)


class NoLegSecurityAltID_14(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_14_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_14):
    def __getitem__(self, idx) -> NoLegSecurityAltID_14:
        return super(NoLegSecurityAltID_14_List, self).__getitem__(idx)


class NoLegs_7(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_14_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_14_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_7_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_7):
    def __getitem__(self, idx) -> NoLegs_7:
        return super(NoLegs_7_List, self).__getitem__(idx)


class NoOfCorpActionDetail_4(fix.Group):
    Entries = [
        fix.Entry(fields.CorpActionID, False),
        fix.Entry(fields.CorpActionCode, False),
        fix.Entry(fields.CorpActionCodeDesc, False),
        fix.Entry(fields.CorpActionDesc, False),
        fix.Entry(fields.CorpActionCodeType, False),
        fix.Entry(fields.CorpActionStartDate, False),
        fix.Entry(fields.CorpActionEndDate, False),
        fix.Entry(fields.CorpActionRecordDate, False),
        fix.Entry(fields.CorpActionStatus, False),
        fix.Entry(fields.CorporateActionExtended, False),
        fix.Entry(fields.CorpActionExDate, False),
        fix.Entry(fields.CorpActionPaymentDate, False),
        fix.Entry(fields.CorpActionValue, False),
    ]

    CorpActionID: int
    CorpActionCode: str
    CorpActionCodeDesc: str
    CorpActionDesc: str
    CorpActionCodeType: str
    CorpActionStartDate: str
    CorpActionEndDate: str
    CorpActionRecordDate: str
    CorpActionStatus: int
    CorporateActionExtended: str
    CorpActionExDate: str
    CorpActionPaymentDate: str
    CorpActionValue: int


class NoOfCorpActionDetail_4_List(fix.GroupContainer, CountCls=fields.NoOfCorpActionDetail, GroupCls=NoOfCorpActionDetail_4):
    def __getitem__(self, idx) -> NoOfCorpActionDetail_4:
        return super(NoOfCorpActionDetail_4_List, self).__getitem__(idx)


class NoRelatedSym_3(fix.Group):
    Entries = [
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_12_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_12_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_13_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_13_List, False),
        fix.Entry(NoInstrAttrib_11_List, False),
        fix.Entry(NoSecurityClassifications_4_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
        fix.Entry(NoTickRules_5_List, False),
        fix.Entry(NoLotTypeRules_5_List, False),
        fix.Entry(fields.RoundLot, False),
        fix.Entry(NoTradingSessionRules_4_List, False),
        fix.Entry(NoUnderlyings_7_List, False),
        fix.Entry(fields.Currency, False),
        fix.Entry(NoLegs_7_List, False),
        fix.Entry(fields.Text, False),
        fix.Entry(fields.EncodedTextLen, False),
        fix.Entry(fields.EncodedText, False),
        fix.Entry(NoOfCorpActionDetail_4_List, False),
        fix.Entry(fields.CorporateAction, False),
    ]

    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_12_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_12_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_13_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_13_List
    NoInstrAttrib: NoInstrAttrib_11_List
    NoSecurityClassifications: NoSecurityClassifications_4_List
    StartDate: str
    EndDate: str
    NoTickRules: NoTickRules_5_List
    NoLotTypeRules: NoLotTypeRules_5_List
    RoundLot: float
    NoTradingSessionRules: NoTradingSessionRules_4_List
    NoUnderlyings: NoUnderlyings_7_List
    Currency: str
    NoLegs: NoLegs_7_List
    Text: str
    EncodedTextLen: int
    EncodedText: str
    NoOfCorpActionDetail: NoOfCorpActionDetail_4_List
    CorporateAction: str


class NoRelatedSym_3_List(fix.GroupContainer, CountCls=fields.NoRelatedSym, GroupCls=NoRelatedSym_3):
    def __getitem__(self, idx) -> NoRelatedSym_3:
        return super(NoRelatedSym_3_List, self).__getitem__(idx)


class NoPartySubIDs_15(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_15_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_15):
    def __getitem__(self, idx) -> NoPartySubIDs_15:
        return super(NoPartySubIDs_15_List, self).__getitem__(idx)


class NoPartySubIDs_16(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_16_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_16):
    def __getitem__(self, idx) -> NoPartySubIDs_16:
        return super(NoPartySubIDs_16_List, self).__getitem__(idx)


class NoPartyIDs_8(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_16_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_16_List


class NoPartyIDs_8_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_8):
    def __getitem__(self, idx) -> NoPartyIDs_8:
        return super(NoPartyIDs_8_List, self).__getitem__(idx)


class NoOrderAttributes_3(fix.Group):
    Entries = [
        fix.Entry(fields.OrderAttributeType, False),
        fix.Entry(fields.OrderAttributeValue, False),
    ]

    OrderAttributeType: int
    OrderAttributeValue: str


class NoOrderAttributes_3_List(fix.GroupContainer, CountCls=fields.NoOrderAttributes, GroupCls=NoOrderAttributes_3):
    def __getitem__(self, idx) -> NoOrderAttributes_3:
        return super(NoOrderAttributes_3_List, self).__getitem__(idx)


class NoTradingSessions_2(fix.Group):
    Entries = [
        fix.Entry(fields.TradingSessionID, False),
        fix.Entry(fields.TradingSessionSubID, False),
    ]

    TradingSessionID: str
    TradingSessionSubID: str


class NoTradingSessions_2_List(fix.GroupContainer, CountCls=fields.NoTradingSessions, GroupCls=NoTradingSessions_2):
    def __getitem__(self, idx) -> NoTradingSessions_2:
        return super(NoTradingSessions_2_List, self).__getitem__(idx)


class NoSecurityAltID_13(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_13_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_13):
    def __getitem__(self, idx) -> NoSecurityAltID_13:
        return super(NoSecurityAltID_13_List, self).__getitem__(idx)


class NoEvents_13(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_13_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_13):
    def __getitem__(self, idx) -> NoEvents_13:
        return super(NoEvents_13_List, self).__getitem__(idx)


class NoInstrumentParties_14(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_14_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_14):
    def __getitem__(self, idx) -> NoInstrumentParties_14:
        return super(NoInstrumentParties_14_List, self).__getitem__(idx)


class NoStreams_14(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_14_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_14):
    def __getitem__(self, idx) -> NoStreams_14:
        return super(NoStreams_14_List, self).__getitem__(idx)


class NoTrdRegTimestamps_3(fix.Group):
    Entries = [
        fix.Entry(fields.TrdRegTimestamp, False),
        fix.Entry(fields.TrdRegTimestampType, False),
        fix.Entry(fields.DeskOrderHandlingInst, False),
        fix.Entry(fields.NBBOPrice, False),
        fix.Entry(fields.NBBOQty, False),
        fix.Entry(fields.NBBOSource, False),
        fix.Entry(fields.NBBOEntryType, False),
    ]

    TrdRegTimestamp: str
    TrdRegTimestampType: int
    DeskOrderHandlingInst: str
    NBBOPrice: float
    NBBOQty: float
    NBBOSource: int
    NBBOEntryType: int


class NoTrdRegTimestamps_3_List(fix.GroupContainer, CountCls=fields.NoTrdRegTimestamps, GroupCls=NoTrdRegTimestamps_3):
    def __getitem__(self, idx) -> NoTrdRegTimestamps_3:
        return super(NoTrdRegTimestamps_3_List, self).__getitem__(idx)


class NoOrderAttributes_4(fix.Group):
    Entries = [
        fix.Entry(fields.OrderAttributeType, False),
        fix.Entry(fields.OrderAttributeValue, False),
    ]

    OrderAttributeType: int
    OrderAttributeValue: str


class NoOrderAttributes_4_List(fix.GroupContainer, CountCls=fields.NoOrderAttributes, GroupCls=NoOrderAttributes_4):
    def __getitem__(self, idx) -> NoOrderAttributes_4:
        return super(NoOrderAttributes_4_List, self).__getitem__(idx)


class NoPartySubIDs_17(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_17_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_17):
    def __getitem__(self, idx) -> NoPartySubIDs_17:
        return super(NoPartySubIDs_17_List, self).__getitem__(idx)


class NoPartySubIDs_18(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_18_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_18):
    def __getitem__(self, idx) -> NoPartySubIDs_18:
        return super(NoPartySubIDs_18_List, self).__getitem__(idx)


class NoPartyIDs_9(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_18_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_18_List


class NoPartyIDs_9_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_9):
    def __getitem__(self, idx) -> NoPartyIDs_9:
        return super(NoPartyIDs_9_List, self).__getitem__(idx)


class NoRegulatoryTradeIDs_2(fix.Group):
    Entries = [
        fix.Entry(fields.RegulatoryTradeID, False),
        fix.Entry(fields.RegulatoryTradeIDType, False),
    ]

    RegulatoryTradeID: str
    RegulatoryTradeIDType: int


class NoRegulatoryTradeIDs_2_List(fix.GroupContainer, CountCls=fields.NoRegulatoryTradeIDs, GroupCls=NoRegulatoryTradeIDs_2):
    def __getitem__(self, idx) -> NoRegulatoryTradeIDs_2:
        return super(NoRegulatoryTradeIDs_2_List, self).__getitem__(idx)


class NoSecurityAltID_14(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_14_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_14):
    def __getitem__(self, idx) -> NoSecurityAltID_14:
        return super(NoSecurityAltID_14_List, self).__getitem__(idx)


class NoEvents_14(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_14_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_14):
    def __getitem__(self, idx) -> NoEvents_14:
        return super(NoEvents_14_List, self).__getitem__(idx)


class NoInstrumentParties_15(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_15_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_15):
    def __getitem__(self, idx) -> NoInstrumentParties_15:
        return super(NoInstrumentParties_15_List, self).__getitem__(idx)


class NoStreams_15(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_15_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_15):
    def __getitem__(self, idx) -> NoStreams_15:
        return super(NoStreams_15_List, self).__getitem__(idx)


class NoLegSecurityAltID_15(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_15_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_15):
    def __getitem__(self, idx) -> NoLegSecurityAltID_15:
        return super(NoLegSecurityAltID_15_List, self).__getitem__(idx)


class NoLegSecurityAltID_16(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_16_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_16):
    def __getitem__(self, idx) -> NoLegSecurityAltID_16:
        return super(NoLegSecurityAltID_16_List, self).__getitem__(idx)


class NoLegs_8(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_16_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
        fix.Entry(fields.LegLastPx, False),
        fix.Entry(fields.LegLastQty, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_16_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str
    LegLastPx: float
    LegLastQty: float


class NoLegs_8_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_8):
    def __getitem__(self, idx) -> NoLegs_8:
        return super(NoLegs_8_List, self).__getitem__(idx)


class NoTrdRegTimestamps_4(fix.Group):
    Entries = [
        fix.Entry(fields.TrdRegTimestamp, False),
        fix.Entry(fields.TrdRegTimestampType, False),
        fix.Entry(fields.DeskOrderHandlingInst, False),
        fix.Entry(fields.NBBOPrice, False),
        fix.Entry(fields.NBBOQty, False),
        fix.Entry(fields.NBBOSource, False),
        fix.Entry(fields.NBBOEntryType, False),
    ]

    TrdRegTimestamp: str
    TrdRegTimestampType: int
    DeskOrderHandlingInst: str
    NBBOPrice: float
    NBBOQty: float
    NBBOSource: int
    NBBOEntryType: int


class NoTrdRegTimestamps_4_List(fix.GroupContainer, CountCls=fields.NoTrdRegTimestamps, GroupCls=NoTrdRegTimestamps_4):
    def __getitem__(self, idx) -> NoTrdRegTimestamps_4:
        return super(NoTrdRegTimestamps_4_List, self).__getitem__(idx)


class NoPartySubIDs_19(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_19_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_19):
    def __getitem__(self, idx) -> NoPartySubIDs_19:
        return super(NoPartySubIDs_19_List, self).__getitem__(idx)


class NoPartySubIDs_20(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_20_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_20):
    def __getitem__(self, idx) -> NoPartySubIDs_20:
        return super(NoPartySubIDs_20_List, self).__getitem__(idx)


class NoPartyIDs_10(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_20_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_20_List


class NoPartyIDs_10_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_10):
    def __getitem__(self, idx) -> NoPartyIDs_10:
        return super(NoPartyIDs_10_List, self).__getitem__(idx)


class NoSecurityAltID_15(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_15_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_15):
    def __getitem__(self, idx) -> NoSecurityAltID_15:
        return super(NoSecurityAltID_15_List, self).__getitem__(idx)


class NoEvents_15(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_15_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_15):
    def __getitem__(self, idx) -> NoEvents_15:
        return super(NoEvents_15_List, self).__getitem__(idx)


class NoInstrumentParties_16(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_16_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_16):
    def __getitem__(self, idx) -> NoInstrumentParties_16:
        return super(NoInstrumentParties_16_List, self).__getitem__(idx)


class NoStreams_16(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_16_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_16):
    def __getitem__(self, idx) -> NoStreams_16:
        return super(NoStreams_16_List, self).__getitem__(idx)


class NoPartySubIDs_21(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_21_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_21):
    def __getitem__(self, idx) -> NoPartySubIDs_21:
        return super(NoPartySubIDs_21_List, self).__getitem__(idx)


class NoPartySubIDs_22(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_22_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_22):
    def __getitem__(self, idx) -> NoPartySubIDs_22:
        return super(NoPartySubIDs_22_List, self).__getitem__(idx)


class NoPartyIDs_11(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_22_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_22_List


class NoPartyIDs_11_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_11):
    def __getitem__(self, idx) -> NoPartyIDs_11:
        return super(NoPartyIDs_11_List, self).__getitem__(idx)


class NoOrderAttributes_5(fix.Group):
    Entries = [
        fix.Entry(fields.OrderAttributeType, False),
        fix.Entry(fields.OrderAttributeValue, False),
    ]

    OrderAttributeType: int
    OrderAttributeValue: str


class NoOrderAttributes_5_List(fix.GroupContainer, CountCls=fields.NoOrderAttributes, GroupCls=NoOrderAttributes_5):
    def __getitem__(self, idx) -> NoOrderAttributes_5:
        return super(NoOrderAttributes_5_List, self).__getitem__(idx)


class NoSecurityAltID_16(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_16_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_16):
    def __getitem__(self, idx) -> NoSecurityAltID_16:
        return super(NoSecurityAltID_16_List, self).__getitem__(idx)


class NoEvents_16(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_16_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_16):
    def __getitem__(self, idx) -> NoEvents_16:
        return super(NoEvents_16_List, self).__getitem__(idx)


class NoInstrumentParties_17(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_17_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_17):
    def __getitem__(self, idx) -> NoInstrumentParties_17:
        return super(NoInstrumentParties_17_List, self).__getitem__(idx)


class NoStreams_17(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_17_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_17):
    def __getitem__(self, idx) -> NoStreams_17:
        return super(NoStreams_17_List, self).__getitem__(idx)


class NoTrdRegTimestamps_5(fix.Group):
    Entries = [
        fix.Entry(fields.TrdRegTimestamp, False),
        fix.Entry(fields.TrdRegTimestampType, False),
        fix.Entry(fields.DeskOrderHandlingInst, False),
        fix.Entry(fields.NBBOPrice, False),
        fix.Entry(fields.NBBOQty, False),
        fix.Entry(fields.NBBOSource, False),
        fix.Entry(fields.NBBOEntryType, False),
    ]

    TrdRegTimestamp: str
    TrdRegTimestampType: int
    DeskOrderHandlingInst: str
    NBBOPrice: float
    NBBOQty: float
    NBBOSource: int
    NBBOEntryType: int


class NoTrdRegTimestamps_5_List(fix.GroupContainer, CountCls=fields.NoTrdRegTimestamps, GroupCls=NoTrdRegTimestamps_5):
    def __getitem__(self, idx) -> NoTrdRegTimestamps_5:
        return super(NoTrdRegTimestamps_5_List, self).__getitem__(idx)


class NoPartySubIDs_23(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_23_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_23):
    def __getitem__(self, idx) -> NoPartySubIDs_23:
        return super(NoPartySubIDs_23_List, self).__getitem__(idx)


class NoPartySubIDs_24(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_24_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_24):
    def __getitem__(self, idx) -> NoPartySubIDs_24:
        return super(NoPartySubIDs_24_List, self).__getitem__(idx)


class NoPartyIDs_12(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_24_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_24_List


class NoPartyIDs_12_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_12):
    def __getitem__(self, idx) -> NoPartyIDs_12:
        return super(NoPartyIDs_12_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_16(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_16_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_16):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_16:
        return super(NoUnderlyingSecurityAltID_16_List, self).__getitem__(idx)


class NoSecurityAltID_17(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_17_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_17):
    def __getitem__(self, idx) -> NoSecurityAltID_17:
        return super(NoSecurityAltID_17_List, self).__getitem__(idx)


class NoEvents_17(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_17_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_17):
    def __getitem__(self, idx) -> NoEvents_17:
        return super(NoEvents_17_List, self).__getitem__(idx)


class NoInstrumentParties_18(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_18_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_18):
    def __getitem__(self, idx) -> NoInstrumentParties_18:
        return super(NoInstrumentParties_18_List, self).__getitem__(idx)


class NoStreams_18(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_18_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_18):
    def __getitem__(self, idx) -> NoStreams_18:
        return super(NoStreams_18_List, self).__getitem__(idx)


class NoLegSecurityAltID_17(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_17_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_17):
    def __getitem__(self, idx) -> NoLegSecurityAltID_17:
        return super(NoLegSecurityAltID_17_List, self).__getitem__(idx)


class NoLegSecurityAltID_18(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_18_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_18):
    def __getitem__(self, idx) -> NoLegSecurityAltID_18:
        return super(NoLegSecurityAltID_18_List, self).__getitem__(idx)


class NoLegs_9(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_18_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_18_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_9_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_9):
    def __getitem__(self, idx) -> NoLegs_9:
        return super(NoLegs_9_List, self).__getitem__(idx)


class NoSecurityAltID_18(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_18_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_18):
    def __getitem__(self, idx) -> NoSecurityAltID_18:
        return super(NoSecurityAltID_18_List, self).__getitem__(idx)


class NoEvents_18(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_18_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_18):
    def __getitem__(self, idx) -> NoEvents_18:
        return super(NoEvents_18_List, self).__getitem__(idx)


class NoInstrumentParties_19(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_19_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_19):
    def __getitem__(self, idx) -> NoInstrumentParties_19:
        return super(NoInstrumentParties_19_List, self).__getitem__(idx)


class NoStreams_19(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_19_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_19):
    def __getitem__(self, idx) -> NoStreams_19:
        return super(NoStreams_19_List, self).__getitem__(idx)


class NoLegSecurityAltID_19(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_19_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_19):
    def __getitem__(self, idx) -> NoLegSecurityAltID_19:
        return super(NoLegSecurityAltID_19_List, self).__getitem__(idx)


class NoLegSecurityAltID_20(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_20_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_20):
    def __getitem__(self, idx) -> NoLegSecurityAltID_20:
        return super(NoLegSecurityAltID_20_List, self).__getitem__(idx)


class NoLegs_10(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_20_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_20_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_10_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_10):
    def __getitem__(self, idx) -> NoLegs_10:
        return super(NoLegs_10_List, self).__getitem__(idx)


class NoQuoteEntries_1(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteEntryID, True),
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_18_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_18_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_19_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_19_List, False),
        fix.Entry(NoLegs_10_List, False),
        fix.Entry(fields.BidPx, False),
        fix.Entry(fields.OfferPx, False),
        fix.Entry(fields.BidSize, False),
        fix.Entry(fields.OfferSize, False),
        fix.Entry(fields.ValidUntilTime, False),
        fix.Entry(fields.TransactTime, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(fields.OrderCapacity, False),
        fix.Entry(fields.OrderRestrictions, False),
    ]

    QuoteEntryID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_18_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_18_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_19_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_19_List
    NoLegs: NoLegs_10_List
    BidPx: float
    OfferPx: float
    BidSize: float
    OfferSize: float
    ValidUntilTime: str
    TransactTime: str
    TradingSessionSubID: str
    SettlDate: str
    OrderCapacity: str
    OrderRestrictions: str


class NoQuoteEntries_1_List(fix.GroupContainer, CountCls=fields.NoQuoteEntries, GroupCls=NoQuoteEntries_1):
    def __getitem__(self, idx) -> NoQuoteEntries_1:
        return super(NoQuoteEntries_1_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_17(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_17_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_17):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_17:
        return super(NoUnderlyingSecurityAltID_17_List, self).__getitem__(idx)


class NoSecurityAltID_19(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_19_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_19):
    def __getitem__(self, idx) -> NoSecurityAltID_19:
        return super(NoSecurityAltID_19_List, self).__getitem__(idx)


class NoEvents_19(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_19_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_19):
    def __getitem__(self, idx) -> NoEvents_19:
        return super(NoEvents_19_List, self).__getitem__(idx)


class NoInstrumentParties_20(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_20_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_20):
    def __getitem__(self, idx) -> NoInstrumentParties_20:
        return super(NoInstrumentParties_20_List, self).__getitem__(idx)


class NoStreams_20(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_20_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_20):
    def __getitem__(self, idx) -> NoStreams_20:
        return super(NoStreams_20_List, self).__getitem__(idx)


class NoLegSecurityAltID_21(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_21_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_21):
    def __getitem__(self, idx) -> NoLegSecurityAltID_21:
        return super(NoLegSecurityAltID_21_List, self).__getitem__(idx)


class NoLegSecurityAltID_22(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_22_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_22):
    def __getitem__(self, idx) -> NoLegSecurityAltID_22:
        return super(NoLegSecurityAltID_22_List, self).__getitem__(idx)


class NoLegs_11(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_22_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_22_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_11_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_11):
    def __getitem__(self, idx) -> NoLegs_11:
        return super(NoLegs_11_List, self).__getitem__(idx)


class NoSecurityAltID_20(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_20_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_20):
    def __getitem__(self, idx) -> NoSecurityAltID_20:
        return super(NoSecurityAltID_20_List, self).__getitem__(idx)


class NoEvents_20(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_20_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_20):
    def __getitem__(self, idx) -> NoEvents_20:
        return super(NoEvents_20_List, self).__getitem__(idx)


class NoInstrumentParties_21(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_21_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_21):
    def __getitem__(self, idx) -> NoInstrumentParties_21:
        return super(NoInstrumentParties_21_List, self).__getitem__(idx)


class NoStreams_21(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_21_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_21):
    def __getitem__(self, idx) -> NoStreams_21:
        return super(NoStreams_21_List, self).__getitem__(idx)


class NoLegSecurityAltID_23(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_23_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_23):
    def __getitem__(self, idx) -> NoLegSecurityAltID_23:
        return super(NoLegSecurityAltID_23_List, self).__getitem__(idx)


class NoLegSecurityAltID_24(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_24_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_24):
    def __getitem__(self, idx) -> NoLegSecurityAltID_24:
        return super(NoLegSecurityAltID_24_List, self).__getitem__(idx)


class NoLegs_12(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_24_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_24_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_12_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_12):
    def __getitem__(self, idx) -> NoLegs_12:
        return super(NoLegs_12_List, self).__getitem__(idx)


class NoQuoteEntries_2(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteEntryID, True),
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_20_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_20_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_21_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_21_List, False),
        fix.Entry(NoLegs_12_List, False),
        fix.Entry(fields.BidPx, False),
        fix.Entry(fields.OfferPx, False),
        fix.Entry(fields.BidSize, False),
        fix.Entry(fields.OfferSize, False),
        fix.Entry(fields.ValidUntilTime, False),
        fix.Entry(fields.TransactTime, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(fields.OrderCapacity, False),
        fix.Entry(fields.OrderRestrictions, False),
    ]

    QuoteEntryID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_20_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_20_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_21_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_21_List
    NoLegs: NoLegs_12_List
    BidPx: float
    OfferPx: float
    BidSize: float
    OfferSize: float
    ValidUntilTime: str
    TransactTime: str
    TradingSessionSubID: str
    SettlDate: str
    OrderCapacity: str
    OrderRestrictions: str


class NoQuoteEntries_2_List(fix.GroupContainer, CountCls=fields.NoQuoteEntries, GroupCls=NoQuoteEntries_2):
    def __getitem__(self, idx) -> NoQuoteEntries_2:
        return super(NoQuoteEntries_2_List, self).__getitem__(idx)


class NoQuoteSets_1(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteSetID, True),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_17_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
        fix.Entry(fields.TotNoQuoteEntries, True),
        fix.Entry(fields.LastFragment, False),
        fix.Entry(NoQuoteEntries_2_List, True),
    ]

    QuoteSetID: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_17_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str
    TotNoQuoteEntries: int
    LastFragment: bool
    NoQuoteEntries: NoQuoteEntries_2_List


class NoQuoteSets_1_List(fix.GroupContainer, CountCls=fields.NoQuoteSets, GroupCls=NoQuoteSets_1):
    def __getitem__(self, idx) -> NoQuoteSets_1:
        return super(NoQuoteSets_1_List, self).__getitem__(idx)


class NoPartySubIDs_25(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_25_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_25):
    def __getitem__(self, idx) -> NoPartySubIDs_25:
        return super(NoPartySubIDs_25_List, self).__getitem__(idx)


class NoPartySubIDs_26(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_26_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_26):
    def __getitem__(self, idx) -> NoPartySubIDs_26:
        return super(NoPartySubIDs_26_List, self).__getitem__(idx)


class NoPartyIDs_13(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_26_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_26_List


class NoPartyIDs_13_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_13):
    def __getitem__(self, idx) -> NoPartyIDs_13:
        return super(NoPartyIDs_13_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_18(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_18_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_18):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_18:
        return super(NoUnderlyingSecurityAltID_18_List, self).__getitem__(idx)


class NoSecurityAltID_21(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_21_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_21):
    def __getitem__(self, idx) -> NoSecurityAltID_21:
        return super(NoSecurityAltID_21_List, self).__getitem__(idx)


class NoEvents_21(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_21_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_21):
    def __getitem__(self, idx) -> NoEvents_21:
        return super(NoEvents_21_List, self).__getitem__(idx)


class NoInstrumentParties_22(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_22_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_22):
    def __getitem__(self, idx) -> NoInstrumentParties_22:
        return super(NoInstrumentParties_22_List, self).__getitem__(idx)


class NoStreams_22(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_22_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_22):
    def __getitem__(self, idx) -> NoStreams_22:
        return super(NoStreams_22_List, self).__getitem__(idx)


class NoLegSecurityAltID_25(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_25_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_25):
    def __getitem__(self, idx) -> NoLegSecurityAltID_25:
        return super(NoLegSecurityAltID_25_List, self).__getitem__(idx)


class NoLegSecurityAltID_26(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_26_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_26):
    def __getitem__(self, idx) -> NoLegSecurityAltID_26:
        return super(NoLegSecurityAltID_26_List, self).__getitem__(idx)


class NoLegs_13(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_26_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_26_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_13_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_13):
    def __getitem__(self, idx) -> NoLegs_13:
        return super(NoLegs_13_List, self).__getitem__(idx)


class NoSecurityAltID_22(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_22_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_22):
    def __getitem__(self, idx) -> NoSecurityAltID_22:
        return super(NoSecurityAltID_22_List, self).__getitem__(idx)


class NoEvents_22(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_22_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_22):
    def __getitem__(self, idx) -> NoEvents_22:
        return super(NoEvents_22_List, self).__getitem__(idx)


class NoInstrumentParties_23(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_23_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_23):
    def __getitem__(self, idx) -> NoInstrumentParties_23:
        return super(NoInstrumentParties_23_List, self).__getitem__(idx)


class NoStreams_23(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_23_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_23):
    def __getitem__(self, idx) -> NoStreams_23:
        return super(NoStreams_23_List, self).__getitem__(idx)


class NoLegSecurityAltID_27(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_27_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_27):
    def __getitem__(self, idx) -> NoLegSecurityAltID_27:
        return super(NoLegSecurityAltID_27_List, self).__getitem__(idx)


class NoLegSecurityAltID_28(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_28_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_28):
    def __getitem__(self, idx) -> NoLegSecurityAltID_28:
        return super(NoLegSecurityAltID_28_List, self).__getitem__(idx)


class NoLegs_14(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_28_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_28_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_14_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_14):
    def __getitem__(self, idx) -> NoLegs_14:
        return super(NoLegs_14_List, self).__getitem__(idx)


class NoQuoteEntries_3(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteEntryID, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(NoSecurityAltID_22_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_22_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_23_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_23_List, False),
        fix.Entry(NoLegs_14_List, False),
        fix.Entry(fields.ValidUntilTime, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(fields.OrderRestrictions, False),
        fix.Entry(fields.QuoteEntryStatus, False),
        fix.Entry(fields.QuoteEntryRejectReason, False),
    ]

    QuoteEntryID: str
    SymbolSfx: str
    NoSecurityAltID: NoSecurityAltID_22_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_22_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_23_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_23_List
    NoLegs: NoLegs_14_List
    ValidUntilTime: str
    TradingSessionSubID: str
    SettlDate: str
    OrderRestrictions: str
    QuoteEntryStatus: int
    QuoteEntryRejectReason: int


class NoQuoteEntries_3_List(fix.GroupContainer, CountCls=fields.NoQuoteEntries, GroupCls=NoQuoteEntries_3):
    def __getitem__(self, idx) -> NoQuoteEntries_3:
        return super(NoQuoteEntries_3_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_19(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_19_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_19):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_19:
        return super(NoUnderlyingSecurityAltID_19_List, self).__getitem__(idx)


class NoSecurityAltID_23(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_23_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_23):
    def __getitem__(self, idx) -> NoSecurityAltID_23:
        return super(NoSecurityAltID_23_List, self).__getitem__(idx)


class NoEvents_23(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_23_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_23):
    def __getitem__(self, idx) -> NoEvents_23:
        return super(NoEvents_23_List, self).__getitem__(idx)


class NoInstrumentParties_24(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_24_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_24):
    def __getitem__(self, idx) -> NoInstrumentParties_24:
        return super(NoInstrumentParties_24_List, self).__getitem__(idx)


class NoStreams_24(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_24_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_24):
    def __getitem__(self, idx) -> NoStreams_24:
        return super(NoStreams_24_List, self).__getitem__(idx)


class NoLegSecurityAltID_29(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_29_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_29):
    def __getitem__(self, idx) -> NoLegSecurityAltID_29:
        return super(NoLegSecurityAltID_29_List, self).__getitem__(idx)


class NoLegSecurityAltID_30(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_30_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_30):
    def __getitem__(self, idx) -> NoLegSecurityAltID_30:
        return super(NoLegSecurityAltID_30_List, self).__getitem__(idx)


class NoLegs_15(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_30_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_30_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_15_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_15):
    def __getitem__(self, idx) -> NoLegs_15:
        return super(NoLegs_15_List, self).__getitem__(idx)


class NoSecurityAltID_24(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_24_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_24):
    def __getitem__(self, idx) -> NoSecurityAltID_24:
        return super(NoSecurityAltID_24_List, self).__getitem__(idx)


class NoEvents_24(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_24_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_24):
    def __getitem__(self, idx) -> NoEvents_24:
        return super(NoEvents_24_List, self).__getitem__(idx)


class NoInstrumentParties_25(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_25_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_25):
    def __getitem__(self, idx) -> NoInstrumentParties_25:
        return super(NoInstrumentParties_25_List, self).__getitem__(idx)


class NoStreams_25(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_25_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_25):
    def __getitem__(self, idx) -> NoStreams_25:
        return super(NoStreams_25_List, self).__getitem__(idx)


class NoLegSecurityAltID_31(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_31_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_31):
    def __getitem__(self, idx) -> NoLegSecurityAltID_31:
        return super(NoLegSecurityAltID_31_List, self).__getitem__(idx)


class NoLegSecurityAltID_32(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_32_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_32):
    def __getitem__(self, idx) -> NoLegSecurityAltID_32:
        return super(NoLegSecurityAltID_32_List, self).__getitem__(idx)


class NoLegs_16(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_32_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_32_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_16_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_16):
    def __getitem__(self, idx) -> NoLegs_16:
        return super(NoLegs_16_List, self).__getitem__(idx)


class NoQuoteEntries_4(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteEntryID, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(NoSecurityAltID_24_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_24_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_25_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_25_List, False),
        fix.Entry(NoLegs_16_List, False),
        fix.Entry(fields.ValidUntilTime, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(fields.OrderRestrictions, False),
        fix.Entry(fields.QuoteEntryStatus, False),
        fix.Entry(fields.QuoteEntryRejectReason, False),
    ]

    QuoteEntryID: str
    SymbolSfx: str
    NoSecurityAltID: NoSecurityAltID_24_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_24_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_25_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_25_List
    NoLegs: NoLegs_16_List
    ValidUntilTime: str
    TradingSessionSubID: str
    SettlDate: str
    OrderRestrictions: str
    QuoteEntryStatus: int
    QuoteEntryRejectReason: int


class NoQuoteEntries_4_List(fix.GroupContainer, CountCls=fields.NoQuoteEntries, GroupCls=NoQuoteEntries_4):
    def __getitem__(self, idx) -> NoQuoteEntries_4:
        return super(NoQuoteEntries_4_List, self).__getitem__(idx)


class NoQuoteSets_2(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteSetID, False),
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_19_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
        fix.Entry(fields.TotNoQuoteEntries, False),
        fix.Entry(fields.TotNoRejQuotes, False),
        fix.Entry(fields.LastFragment, False),
        fix.Entry(NoQuoteEntries_4_List, False),
    ]

    QuoteSetID: str
    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_19_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str
    TotNoQuoteEntries: int
    TotNoRejQuotes: int
    LastFragment: bool
    NoQuoteEntries: NoQuoteEntries_4_List


class NoQuoteSets_2_List(fix.GroupContainer, CountCls=fields.NoQuoteSets, GroupCls=NoQuoteSets_2):
    def __getitem__(self, idx) -> NoQuoteSets_2:
        return super(NoQuoteSets_2_List, self).__getitem__(idx)


class NoQuoteAttributes_1(fix.Group):
    Entries = [
        fix.Entry(fields.QuoteAttributeType, False),
        fix.Entry(fields.QuoteAttributeValue, False),
    ]

    QuoteAttributeType: int
    QuoteAttributeValue: str


class NoQuoteAttributes_1_List(fix.GroupContainer, CountCls=fields.NoQuoteAttributes, GroupCls=NoQuoteAttributes_1):
    def __getitem__(self, idx) -> NoQuoteAttributes_1:
        return super(NoQuoteAttributes_1_List, self).__getitem__(idx)


class NoPartySubIDs_27(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_27_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_27):
    def __getitem__(self, idx) -> NoPartySubIDs_27:
        return super(NoPartySubIDs_27_List, self).__getitem__(idx)


class NoPartySubIDs_28(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_28_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_28):
    def __getitem__(self, idx) -> NoPartySubIDs_28:
        return super(NoPartySubIDs_28_List, self).__getitem__(idx)


class NoPartyIDs_14(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_28_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_28_List


class NoPartyIDs_14_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_14):
    def __getitem__(self, idx) -> NoPartyIDs_14:
        return super(NoPartyIDs_14_List, self).__getitem__(idx)


class NoSecurityAltID_25(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_25_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_25):
    def __getitem__(self, idx) -> NoSecurityAltID_25:
        return super(NoSecurityAltID_25_List, self).__getitem__(idx)


class NoEvents_25(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_25_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_25):
    def __getitem__(self, idx) -> NoEvents_25:
        return super(NoEvents_25_List, self).__getitem__(idx)


class NoInstrumentParties_26(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_26_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_26):
    def __getitem__(self, idx) -> NoInstrumentParties_26:
        return super(NoInstrumentParties_26_List, self).__getitem__(idx)


class NoStreams_26(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_26_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_26):
    def __getitem__(self, idx) -> NoStreams_26:
        return super(NoStreams_26_List, self).__getitem__(idx)


class NoLegSecurityAltID_33(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_33_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_33):
    def __getitem__(self, idx) -> NoLegSecurityAltID_33:
        return super(NoLegSecurityAltID_33_List, self).__getitem__(idx)


class NoLegSecurityAltID_34(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_34_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_34):
    def __getitem__(self, idx) -> NoLegSecurityAltID_34:
        return super(NoLegSecurityAltID_34_List, self).__getitem__(idx)


class NoLegs_17(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_34_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_34_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_17_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_17):
    def __getitem__(self, idx) -> NoLegs_17:
        return super(NoLegs_17_List, self).__getitem__(idx)


class NoPartySubIDs_29(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_29_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_29):
    def __getitem__(self, idx) -> NoPartySubIDs_29:
        return super(NoPartySubIDs_29_List, self).__getitem__(idx)


class NoPartySubIDs_30(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_30_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_30):
    def __getitem__(self, idx) -> NoPartySubIDs_30:
        return super(NoPartySubIDs_30_List, self).__getitem__(idx)


class NoPartyIDs_15(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_30_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_30_List


class NoPartyIDs_15_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_15):
    def __getitem__(self, idx) -> NoPartyIDs_15:
        return super(NoPartyIDs_15_List, self).__getitem__(idx)


class NoSecurityAltID_26(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_26_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_26):
    def __getitem__(self, idx) -> NoSecurityAltID_26:
        return super(NoSecurityAltID_26_List, self).__getitem__(idx)


class NoEvents_26(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_26_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_26):
    def __getitem__(self, idx) -> NoEvents_26:
        return super(NoEvents_26_List, self).__getitem__(idx)


class NoInstrumentParties_27(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_27_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_27):
    def __getitem__(self, idx) -> NoInstrumentParties_27:
        return super(NoInstrumentParties_27_List, self).__getitem__(idx)


class NoStreams_27(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_27_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_27):
    def __getitem__(self, idx) -> NoStreams_27:
        return super(NoStreams_27_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_20(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_20_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_20):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_20:
        return super(NoUnderlyingSecurityAltID_20_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_21(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_21_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_21):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_21:
        return super(NoUnderlyingSecurityAltID_21_List, self).__getitem__(idx)


class NoUnderlyings_8(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_21_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_21_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_8_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_8):
    def __getitem__(self, idx) -> NoUnderlyings_8:
        return super(NoUnderlyings_8_List, self).__getitem__(idx)


class NoLegSecurityAltID_35(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_35_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_35):
    def __getitem__(self, idx) -> NoLegSecurityAltID_35:
        return super(NoLegSecurityAltID_35_List, self).__getitem__(idx)


class NoLegSecurityAltID_36(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_36_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_36):
    def __getitem__(self, idx) -> NoLegSecurityAltID_36:
        return super(NoLegSecurityAltID_36_List, self).__getitem__(idx)


class NoLegs_18(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_36_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_36_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_18_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_18):
    def __getitem__(self, idx) -> NoLegs_18:
        return super(NoLegs_18_List, self).__getitem__(idx)


class NoSecurityAltID_27(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_27_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_27):
    def __getitem__(self, idx) -> NoSecurityAltID_27:
        return super(NoSecurityAltID_27_List, self).__getitem__(idx)


class NoEvents_27(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_27_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_27):
    def __getitem__(self, idx) -> NoEvents_27:
        return super(NoEvents_27_List, self).__getitem__(idx)


class NoInstrumentParties_28(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_28_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_28):
    def __getitem__(self, idx) -> NoInstrumentParties_28:
        return super(NoInstrumentParties_28_List, self).__getitem__(idx)


class NoStreams_28(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_28_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_28):
    def __getitem__(self, idx) -> NoStreams_28:
        return super(NoStreams_28_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_22(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_22_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_22):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_22:
        return super(NoUnderlyingSecurityAltID_22_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_23(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_23_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_23):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_23:
        return super(NoUnderlyingSecurityAltID_23_List, self).__getitem__(idx)


class NoUnderlyings_9(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_23_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_23_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_9_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_9):
    def __getitem__(self, idx) -> NoUnderlyings_9:
        return super(NoUnderlyings_9_List, self).__getitem__(idx)


class NoLegSecurityAltID_37(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_37_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_37):
    def __getitem__(self, idx) -> NoLegSecurityAltID_37:
        return super(NoLegSecurityAltID_37_List, self).__getitem__(idx)


class NoLegSecurityAltID_38(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_38_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_38):
    def __getitem__(self, idx) -> NoLegSecurityAltID_38:
        return super(NoLegSecurityAltID_38_List, self).__getitem__(idx)


class NoLegs_19(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_38_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_38_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_19_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_19):
    def __getitem__(self, idx) -> NoLegs_19:
        return super(NoLegs_19_List, self).__getitem__(idx)


class NoQuoteEntries_5(fix.Group):
    Entries = [
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(NoSecurityAltID_27_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_27_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_28_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_28_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
        fix.Entry(NoUnderlyings_9_List, False),
        fix.Entry(NoLegs_19_List, False),
    ]

    Symbol: str
    SymbolSfx: str
    NoSecurityAltID: NoSecurityAltID_27_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_27_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_28_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_28_List
    StartDate: str
    EndDate: str
    NoUnderlyings: NoUnderlyings_9_List
    NoLegs: NoLegs_19_List


class NoQuoteEntries_5_List(fix.GroupContainer, CountCls=fields.NoQuoteEntries, GroupCls=NoQuoteEntries_5):
    def __getitem__(self, idx) -> NoQuoteEntries_5:
        return super(NoQuoteEntries_5_List, self).__getitem__(idx)


class NoRootPartySubIDs_4(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_4_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_4):
    def __getitem__(self, idx) -> NoRootPartySubIDs_4:
        return super(NoRootPartySubIDs_4_List, self).__getitem__(idx)


class NoRootPartySubIDs_5(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_5_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_5):
    def __getitem__(self, idx) -> NoRootPartySubIDs_5:
        return super(NoRootPartySubIDs_5_List, self).__getitem__(idx)


class NoRootPartyIDs_2(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartyID, False),
        fix.Entry(fields.RootPartyIDSource, False),
        fix.Entry(fields.RootPartyRole, False),
        fix.Entry(NoRootPartySubIDs_5_List, False),
        fix.Entry(fields.PartyRoleQualifier, False),
    ]

    RootPartyID: str
    RootPartyIDSource: str
    RootPartyRole: int
    NoRootPartySubIDs: NoRootPartySubIDs_5_List
    PartyRoleQualifier: int


class NoRootPartyIDs_2_List(fix.GroupContainer, CountCls=fields.NoRootPartyIDs, GroupCls=NoRootPartyIDs_2):
    def __getitem__(self, idx) -> NoRootPartyIDs_2:
        return super(NoRootPartyIDs_2_List, self).__getitem__(idx)


class NoSecurityAltID_28(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_28_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_28):
    def __getitem__(self, idx) -> NoSecurityAltID_28:
        return super(NoSecurityAltID_28_List, self).__getitem__(idx)


class NoEvents_28(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_28_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_28):
    def __getitem__(self, idx) -> NoEvents_28:
        return super(NoEvents_28_List, self).__getitem__(idx)


class NoInstrumentParties_29(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_29_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_29):
    def __getitem__(self, idx) -> NoInstrumentParties_29:
        return super(NoInstrumentParties_29_List, self).__getitem__(idx)


class NoStreams_29(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_29_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_29):
    def __getitem__(self, idx) -> NoStreams_29:
        return super(NoStreams_29_List, self).__getitem__(idx)


class NoLegSecurityAltID_39(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_39_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_39):
    def __getitem__(self, idx) -> NoLegSecurityAltID_39:
        return super(NoLegSecurityAltID_39_List, self).__getitem__(idx)


class NoLegSecurityAltID_40(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_40_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_40):
    def __getitem__(self, idx) -> NoLegSecurityAltID_40:
        return super(NoLegSecurityAltID_40_List, self).__getitem__(idx)


class NoLegs_20(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_40_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_40_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_20_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_20):
    def __getitem__(self, idx) -> NoLegs_20:
        return super(NoLegs_20_List, self).__getitem__(idx)


class NoSecurityAltID_29(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_29_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_29):
    def __getitem__(self, idx) -> NoSecurityAltID_29:
        return super(NoSecurityAltID_29_List, self).__getitem__(idx)


class NoEvents_29(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_29_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_29):
    def __getitem__(self, idx) -> NoEvents_29:
        return super(NoEvents_29_List, self).__getitem__(idx)


class NoInstrumentParties_30(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_30_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_30):
    def __getitem__(self, idx) -> NoInstrumentParties_30:
        return super(NoInstrumentParties_30_List, self).__getitem__(idx)


class NoStreams_30(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_30_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_30):
    def __getitem__(self, idx) -> NoStreams_30:
        return super(NoStreams_30_List, self).__getitem__(idx)


class NoLegSecurityAltID_41(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_41_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_41):
    def __getitem__(self, idx) -> NoLegSecurityAltID_41:
        return super(NoLegSecurityAltID_41_List, self).__getitem__(idx)


class NoLegSecurityAltID_42(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_42_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_42):
    def __getitem__(self, idx) -> NoLegSecurityAltID_42:
        return super(NoLegSecurityAltID_42_List, self).__getitem__(idx)


class NoLegs_21(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_42_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_42_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_21_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_21):
    def __getitem__(self, idx) -> NoLegs_21:
        return super(NoLegs_21_List, self).__getitem__(idx)


class NoRelatedSym_4(fix.Group):
    Entries = [
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_29_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_29_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_30_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_30_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
        fix.Entry(fields.QuoteType, True),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.Side, False),
        fix.Entry(fields.OrderQty, True),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(NoLegs_21_List, False),
        fix.Entry(fields.ValidUntilTime, False),
        fix.Entry(fields.ExposureDuration, False),
    ]

    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_29_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_29_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_30_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_30_List
    StartDate: str
    EndDate: str
    QuoteType: int
    TradingSessionSubID: str
    Side: str
    OrderQty: float
    SettlDate: str
    NoLegs: NoLegs_21_List
    ValidUntilTime: str
    ExposureDuration: int


class NoRelatedSym_4_List(fix.GroupContainer, CountCls=fields.NoRelatedSym, GroupCls=NoRelatedSym_4):
    def __getitem__(self, idx) -> NoRelatedSym_4:
        return super(NoRelatedSym_4_List, self).__getitem__(idx)


class NoPartySubIDs_31(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_31_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_31):
    def __getitem__(self, idx) -> NoPartySubIDs_31:
        return super(NoPartySubIDs_31_List, self).__getitem__(idx)


class NoPartySubIDs_32(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_32_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_32):
    def __getitem__(self, idx) -> NoPartySubIDs_32:
        return super(NoPartySubIDs_32_List, self).__getitem__(idx)


class NoPartyIDs_16(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_32_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_32_List


class NoPartyIDs_16_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_16):
    def __getitem__(self, idx) -> NoPartyIDs_16:
        return super(NoPartyIDs_16_List, self).__getitem__(idx)


class NoSecurityAltID_30(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_30_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_30):
    def __getitem__(self, idx) -> NoSecurityAltID_30:
        return super(NoSecurityAltID_30_List, self).__getitem__(idx)


class NoEvents_30(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_30_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_30):
    def __getitem__(self, idx) -> NoEvents_30:
        return super(NoEvents_30_List, self).__getitem__(idx)


class NoInstrumentParties_31(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_31_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_31):
    def __getitem__(self, idx) -> NoInstrumentParties_31:
        return super(NoInstrumentParties_31_List, self).__getitem__(idx)


class NoStreams_31(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_31_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_31):
    def __getitem__(self, idx) -> NoStreams_31:
        return super(NoStreams_31_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_24(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_24_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_24):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_24:
        return super(NoUnderlyingSecurityAltID_24_List, self).__getitem__(idx)


class NoUnderlyingSecurityAltID_25(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSecurityAltID, False),
        fix.Entry(fields.UnderlyingSecurityAltIDSource, False),
    ]

    UnderlyingSecurityAltID: str
    UnderlyingSecurityAltIDSource: str


class NoUnderlyingSecurityAltID_25_List(fix.GroupContainer, CountCls=fields.NoUnderlyingSecurityAltID, GroupCls=NoUnderlyingSecurityAltID_25):
    def __getitem__(self, idx) -> NoUnderlyingSecurityAltID_25:
        return super(NoUnderlyingSecurityAltID_25_List, self).__getitem__(idx)


class NoUnderlyings_10(fix.Group):
    Entries = [
        fix.Entry(fields.UnderlyingSymbol, False),
        fix.Entry(fields.UnderlyingSymbolSfx, False),
        fix.Entry(fields.UnderlyingSecurityID, False),
        fix.Entry(fields.UnderlyingSecurityIDSource, False),
        fix.Entry(NoUnderlyingSecurityAltID_25_List, False),
        fix.Entry(fields.UnderlyingSecurityDesc, False),
        fix.Entry(fields.UnderlyingCurrency, False),
    ]

    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: NoUnderlyingSecurityAltID_25_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str


class NoUnderlyings_10_List(fix.GroupContainer, CountCls=fields.NoUnderlyings, GroupCls=NoUnderlyings_10):
    def __getitem__(self, idx) -> NoUnderlyings_10:
        return super(NoUnderlyings_10_List, self).__getitem__(idx)


class NoLegSecurityAltID_43(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_43_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_43):
    def __getitem__(self, idx) -> NoLegSecurityAltID_43:
        return super(NoLegSecurityAltID_43_List, self).__getitem__(idx)


class NoLegSecurityAltID_44(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_44_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_44):
    def __getitem__(self, idx) -> NoLegSecurityAltID_44:
        return super(NoLegSecurityAltID_44_List, self).__getitem__(idx)


class NoLegs_22(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_44_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_44_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_22_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_22):
    def __getitem__(self, idx) -> NoLegs_22:
        return super(NoLegs_22_List, self).__getitem__(idx)


class NoRootPartySubIDs_6(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_6_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_6):
    def __getitem__(self, idx) -> NoRootPartySubIDs_6:
        return super(NoRootPartySubIDs_6_List, self).__getitem__(idx)


class NoRootPartySubIDs_7(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartySubID, False),
        fix.Entry(fields.RootPartySubIDType, False),
    ]

    RootPartySubID: str
    RootPartySubIDType: int


class NoRootPartySubIDs_7_List(fix.GroupContainer, CountCls=fields.NoRootPartySubIDs, GroupCls=NoRootPartySubIDs_7):
    def __getitem__(self, idx) -> NoRootPartySubIDs_7:
        return super(NoRootPartySubIDs_7_List, self).__getitem__(idx)


class NoRootPartyIDs_3(fix.Group):
    Entries = [
        fix.Entry(fields.RootPartyID, False),
        fix.Entry(fields.RootPartyIDSource, False),
        fix.Entry(fields.RootPartyRole, False),
        fix.Entry(NoRootPartySubIDs_7_List, False),
        fix.Entry(fields.PartyRoleQualifier, False),
    ]

    RootPartyID: str
    RootPartyIDSource: str
    RootPartyRole: int
    NoRootPartySubIDs: NoRootPartySubIDs_7_List
    PartyRoleQualifier: int


class NoRootPartyIDs_3_List(fix.GroupContainer, CountCls=fields.NoRootPartyIDs, GroupCls=NoRootPartyIDs_3):
    def __getitem__(self, idx) -> NoRootPartyIDs_3:
        return super(NoRootPartyIDs_3_List, self).__getitem__(idx)


class NoSecurityAltID_31(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_31_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_31):
    def __getitem__(self, idx) -> NoSecurityAltID_31:
        return super(NoSecurityAltID_31_List, self).__getitem__(idx)


class NoEvents_31(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_31_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_31):
    def __getitem__(self, idx) -> NoEvents_31:
        return super(NoEvents_31_List, self).__getitem__(idx)


class NoInstrumentParties_32(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_32_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_32):
    def __getitem__(self, idx) -> NoInstrumentParties_32:
        return super(NoInstrumentParties_32_List, self).__getitem__(idx)


class NoStreams_32(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_32_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_32):
    def __getitem__(self, idx) -> NoStreams_32:
        return super(NoStreams_32_List, self).__getitem__(idx)


class NoLegSecurityAltID_45(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_45_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_45):
    def __getitem__(self, idx) -> NoLegSecurityAltID_45:
        return super(NoLegSecurityAltID_45_List, self).__getitem__(idx)


class NoLegSecurityAltID_46(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_46_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_46):
    def __getitem__(self, idx) -> NoLegSecurityAltID_46:
        return super(NoLegSecurityAltID_46_List, self).__getitem__(idx)


class NoLegs_23(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_46_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_46_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_23_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_23):
    def __getitem__(self, idx) -> NoLegs_23:
        return super(NoLegs_23_List, self).__getitem__(idx)


class NoSecurityAltID_32(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_32_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_32):
    def __getitem__(self, idx) -> NoSecurityAltID_32:
        return super(NoSecurityAltID_32_List, self).__getitem__(idx)


class NoEvents_32(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_32_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_32):
    def __getitem__(self, idx) -> NoEvents_32:
        return super(NoEvents_32_List, self).__getitem__(idx)


class NoInstrumentParties_33(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_33_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_33):
    def __getitem__(self, idx) -> NoInstrumentParties_33:
        return super(NoInstrumentParties_33_List, self).__getitem__(idx)


class NoStreams_33(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_33_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_33):
    def __getitem__(self, idx) -> NoStreams_33:
        return super(NoStreams_33_List, self).__getitem__(idx)


class NoLegSecurityAltID_47(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_47_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_47):
    def __getitem__(self, idx) -> NoLegSecurityAltID_47:
        return super(NoLegSecurityAltID_47_List, self).__getitem__(idx)


class NoLegSecurityAltID_48(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_48_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_48):
    def __getitem__(self, idx) -> NoLegSecurityAltID_48:
        return super(NoLegSecurityAltID_48_List, self).__getitem__(idx)


class NoLegs_24(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_48_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_48_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_24_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_24):
    def __getitem__(self, idx) -> NoLegs_24:
        return super(NoLegs_24_List, self).__getitem__(idx)


class NoRelatedSym_5(fix.Group):
    Entries = [
        fix.Entry(fields.Symbol, False),
        fix.Entry(fields.SymbolSfx, False),
        fix.Entry(fields.SecurityID, False),
        fix.Entry(fields.SecurityIDSource, False),
        fix.Entry(NoSecurityAltID_32_List, False),
        fix.Entry(fields.Product, False),
        fix.Entry(fields.CFICode, False),
        fix.Entry(fields.SecurityType, False),
        fix.Entry(fields.SecuritySubType, False),
        fix.Entry(fields.MaturityDate, False),
        fix.Entry(fields.MaturityTime, False),
        fix.Entry(fields.SecurityStatus, False),
        fix.Entry(fields.CouponPaymentDate, False),
        fix.Entry(fields.CouponDayCount, False),
        fix.Entry(fields.IssueDate, False),
        fix.Entry(fields.Factor, False),
        fix.Entry(fields.StrikePrice, False),
        fix.Entry(fields.StrikePricePrecision, False),
        fix.Entry(fields.StrikeMultiplier, False),
        fix.Entry(fields.ContractMultiplier, False),
        fix.Entry(fields.MinPriceIncrement, False),
        fix.Entry(fields.SettlMethod, False),
        fix.Entry(fields.ExerciseStyle, False),
        fix.Entry(fields.PutOrCall, False),
        fix.Entry(fields.CouponRate, False),
        fix.Entry(fields.Issuer, False),
        fix.Entry(fields.SecurityDesc, False),
        fix.Entry(NoEvents_32_List, False),
        fix.Entry(fields.DatedDate, False),
        fix.Entry(NoInstrumentParties_33_List, False),
        fix.Entry(fields.InstrumentPricePrecision, False),
        fix.Entry(NoStreams_33_List, False),
        fix.Entry(fields.StartDate, False),
        fix.Entry(fields.EndDate, False),
        fix.Entry(fields.QuoteType, False),
        fix.Entry(fields.TradingSessionSubID, False),
        fix.Entry(fields.Side, False),
        fix.Entry(fields.OrderQty, False),
        fix.Entry(fields.SettlDate, False),
        fix.Entry(NoLegs_24_List, False),
    ]

    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: NoSecurityAltID_32_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: NoEvents_32_List
    DatedDate: str
    NoInstrumentParties: NoInstrumentParties_33_List
    InstrumentPricePrecision: int
    NoStreams: NoStreams_33_List
    StartDate: str
    EndDate: str
    QuoteType: int
    TradingSessionSubID: str
    Side: str
    OrderQty: float
    SettlDate: str
    NoLegs: NoLegs_24_List


class NoRelatedSym_5_List(fix.GroupContainer, CountCls=fields.NoRelatedSym, GroupCls=NoRelatedSym_5):
    def __getitem__(self, idx) -> NoRelatedSym_5:
        return super(NoRelatedSym_5_List, self).__getitem__(idx)


class NoPartySubIDs_33(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_33_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_33):
    def __getitem__(self, idx) -> NoPartySubIDs_33:
        return super(NoPartySubIDs_33_List, self).__getitem__(idx)


class NoPartySubIDs_34(fix.Group):
    Entries = [
        fix.Entry(fields.PartySubID, False),
        fix.Entry(fields.PartySubIDType, False),
    ]

    PartySubID: str
    PartySubIDType: int


class NoPartySubIDs_34_List(fix.GroupContainer, CountCls=fields.NoPartySubIDs, GroupCls=NoPartySubIDs_34):
    def __getitem__(self, idx) -> NoPartySubIDs_34:
        return super(NoPartySubIDs_34_List, self).__getitem__(idx)


class NoPartyIDs_17(fix.Group):
    Entries = [
        fix.Entry(fields.PartyID, True),
        fix.Entry(fields.PartyIDSource, True),
        fix.Entry(fields.PartyRole, True),
        fix.Entry(fields.PartyRoleQualifier, False),
        fix.Entry(NoPartySubIDs_34_List, False),
    ]

    PartyID: str
    PartyIDSource: str
    PartyRole: int
    PartyRoleQualifier: int
    NoPartySubIDs: NoPartySubIDs_34_List


class NoPartyIDs_17_List(fix.GroupContainer, CountCls=fields.NoPartyIDs, GroupCls=NoPartyIDs_17):
    def __getitem__(self, idx) -> NoPartyIDs_17:
        return super(NoPartyIDs_17_List, self).__getitem__(idx)


class NoSecurityAltID_33(fix.Group):
    Entries = [
        fix.Entry(fields.SecurityAltID, False),
        fix.Entry(fields.SecurityAltIDSource, False),
    ]

    SecurityAltID: str
    SecurityAltIDSource: str


class NoSecurityAltID_33_List(fix.GroupContainer, CountCls=fields.NoSecurityAltID, GroupCls=NoSecurityAltID_33):
    def __getitem__(self, idx) -> NoSecurityAltID_33:
        return super(NoSecurityAltID_33_List, self).__getitem__(idx)


class NoEvents_33(fix.Group):
    Entries = [
        fix.Entry(fields.EventType, False),
        fix.Entry(fields.EventDate, False),
        fix.Entry(fields.EventTime, False),
    ]

    EventType: int
    EventDate: str
    EventTime: str


class NoEvents_33_List(fix.GroupContainer, CountCls=fields.NoEvents, GroupCls=NoEvents_33):
    def __getitem__(self, idx) -> NoEvents_33:
        return super(NoEvents_33_List, self).__getitem__(idx)


class NoInstrumentParties_34(fix.Group):
    Entries = [
        fix.Entry(fields.InstrumentPartyID, False),
        fix.Entry(fields.InstrumentPartyIDSource, False),
        fix.Entry(fields.InstrumentPartyRole, False),
    ]

    InstrumentPartyID: str
    InstrumentPartyIDSource: str
    InstrumentPartyRole: int


class NoInstrumentParties_34_List(fix.GroupContainer, CountCls=fields.NoInstrumentParties, GroupCls=NoInstrumentParties_34):
    def __getitem__(self, idx) -> NoInstrumentParties_34:
        return super(NoInstrumentParties_34_List, self).__getitem__(idx)


class NoStreams_34(fix.Group):
    Entries = [
        fix.Entry(fields.PaymentStreamDayCount, False),
    ]

    PaymentStreamDayCount: int


class NoStreams_34_List(fix.GroupContainer, CountCls=fields.NoStreams, GroupCls=NoStreams_34):
    def __getitem__(self, idx) -> NoStreams_34:
        return super(NoStreams_34_List, self).__getitem__(idx)


class NoLegSecurityAltID_49(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_49_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_49):
    def __getitem__(self, idx) -> NoLegSecurityAltID_49:
        return super(NoLegSecurityAltID_49_List, self).__getitem__(idx)


class NoLegSecurityAltID_50(fix.Group):
    Entries = [
        fix.Entry(fields.LegSecurityAltID, False),
        fix.Entry(fields.LegSecurityAltIDSource, False),
    ]

    LegSecurityAltID: str
    LegSecurityAltIDSource: str


class NoLegSecurityAltID_50_List(fix.GroupContainer, CountCls=fields.NoLegSecurityAltID, GroupCls=NoLegSecurityAltID_50):
    def __getitem__(self, idx) -> NoLegSecurityAltID_50:
        return super(NoLegSecurityAltID_50_List, self).__getitem__(idx)


class NoLegs_25(fix.Group):
    Entries = [
        fix.Entry(fields.LegSymbol, False),
        fix.Entry(fields.LegSecurityID, False),
        fix.Entry(fields.LegSecurityIDSource, False),
        fix.Entry(NoLegSecurityAltID_50_List, False),
        fix.Entry(fields.LegSecurityDesc, False),
        fix.Entry(fields.LegRatioQty, False),
        fix.Entry(fields.LegSide, False),
        fix.Entry(fields.Side, False),
    ]

    LegSymbol: str
    LegSecurityID: str
    LegSecurityIDSource: str
    NoLegSecurityAltID: NoLegSecurityAltID_50_List
    LegSecurityDesc: str
    LegRatioQty: float
    LegSide: str
    Side: str


class NoLegs_25_List(fix.GroupContainer, CountCls=fields.NoLegs, GroupCls=NoLegs_25):
    def __getitem__(self, idx) -> NoLegs_25:
        return super(NoLegs_25_List, self).__getitem__(idx)


