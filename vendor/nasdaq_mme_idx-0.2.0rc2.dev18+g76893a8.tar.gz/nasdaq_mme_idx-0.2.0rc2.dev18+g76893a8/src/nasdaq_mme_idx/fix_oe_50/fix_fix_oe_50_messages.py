from nasdaq_protocols import fix
from . import fix_fix_oe_50_groups as groups
from . import fix_fix_oe_50_bodies as bodies
from .app import Message as Message


class News(Message,
               Name="News",
               Type="B",
               Category="EventCommunication",
               HeaderCls=bodies.Header,
               BodyCls=bodies.NewsBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.NewsBody
    Trailer: bodies.Trailer
    NewsID: str
    NoNewsRefIDs: groups.NoNewsRefIDs_1_List
    NewsCategory: int
    OrigTime: str
    Urgency: str
    Headline: str
    MarketID: str
    MarketSegmentID: str
    NoRelatedSym: groups.NoRelatedSym_1_List
    NoLegs: groups.NoLegs_1_List
    NoUnderlyings: groups.NoUnderlyings_1_List
    NoLinesOfText: groups.NoLinesOfText_1_List
    URLLink: str
    RawDataLength: int
    RawData: str


class UserRequest(Message,
               Name="UserRequest",
               Type="BE",
               Category="UserManagement",
               HeaderCls=bodies.Header,
               BodyCls=bodies.UserRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.UserRequestBody
    Trailer: bodies.Trailer
    UserRequestID: str
    UserRequestType: int
    Username: str
    Password: str
    NewPassword: str
    EncryptedPasswordMethod: int
    EncryptedPasswordLen: int
    EncryptedPassword: str
    EncryptedNewPasswordLen: int
    EncryptedNewPassword: str
    RawDataLength: int
    RawData: str


class TradingSessionListRequest(Message,
               Name="TradingSessionListRequest",
               Type="BI",
               Category="MarketStructureReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradingSessionListRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradingSessionListRequestBody
    Trailer: bodies.Trailer
    TradSesReqID: str
    MarketID: str
    MarketSegmentID: str
    TradingSessionID: str
    TradingSessionSubID: str
    SubscriptionRequestType: str


class OrderStatusRequest(Message,
               Name="OrderStatusRequest",
               Type="H",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.OrderStatusRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.OrderStatusRequestBody
    Trailer: bodies.Trailer
    OrderID: str
    ClOrdID: str
    SecondaryClOrdID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_3_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_3_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_3_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_3_List
    StartDate: str
    EndDate: str
    NoUnderlyings: groups.NoUnderlyings_2_List
    MarketSegmentID: str
    Side: str


class TradingSessionList(Message,
               Name="TradingSessionList",
               Type="BJ",
               Category="MarketStructureReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradingSessionListBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradingSessionListBody
    Trailer: bodies.Trailer
    TradSesReqID: str
    NoTradingSessions: groups.NoTradingSessions_1_List


class SecurityListUpdateReport(Message,
               Name="SecurityListUpdateReport",
               Type="BK",
               Category="SecuritiesReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.SecurityListUpdateReportBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.SecurityListUpdateReportBody
    Trailer: bodies.Trailer
    SecurityListID: str
    SecurityReqID: str
    SecurityRequestResult: int
    TotNoRelatedSym: int
    CorporateAction: str
    MarketID: str
    MarketSegmentID: str
    TransactTime: str
    LastFragment: bool
    NoRelatedSym: groups.NoRelatedSym_2_List


class MarketDefinitionRequest(Message,
               Name="MarketDefinitionRequest",
               Type="BT",
               Category="MarketStructureReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.MarketDefinitionRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.MarketDefinitionRequestBody
    Trailer: bodies.Trailer
    MarketReqID: str
    SubscriptionRequestType: str
    MarketID: str
    MarketSegmentID: str


class MarketDefinition(Message,
               Name="MarketDefinition",
               Type="BU",
               Category="MarketStructureReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.MarketDefinitionBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.MarketDefinitionBody
    Trailer: bodies.Trailer
    MarketReportID: str
    MarketReqID: str
    MarketID: str
    MarketSegmentID: str
    MarketSegmentDesc: str
    NoInstrumentScopes: groups.NoInstrumentScopes_1_List
    Currency: str
    NoTickRules: groups.NoTickRules_3_List
    NoLotTypeRules: groups.NoLotTypeRules_3_List
    RoundLot: float
    NoOrdTypeRules: groups.NoOrdTypeRules_7_List
    NoTimeInForceRules: groups.NoTimeInForceRules_7_List
    NoMatchRules: groups.NoMatchRules_7_List
    NoPartyIDs: groups.NoPartyIDs_1_List
    TransactTime: str
    Text: str
    EncodedTextLen: int
    EncodedText: str


class TradeCaptureReportRequest(Message,
               Name="TradeCaptureReportRequest",
               Type="AD",
               Category="TradeCapture",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradeCaptureReportRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradeCaptureReportRequestBody
    Trailer: bodies.Trailer
    TradeRequestID: str
    FirmTradeID: str
    TradeRequestType: int
    SubscriptionRequestType: str
    SecondaryExecID: str
    TradeLinkID: str
    NoPartyIDs: groups.NoPartyIDs_2_List
    SymbolSfx: str
    NoSecurityAltID: groups.NoSecurityAltID_6_List
    Product: int
    CFICode: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_6_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_6_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_6_List
    NoInstrAttrib: groups.NoInstrAttrib_5_List
    StartDate: str
    EndDate: str
    TradingSessionSubID: str


class TradeCaptureReport(Message,
               Name="TradeCaptureReport",
               Type="AE",
               Category="TradeCapture",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradeCaptureReportBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradeCaptureReportBody
    Trailer: bodies.Trailer
    TradeReportID: str
    TradeID: str
    SecondaryTradeID: str
    FirmTradeID: str
    TradeReportType: int
    TradeRequestID: str
    TrdType: int
    TrdSubType: int
    SecondaryTrdType: int
    TradeHandlingInstr: str
    OrigTradeID: str
    ExecType: str
    TotNumTradeReports: int
    SubscriptionRequestType: str
    TradeLinkID: str
    TrdMatchID: str
    SecondaryExecID: str
    NoRegulatoryTradeIDs: groups.NoRegulatoryTradeIDs_1_List
    PreviouslyReported: bool
    NoRootPartyIDs: groups.NoRootPartyIDs_1_List
    VenueType: str
    MarketSegmentID: str
    MarketID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_7_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_7_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_7_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_7_List
    NoInstrAttrib: groups.NoInstrAttrib_6_List
    StartDate: str
    EndDate: str
    LastQty: float
    LastPx: float
    LastMkt: str
    TradeDate: str
    NoLegs: groups.NoLegs_4_List
    TransactTime: str
    NoTrdRegTimestamps: groups.NoTrdRegTimestamps_1_List
    SettlDate: str
    MatchStatus: str
    MatchType: str
    NoSides: groups.NoSides_1_List
    CopyMsgIndicator: bool
    RejectText: str
    RegulatoryReportType: int


class OrderMassStatusRequest(Message,
               Name="OrderMassStatusRequest",
               Type="AF",
               Category="OrderMassHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.OrderMassStatusRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.OrderMassStatusRequestBody
    Trailer: bodies.Trailer
    MassStatusReqID: str
    MassStatusReqType: int
    NoPartyIDs: groups.NoPartyIDs_5_List
    Account: str
    TradingSessionID: str
    TradingSessionSubID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_8_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_8_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_8_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_8_List
    UnderlyingSymbol: str
    UnderlyingSymbolSfx: str
    UnderlyingSecurityID: str
    UnderlyingSecurityIDSource: str
    NoUnderlyingSecurityAltID: groups.NoUnderlyingSecurityAltID_9_List
    UnderlyingSecurityDesc: str
    UnderlyingCurrency: str
    Side: str


class Heartbeat(Message,
               Name="Heartbeat",
               Type="0",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.HeartbeatBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.HeartbeatBody
    Trailer: bodies.Trailer
    TestReqID: str


class TradeCaptureReportRequestAck(Message,
               Name="TradeCaptureReportRequestAck",
               Type="AQ",
               Category="TradeCapture",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradeCaptureReportRequestAckBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradeCaptureReportRequestAckBody
    Trailer: bodies.Trailer
    TradeRequestID: str
    FirmTradeID: str
    TradeRequestType: int
    SubscriptionRequestType: str
    TotNumTradeReports: int
    TradeRequestResult: int
    TradeRequestStatus: int
    SymbolSfx: str
    NoSecurityAltID: groups.NoSecurityAltID_9_List
    Product: int
    CFICode: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_9_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_9_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_9_List
    NoInstrAttrib: groups.NoInstrAttrib_7_List
    Text: str


class TestRequest(Message,
               Name="TestRequest",
               Type="1",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TestRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TestRequestBody
    Trailer: bodies.Trailer
    TestReqID: str


class TradeCaptureReportAck(Message,
               Name="TradeCaptureReportAck",
               Type="AR",
               Category="TradeCapture",
               HeaderCls=bodies.Header,
               BodyCls=bodies.TradeCaptureReportAckBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.TradeCaptureReportAckBody
    Trailer: bodies.Trailer
    TradeReportID: str
    TradeID: str
    SecondaryTradeID: str
    FirmTradeID: str
    TradeReportType: int
    TradeHandlingInstr: str
    RootPartyID: str
    RootPartyIDSource: str
    RootPartyRole: int
    NoRootPartySubIDs: groups.NoRootPartySubIDs_3_List
    PartyRoleQualifier: int
    ExecType: str
    TrdRptStatus: int
    TradeReportRejectReason: int
    RejectText: str
    SubscriptionRequestType: str
    TradeLinkID: str
    SecondaryExecID: str
    MarketSegmentID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    Product: int
    SecurityType: str
    SecuritySubType: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    EventType: int
    EventDate: str
    EventTime: str
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_10_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_10_List
    NoInstrAttrib: groups.NoInstrAttrib_8_List
    StartDate: str
    EndDate: str
    MatchStatus: str
    NoTrdRegTimestamps: groups.NoTrdRegTimestamps_2_List
    NoSides: groups.NoSides_2_List


class ResendRequest(Message,
               Name="ResendRequest",
               Type="2",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.ResendRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.ResendRequestBody
    Trailer: bodies.Trailer
    BeginSeqNo: int
    EndSeqNo: int


class Reject(Message,
               Name="Reject",
               Type="3",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.RejectBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.RejectBody
    Trailer: bodies.Trailer
    RefSeqNum: int
    RefTagID: int
    RefMsgType: str
    SessionRejectReason: int
    Text: str


class QuoteAck(Message,
               Name="QuoteAck",
               Type="CW",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteAckBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteAckBody
    Trailer: bodies.Trailer
    QuoteID: str
    QuoteCancelType: int
    SecondaryQuoteID: str
    QuoteAckStatus: int
    QuoteRejectReason: int
    RejectText: str


class SequenceReset(Message,
               Name="SequenceReset",
               Type="4",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.SequenceResetBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.SequenceResetBody
    Trailer: bodies.Trailer
    GapFillFlag: bool
    NewSeqNo: int


class SecurityListRequest(Message,
               Name="SecurityListRequest",
               Type="x",
               Category="SecuritiesReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.SecurityListRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.SecurityListRequestBody
    Trailer: bodies.Trailer
    SecurityReqID: str
    SecurityListRequestType: int
    SecurityListID: str
    MarketID: str
    MarketSegmentID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_10_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_10_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_11_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_11_List
    NoInstrAttrib: groups.NoInstrAttrib_9_List
    StartDate: str
    EndDate: str
    NoUnderlyings: groups.NoUnderlyings_5_List
    NoLegs: groups.NoLegs_5_List
    Currency: str
    Text: str
    EncodedTextLen: int
    EncodedText: str
    TradingSessionID: str
    TradingSessionSubID: str
    SubscriptionRequestType: str


class SecurityList(Message,
               Name="SecurityList",
               Type="y",
               Category="SecuritiesReferenceData",
               HeaderCls=bodies.Header,
               BodyCls=bodies.SecurityListBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.SecurityListBody
    Trailer: bodies.Trailer
    SecurityListID: str
    SecurityReqID: str
    SecurityRequestResult: int
    TransactTime: str
    TotNoRelatedSym: int
    MarketID: str
    MarketSegmentID: str
    LastFragment: bool
    NoRelatedSym: groups.NoRelatedSym_3_List


class Logon(Message,
               Name="Logon",
               Type="A",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.LogonBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.LogonBody
    Trailer: bodies.Trailer
    EncryptMethod: int
    HeartBtInt: int
    RawData: str
    ResetSeqNumFlag: bool
    RefMsgType: str
    MsgDirection: str
    RefApplVerID: str
    RefApplExtID: int
    RefCstmApplVerID: str
    DefaultVerIndicator: bool
    TestMessageIndicator: bool
    Username: str
    Password: str
    NewPassword: str
    SessionStatus: int
    DefaultApplVerID: str


class Logout(Message,
               Name="Logout",
               Type="5",
               Category="Session",
               HeaderCls=bodies.Header,
               BodyCls=bodies.LogoutBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.LogoutBody
    Trailer: bodies.Trailer
    SessionStatus: int
    Text: str


class BusinessMessageReject(Message,
               Name="BusinessMessageReject",
               Type="j",
               Category="BusinessReject",
               HeaderCls=bodies.Header,
               BodyCls=bodies.BusinessMessageRejectBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.BusinessMessageRejectBody
    Trailer: bodies.Trailer
    RefSeqNum: int
    RefMsgType: str
    RefApplVerID: str
    BusinessRejectReason: int
    Text: str


class NewOrderSingle(Message,
               Name="NewOrderSingle",
               Type="D",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.NewOrderSingleBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.NewOrderSingleBody
    Trailer: bodies.Trailer
    ClOrdID: str
    NoPartyIDs: groups.NoPartyIDs_8_List
    TradeDate: str
    NoOrderAttributes: groups.NoOrderAttributes_3_List
    SelfMatchPreventionID: str
    SettlDate: str
    ExecInst: str
    MinQty: float
    DisplayQty: float
    MarketSegmentID: str
    ExDestination: str
    NoTradingSessions: groups.NoTradingSessions_2_List
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_13_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_13_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_14_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_14_List
    StartDate: str
    EndDate: str
    Side: str
    LocateReqd: bool
    TransactTime: str
    OrderQty: float
    OrdType: str
    Price: float
    TriggerType: str
    TriggerAction: str
    TriggerPrice: float
    TriggerSymbol: str
    TriggerPriceType: str
    TriggerPriceDirection: str
    TriggerTradingSessionID: str
    TimeInForce: str
    ExpireDate: str
    ExposureDuration: int
    OrderCapacity: str
    OrderRestrictions: str
    PreTradeAnonymity: bool
    Text: str
    PositionEffect: str
    PegOffsetValue: float
    PegPriceType: int
    PegMoveType: int
    PegOffsetType: int
    PegSecurityIDSource: str
    PegSecurityID: str
    PegSymbol: str
    CustOrderHandlingInst: str
    OrderOrigination: int
    NoTrdRegTimestamps: groups.NoTrdRegTimestamps_3_List


class ExecutionReport(Message,
               Name="ExecutionReport",
               Type="8",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.ExecutionReportBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.ExecutionReportBody
    Trailer: bodies.Trailer
    OrderID: str
    SecondaryOrderID: str
    SecondaryExecID: str
    ClOrdID: str
    OrigClOrdID: str
    QuoteRespID: str
    NoOrderAttributes: groups.NoOrderAttributes_4_List
    MassStatusReqID: str
    NoPartyIDs: groups.NoPartyIDs_9_List
    TrdMatchID: str
    ExecID: str
    ExecRefID: str
    ExecType: str
    ExecTypeReason: int
    OrdStatus: str
    RejectText: str
    ExecRestatementReason: int
    NoRegulatoryTradeIDs: groups.NoRegulatoryTradeIDs_2_List
    SelfMatchPreventionID: str
    SettlDate: str
    MatchType: str
    OrderCategory: str
    Symbol: str
    SymbolSfx: str
    NoSecurityAltID: groups.NoSecurityAltID_14_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_14_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_15_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_15_List
    StartDate: str
    EndDate: str
    Side: str
    OrderQty: float
    LotType: str
    OrdType: str
    Price: float
    TriggerType: str
    TriggerAction: str
    TriggerPrice: float
    TriggerSymbol: str
    TriggerPriceType: str
    TriggerPriceDirection: str
    TriggerTradingSessionID: str
    PegOffsetValue: float
    PegPriceType: int
    PegMoveType: int
    PegOffsetType: int
    PegSecurityIDSource: str
    PegSecurityID: str
    PegSymbol: str
    PeggedPrice: float
    Currency: str
    TimeInForce: str
    ExpireDate: str
    ExposureDuration: int
    ExecInst: str
    AggressorIndicator: bool
    OrderCapacity: str
    OrderRestrictions: str
    PreTradeAnonymity: bool
    CustOrderCapacity: int
    LastQty: float
    LastPx: float
    LastMkt: str
    MarketSegmentID: str
    ExDestination: str
    TradingSessionID: str
    TradingSessionSubID: str
    LeavesQty: float
    CumQty: float
    CxlQty: float
    AvgPx: float
    TradeDate: str
    TransactTime: str
    StartCash: float
    EndCash: float
    MinQty: float
    DisplayQty: float
    InitialDisplayQty: float
    DisplayMethod: str
    RefreshQty: float
    PositionEffect: str
    Text: str
    TransBkdTime: str
    NoLegs: groups.NoLegs_8_List
    CustOrderHandlingInst: str
    OrderOrigination: int
    NoTrdRegTimestamps: groups.NoTrdRegTimestamps_4_List


class OrderCancelRequest(Message,
               Name="OrderCancelRequest",
               Type="F",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.OrderCancelRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.OrderCancelRequestBody
    Trailer: bodies.Trailer
    OrigClOrdID: str
    OrderID: str
    ClOrdID: str
    SecondaryClOrdID: str
    NoPartyIDs: groups.NoPartyIDs_10_List
    Symbol: str
    SymbolSfx: str
    NoSecurityAltID: groups.NoSecurityAltID_15_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_15_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_16_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_16_List
    StartDate: str
    EndDate: str
    MarketSegmentID: str
    ExDestination: str
    Side: str
    TransactTime: str


class OrderCancelReject(Message,
               Name="OrderCancelReject",
               Type="9",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.OrderCancelRejectBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.OrderCancelRejectBody
    Trailer: bodies.Trailer
    OrderID: str
    SecondaryOrderID: str
    SecondaryClOrdID: str
    ClOrdID: str
    OrigClOrdID: str
    OrdStatus: str
    TransactTime: str
    CxlRejResponseTo: str
    CxlRejReason: int
    RejectText: str
    ExDestination: str


class OrderCancelReplaceRequest(Message,
               Name="OrderCancelReplaceRequest",
               Type="G",
               Category="SingleGeneralOrderHandling",
               HeaderCls=bodies.Header,
               BodyCls=bodies.OrderCancelReplaceRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.OrderCancelReplaceRequestBody
    Trailer: bodies.Trailer
    OrderID: str
    NoPartyIDs: groups.NoPartyIDs_11_List
    OrigClOrdID: str
    ClOrdID: str
    NoOrderAttributes: groups.NoOrderAttributes_5_List
    SelfMatchPreventionID: str
    SettlDate: str
    ExecInst: str
    MinQty: float
    DisplayQty: float
    InitialDisplayQty: float
    DisplayMethod: str
    RefreshQty: float
    MarketSegmentID: str
    ExDestination: str
    TradingSessionID: str
    TradingSessionSubID: str
    Symbol: str
    SymbolSfx: str
    NoSecurityAltID: groups.NoSecurityAltID_16_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_16_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_17_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_17_List
    StartDate: str
    EndDate: str
    Side: str
    TransactTime: str
    OrderQty: float
    OrdType: str
    Price: float
    TriggerPrice: float
    PegOffsetValue: float
    PegPriceType: int
    PegMoveType: int
    PegOffsetType: int
    PegSecurityIDSource: str
    PegSecurityID: str
    PegSymbol: str
    TimeInForce: str
    ExpireDate: str
    ExposureDuration: int
    OrderCapacity: str
    OrderRestrictions: str
    PreTradeAnonymity: bool
    Text: str
    PositionEffect: str
    LocateReqd: bool
    CustOrderHandlingInst: str
    OrderOrigination: int
    NoTrdRegTimestamps: groups.NoTrdRegTimestamps_5_List


class MassQuote(Message,
               Name="MassQuote",
               Type="i",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.MassQuoteBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.MassQuoteBody
    Trailer: bodies.Trailer
    QuoteID: str
    QuoteType: int
    QuoteModelType: int
    QuoteResponseLevel: int
    NoPartyIDs: groups.NoPartyIDs_12_List
    NoQuoteSets: groups.NoQuoteSets_1_List


class MassQuoteAck(Message,
               Name="MassQuoteAck",
               Type="b",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.MassQuoteAckBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.MassQuoteAckBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    QuoteID: str
    QuoteStatus: int
    QuoteRejectReason: int
    QuoteResponseLevel: int
    QuoteType: int
    QuoteCancelType: int
    NoPartyIDs: groups.NoPartyIDs_13_List
    Text: str
    NoQuoteSets: groups.NoQuoteSets_2_List


class Quote(Message,
               Name="Quote",
               Type="S",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    QuoteID: str
    QuoteRespID: str
    QuoteType: int
    PrivateQuote: bool
    NoQuoteAttributes: groups.NoQuoteAttributes_1_List
    NoPartyIDs: groups.NoPartyIDs_14_List
    TradingSessionSubID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_25_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_25_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_26_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_26_List
    StartDate: str
    EndDate: str
    Side: str
    OrderQty: float
    SettlDate: str
    SingleQuoteIndicator: bool
    NoLegs: groups.NoLegs_17_List
    BidPx: float
    OfferPx: float
    ExposureDuration: int
    ValidUntilTime: str
    TransactTime: str
    ExDestination: str
    OrderCapacity: str
    OrderRestrictions: str
    Text: str


class QuoteCancel(Message,
               Name="QuoteCancel",
               Type="Z",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteCancelBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteCancelBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    QuoteID: str
    QuoteCancelType: int
    QuoteType: int
    NoPartyIDs: groups.NoPartyIDs_15_List
    TradingSessionSubID: str
    NoQuoteEntries: groups.NoQuoteEntries_5_List


class QuoteRequest(Message,
               Name="QuoteRequest",
               Type="R",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteRequestBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteRequestBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    ClOrdID: str
    OrderCapacity: str
    OrderRestrictions: str
    PrivateQuote: bool
    RespondentType: int
    PreTradeAnonymity: bool
    NoRootPartyIDs: groups.NoRootPartyIDs_2_List
    NoRelatedSym: groups.NoRelatedSym_4_List
    Text: str


class QuoteResponse(Message,
               Name="QuoteResponse",
               Type="AJ",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteResponseBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteResponseBody
    Trailer: bodies.Trailer
    QuoteRespID: str
    QuoteID: str
    QuoteReqID: str
    QuoteRespType: int
    ClOrdID: str
    OrderCapacity: str
    OrderRestrictions: str
    NoPartyIDs: groups.NoPartyIDs_16_List
    TradingSessionSubID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_30_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_30_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_31_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_31_List
    StartDate: str
    EndDate: str
    NoUnderlyings: groups.NoUnderlyings_10_List
    Side: str
    OrderQty: float
    SettlDate: str
    NoLegs: groups.NoLegs_22_List
    ValidUntilTime: str
    TransactTime: str
    OrdType: str
    ExDestination: str
    Text: str
    Price: float


class QuoteRequestReject(Message,
               Name="QuoteRequestReject",
               Type="AG",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteRequestRejectBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteRequestRejectBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    QuoteRequestRejectReason: int
    PrivateQuote: bool
    NoRootPartyIDs: groups.NoRootPartyIDs_3_List
    NoRelatedSym: groups.NoRelatedSym_5_List
    Text: str


class QuoteStatusReport(Message,
               Name="QuoteStatusReport",
               Type="AI",
               Category="QuotationNegotiation",
               HeaderCls=bodies.Header,
               BodyCls=bodies.QuoteStatusReportBody,
               TrailerCls=bodies.Trailer):
    Header: bodies.Header
    Body: bodies.QuoteStatusReportBody
    Trailer: bodies.Trailer
    QuoteReqID: str
    QuoteID: str
    SecondaryQuoteID: str
    QuoteRespID: str
    QuoteType: int
    QuoteCancelType: int
    NoPartyIDs: groups.NoPartyIDs_17_List
    TradingSessionSubID: str
    Symbol: str
    SymbolSfx: str
    SecurityID: str
    SecurityIDSource: str
    NoSecurityAltID: groups.NoSecurityAltID_33_List
    Product: int
    CFICode: str
    SecurityType: str
    SecuritySubType: str
    MaturityDate: str
    MaturityTime: str
    SecurityStatus: str
    CouponPaymentDate: str
    CouponDayCount: int
    IssueDate: str
    Factor: float
    StrikePrice: float
    StrikePricePrecision: int
    StrikeMultiplier: float
    ContractMultiplier: float
    MinPriceIncrement: float
    SettlMethod: str
    ExerciseStyle: int
    PutOrCall: int
    CouponRate: float
    Issuer: str
    SecurityDesc: str
    NoEvents: groups.NoEvents_33_List
    DatedDate: str
    NoInstrumentParties: groups.NoInstrumentParties_34_List
    InstrumentPricePrecision: int
    NoStreams: groups.NoStreams_34_List
    StartDate: str
    EndDate: str
    Side: str
    OrderQty: float
    SettlDate: str
    NoLegs: groups.NoLegs_25_List
    Price: float
    ValidUntilTime: str
    ExDestination: str
    OrderCapacity: str
    OrderRestrictions: str
    QuoteStatus: int
    QuoteRejectReason: int
    RejectText: str
    Text: str


