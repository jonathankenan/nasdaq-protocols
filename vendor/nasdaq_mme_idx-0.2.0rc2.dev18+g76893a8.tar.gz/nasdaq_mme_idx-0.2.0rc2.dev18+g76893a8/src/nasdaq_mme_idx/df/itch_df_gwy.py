from enum import Enum
from typing import Callable, Awaitable, Type

from nasdaq_protocols.common import logable
from nasdaq_protocols.common.message import *
from nasdaq_protocols import soup, itch


__all__ = [
    'Message',
    'ClientSession',
    'connect_async',
    'SecondsMessage',
    'SystemEventMessage',
    'OrderBookDirectoryMessageIdx',
    'OrderBookDirectoryExtensionMessage',
    'CombinationOrderBookLegMessage',
    'OrderBookStateMessage',
    'EquilibriumPriceMessage',
    'TickSizeTableMessage',
    'GlimpseSnapshotMessage',
    'AddAnonymousOrderMessage',
    'AddAttributedOrderMessage',
    'OrderReplaceMessage',
    'OrderDeleteMessage',
    'OrderExecutedMessage',
    'OrderExecutedWithPriceMessage',
    'TradeMessage',
    'PriceMessage',
    'TradeReportMessage',
    'BrokenTradeMessage',
    'ItchSnapshot',
]


@logable
class Message(itch.Message, app_name='df_gwy'):
    def __init_subclass__(cls, **kwargs):
        cls.log.debug('subclassing %s, params = %s', cls.__name__, str(kwargs))
        if 'indicator' not in kwargs:
            raise ValueError('expected "indicator" when subclassing df_gwy.Message')

        kwargs['app_name'] = 'df_gwy'
        super().__init_subclass__(**kwargs)


class ClientSession(itch.ClientSession):
    @classmethod
    def decode(cls, bytes_: bytes) -> [int, Message]:
        return Message.from_bytes(bytes_)


async def connect_async(remote: tuple[str, int], user: str, passwd: str, session_id,
                        sequence: int = 0,
                        session_factory: Callable[[soup.SoupClientSession], ClientSession] = None,
                        on_msg_coro: Callable[[Type[Message]], Awaitable[None]] = None,
                        on_close_coro: Callable[[], Awaitable[None]] = None,
                        client_heartbeat_interval: int = 10,
                        server_heartbeat_interval: int = 10) -> ClientSession:
    if session_factory is None:
        def session_factory(x):
            return ClientSession(x, on_msg_coro=on_msg_coro, on_close_coro=on_close_coro)

    return await itch.connect_async(
        remote, user, passwd, session_id, sequence,
        session_factory, on_msg_coro, on_close_coro,
        client_heartbeat_interval, server_heartbeat_interval
    )


# Enums
# Records
# Messages
class SecondsMessage(Message, indicator=84, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('seconds', IntBE),
        ]

    seconds: int


class SystemEventMessage(Message, indicator=83, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('event', CharIso8599),
        ]

    nanos: int
    event: str


class OrderBookDirectoryMessageIdx(Message, indicator=82, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('symbol', FixedIsoString(length=32)),
            Field('longName', FixedIsoString(length=64)),
            Field('isin', FixedIsoString(length=12)),
            Field('financialProduct', Byte),
            Field('tradingCurrency', FixedIsoString(length=3)),
            Field('decimalsInPrice', ShortBE),
            Field('decimalsInNominalValue', ShortBE),
            Field('roundLotSize', IntBE),
            Field('nominalValue', LongBE),
            Field('numberOfLegs', Byte),
            Field('underlyingOrderBookId', IntBE),
            Field('strikePrice', LongBE),
            Field('expirationDate', IntBE),
            Field('decimalsInStrikePrice', ShortBE),
            Field('optionType', Byte),
            Field('decimalsInQuantity', ShortBE),
            Field('testOrderbook', Byte),
            Field('quantityExpressedIn', Byte),
        ]

    nanos: int
    orderBookId: int
    symbol: str
    longName: str
    isin: str
    financialProduct: int
    tradingCurrency: str
    decimalsInPrice: int
    decimalsInNominalValue: int
    roundLotSize: int
    nominalValue: int
    numberOfLegs: int
    underlyingOrderBookId: int
    strikePrice: int
    expirationDate: int
    decimalsInStrikePrice: int
    optionType: int
    decimalsInQuantity: int
    testOrderbook: int
    quantityExpressedIn: int


class OrderBookDirectoryExtensionMessage(Message, indicator=88, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('orderBookType', Byte),
            Field('settlementDate', IntBE),
            Field('returnDate', IntBE),
            Field('referencePrice', LongBE),
            Field('recall', Byte),
            Field('haircut', IntBE),
            Field('dayCountConvention', Byte),
        ]

    nanos: int
    orderBookId: int
    orderBookType: int
    settlementDate: int
    returnDate: int
    referencePrice: int
    recall: int
    haircut: int
    dayCountConvention: int


class CombinationOrderBookLegMessage(Message, indicator=77, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('legOrderBookId', IntBE),
            Field('legSide', CharIso8599),
            Field('legRatio', IntBE),
        ]

    nanos: int
    orderBookId: int
    legOrderBookId: int
    legSide: str
    legRatio: int


class OrderBookStateMessage(Message, indicator=79, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('stateName', FixedIsoString(length=20)),
        ]

    nanos: int
    orderBookId: int
    stateName: str


class EquilibriumPriceMessage(Message, indicator=90, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('bidQuantity', LongBE),
            Field('askQuantity', LongBE),
            Field('price', LongBE),
            Field('bestBidPrice', LongBE),
            Field('bestAskPrice', LongBE),
            Field('bestBidQuantity', LongBE),
            Field('bestAskQuantity', LongBE),
        ]

    nanos: int
    orderBookId: int
    bidQuantity: int
    askQuantity: int
    price: int
    bestBidPrice: int
    bestAskPrice: int
    bestBidQuantity: int
    bestAskQuantity: int


class TickSizeTableMessage(Message, indicator=76, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('tickSize', LongBE),
            Field('priceFrom', LongBE),
            Field('priceTo', LongBE),
        ]

    nanos: int
    orderBookId: int
    tickSize: int
    priceFrom: int
    priceTo: int


class GlimpseSnapshotMessage(Message, indicator=71, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('itchSequenceNumber', FixedIsoString(length=20)),
        ]

    itchSequenceNumber: str


class AddAnonymousOrderMessage(Message, indicator=65, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderBookPosition', IntBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('exchangeOrderType', ShortBE),
            Field('quantityCondition', Byte),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str
    orderBookPosition: int
    quantity: int
    price: int
    exchangeOrderType: int
    quantityCondition: int


class AddAttributedOrderMessage(Message, indicator=70, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderBookPosition', IntBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('exchangeOrderType', ShortBE),
            Field('quantityCondition', Byte),
            Field('mpid', FixedIsoString(length=7)),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str
    orderBookPosition: int
    quantity: int
    price: int
    exchangeOrderType: int
    quantityCondition: int
    mpid: str


class OrderReplaceMessage(Message, indicator=85, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('orderBookPosition', IntBE),
            Field('quantity', LongBE),
            Field('price', LongBE),
            Field('exchangeOrderType', ShortBE),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str
    orderBookPosition: int
    quantity: int
    price: int
    exchangeOrderType: int


class OrderDeleteMessage(Message, indicator=68, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str


class OrderExecutedMessage(Message, indicator=69, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('quantity', LongBE),
            Field('matchId', LongBE),
            Field('comboGroupId', IntBE),
            Field('owner', FixedIsoString(length=7)),
            Field('counterparty', FixedIsoString(length=7)),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str
    quantity: int
    matchId: int
    comboGroupId: int
    owner: str
    counterparty: str


class OrderExecutedWithPriceMessage(Message, indicator=67, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderId', LongBE),
            Field('orderBookId', IntBE),
            Field('side', CharIso8599),
            Field('quantity', LongBE),
            Field('matchId', LongBE),
            Field('comboGroupId', IntBE),
            Field('owner', FixedIsoString(length=7)),
            Field('counterparty', FixedIsoString(length=7)),
            Field('price', LongBE),
            Field('cross', CharIso8599),
            Field('printable', CharIso8599),
        ]

    nanos: int
    orderId: int
    orderBookId: int
    side: str
    quantity: int
    matchId: int
    comboGroupId: int
    owner: str
    counterparty: str
    price: int
    cross: str
    printable: str


class TradeMessage(Message, indicator=80, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('matchId', LongBE),
            Field('comboGroupId', IntBE),
            Field('side', CharIso8599),
            Field('quantity', LongBE),
            Field('orderBookId', IntBE),
            Field('price', LongBE),
            Field('owner', FixedIsoString(length=7)),
            Field('counterparty', FixedIsoString(length=7)),
            Field('printable', CharIso8599),
            Field('cross', CharIso8599),
        ]

    nanos: int
    matchId: int
    comboGroupId: int
    side: str
    quantity: int
    orderBookId: int
    price: int
    owner: str
    counterparty: str
    printable: str
    cross: str


class PriceMessage(Message, indicator=112, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('priceType', CharIso8599),
            Field('orderBookId', IntBE),
            Field('price', IntBE),
        ]

    nanos: int
    priceType: str
    orderBookId: int
    price: int


class TradeReportMessage(Message, indicator=114, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('orderBookId', IntBE),
            Field('quantity', LongBE),
            Field('matchId', FixedIsoString(length=8)),
            Field('timeOfExecution', LongBE),
            Field('timeOfAgreement', LongBE),
            Field('timeOfDissemination', LongBE),
            Field('price', IntBE),
            Field('tradeType', ShortBE),
            Field('buyer', FixedIsoString(length=7)),
            Field('seller', FixedIsoString(length=7)),
            Field('settlementDate', IntBE),
            Field('printable', CharIso8599),
        ]

    nanos: int
    orderBookId: int
    quantity: int
    matchId: str
    timeOfExecution: int
    timeOfAgreement: int
    timeOfDissemination: int
    price: int
    tradeType: int
    buyer: str
    seller: str
    settlementDate: int
    printable: str


class BrokenTradeMessage(Message, indicator=66, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('nanos', IntBE),
            Field('matchId', FixedIsoString(length=8)),
        ]

    nanos: int
    matchId: str


class ItchSnapshot(Message, indicator=115, direction='outgoing'):
    class BodyRecord(Record):
        Fields = [
            Field('cacheLoaded', CharIso8599),
            Field('nextSequenceNumber', LongBE),
        ]

    cacheLoaded: str
    nextSequenceNumber: int


